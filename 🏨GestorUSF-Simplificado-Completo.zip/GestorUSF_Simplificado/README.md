# 🏥 GestorUSF Simplificado

**Sistema de Gestão de Unidades de Saúde da Família com Geração Automática de Relatórios por IA**

---

## 📋 Visão Geral

O **GestorUSF Simplificado** é uma aplicação web moderna e intuitiva para gestão de Unidades de Saúde da Família (USF). O sistema permite que gestores e coordenadores realizem inspeções, gerem registros, criem relatórios profissionais automaticamente utilizando Inteligência Artificial, e gerenciem dados de unidades e usuários.

**Principais Características:**
- ✅ Autenticação segura com controle de acesso por níveis
- ✅ Módulo de Registros com CRUD completo
- ✅ Geração automática de relatórios com IA (Perplexity, Claude, Gemini)
- ✅ Cadastro e gerenciamento de Unidades de Saúde
- ✅ Gerenciamento de Usuários do Sistema
- ✅ Configurações flexíveis de IA
- ✅ Armazenamento seguro em localStorage
- ✅ Interface responsiva e moderna

---

## 🚀 Começando

### Credenciais de Teste

Para acessar o sistema, utilize uma das seguintes credenciais:

| Nível | Email | Senha |
| :--- | :--- | :--- |
| **Administrador** | `admin@gestorUSF.com` | `123` |
| **Gerente** | `maria@gestorUSF.com` | `456` |
| **Operador** | `joao@gestorUSF.com` | `789` |

### Acesso ao Sistema

1. Abra o navegador e acesse a URL do projeto
2. Você será redirecionado para a tela de login
3. Insira email e senha de uma das credenciais acima
4. Clique em "Entrar"

---

## 📱 Funcionalidades Principais

### 1. **Dashboard**
Página inicial após login com acesso rápido a todas as funcionalidades do sistema. Exibe informações do usuário logado e dicas de uso.

### 2. **Registros** 📝
Crie, edite e delete registros de inspeção. Cada registro contém:
- Título da inspeção
- Data da inspeção
- Unidade de Saúde
- Observações gerais
- Inconformidades encontradas

### 3. **Relatórios** 📊
Gere relatórios profissionais automaticamente usando IA:
1. Selecione um registro
2. Clique em "Gerar Relatório com IA"
3. Aguarde a IA processar os dados
4. Visualize ou baixe o relatório gerado

**Importante:** Configure suas credenciais de IA em "Configurações IA" antes de usar esta funcionalidade.

### 4. **Cadastro de Unidades** 🏢
Gerencie as Unidades de Saúde da Família:
- Nome da unidade
- Código CNES
- Responsável
- Telefone e email
- Endereço
- Observações

### 5. **Cadastro de Usuários** 👥
Gerencie usuários do sistema com diferentes níveis de acesso:
- **Administrador:** Acesso total ao sistema
- **Gerente:** Acesso a registros, relatórios e unidades
- **Operador:** Acesso limitado a registros

### 6. **Configurações de IA** ⚙️
Configure sua integração com provedores de IA:

**Provedores Suportados:**
- 🔍 **Perplexity** - Pesquisa com IA em tempo real
- 🤖 **Claude (Anthropic)** - IA avançada e estruturada
- ✨ **Google Gemini** - IA rápida e eficiente

**Como Configurar:**
1. Escolha seu provedor de IA
2. Obtenha uma chave de API no site do provedor
3. Cole a chave no campo "Chave de API"
4. Selecione o modelo desejado
5. Clique em "Salvar Configurações"

---

## 🤖 Geração de Relatórios com IA

### Como Funciona

O sistema utiliza IA para gerar relatórios profissionais e estruturados baseados nos dados dos registros de inspeção. O processo é totalmente automatizado:

1. **Coleta de Dados:** Sistema extrai informações do registro selecionado
2. **Montagem do Prompt:** Cria uma instrução detalhada para a IA
3. **Chamada à API:** Envia o prompt para o provedor de IA configurado
4. **Processamento:** IA gera o relatório estruturado
5. **Salvamento:** Relatório é salvo e disponibilizado para download

### Estrutura do Relatório Gerado

Os relatórios gerados pela IA contêm as seguintes seções:

- **RESUMO EXECUTIVO** - Visão geral dos achados
- **DADOS DA INSPEÇÃO** - Informações básicas
- **ANÁLISE SITUACIONAL** - Contexto e situação atual
- **INCONFORMIDADES IDENTIFICADAS** - Problemas encontrados
- **RECOMENDAÇÕES** - Ações sugeridas
- **CONCLUSÃO** - Considerações finais

### Dicas para Melhores Resultados

- Preencha todos os campos do registro com informações detalhadas
- Seja específico nas observações e inconformidades
- Revise o relatório gerado antes de usar em documentos oficiais
- Ajuste as configurações de IA conforme necessário

---

## 💾 Armazenamento de Dados

Todos os dados são armazenados **localmente no navegador** usando `localStorage`:

- ✅ Registros de inspeção
- ✅ Relatórios gerados
- ✅ Unidades de Saúde
- ✅ Usuários do sistema
- ✅ Configurações de IA

**Segurança:**
- Dados não são enviados para servidores terceiros (exceto para gerar relatórios com IA)
- Chaves de API armazenadas apenas localmente
- Cada navegador/dispositivo tem seus próprios dados

---

## 🔐 Segurança

### Autenticação
- Senhas são validadas localmente (em produção, usar servidor seguro)
- Sessão mantida enquanto o navegador está aberto
- Logout limpa dados da sessão

### Chaves de API
- Armazenadas apenas no navegador local
- **Nunca** compartilhe sua chave de API
- Se comprometida, regenere no painel do provedor

### Dados Sensíveis
- Revise dados antes de gerar relatórios com IA
- Considere anonimizar informações sensíveis
- Faça backup regular de dados importantes

---

## 📖 Documentação Técnica

Para informações detalhadas sobre a implementação da lógica de IA, consulte:

**[LOGICA_IA_RELATORIOS.md](./LOGICA_IA_RELATORIOS.md)**

Este documento contém:
- Fluxo completo de geração de relatórios
- Detalhes de cada função
- Integração com provedores de IA
- Tratamento de erros
- Exemplos práticos

---

## 🛠️ Tecnologias Utilizadas

**Frontend:**
- React 19 com TypeScript
- Tailwind CSS 4 para styling
- shadcn/ui para componentes
- Wouter para roteamento
- Sonner para notificações

**Armazenamento:**
- localStorage para persistência local

**APIs Externas:**
- Perplexity AI API
- Anthropic Claude API
- Google Gemini API

---

## 📝 Exemplos de Uso

### Exemplo 1: Criar um Registro

1. Clique em "Registros" no menu
2. Clique em "Novo Registro"
3. Preencha os campos:
   - **Título:** "Inspeção Mensal - USF Centro"
   - **Data:** 29/10/2025
   - **Unidade:** "USF Centro Dr. José Marques"
   - **Observações:** "Inspeção realizada com sucesso..."
   - **Inconformidades:** "Ar condicionado com ruído excessivo"
4. Clique em "Salvar Registro"

### Exemplo 2: Gerar Relatório com IA

1. Certifique-se de ter configurado a IA em "Configurações IA"
2. Clique em "Relatórios"
3. Selecione um registro da lista
4. Clique em "Gerar Relatório com IA"
5. Aguarde o processamento (pode levar alguns segundos)
6. Visualize o relatório gerado
7. Clique no ícone de download para salvar

### Exemplo 3: Cadastrar Nova Unidade

1. Clique em "Unidades" no menu
2. Clique em "Nova Unidade"
3. Preencha os dados da unidade
4. Clique em "Salvar Unidade"

---

## ⚠️ Limitações e Considerações

- **Armazenamento Local:** Dados são perdidos se o navegador for limpo
- **Sem Sincronização:** Cada dispositivo tem dados independentes
- **Sem Backup Automático:** Recomenda-se fazer backup regular
- **Limite de Tamanho:** localStorage tem limite (~5-10MB por domínio)
- **Sem Servidor:** Funciona 100% no navegador (offline-first)

---

## 🚨 Troubleshooting

### "Configurações de IA não encontradas"
- Acesse "Configurações IA"
- Configure uma chave de API válida
- Selecione um modelo
- Clique em "Salvar Configurações"

### "Erro ao gerar relatório"
- Verifique se a chave de API está correta
- Confirme se o modelo está disponível
- Verifique conexão com a internet
- Tente novamente em alguns segundos

### Dados desapareceram
- Verifique se o localStorage foi limpo
- Tente restaurar do histórico do navegador
- Considere fazer backups regulares

### Relatório vazio ou incompleto
- Preencha todos os campos do registro
- Tente com outro provedor de IA
- Aumente o limite de tokens em "Configurações IA"

---

## 📞 Suporte

Para dúvidas ou problemas:

1. Consulte a documentação em [LOGICA_IA_RELATORIOS.md](./LOGICA_IA_RELATORIOS.md)
2. Verifique as credenciais de teste
3. Teste com dados simples primeiro
4. Verifique a conexão com a internet

---

## 📄 Licença

Este projeto é fornecido como-está para fins educacionais e de demonstração.

---

## 👨‍💻 Desenvolvido por

**Manus AI** - Sistema de Gestão Inteligente para Saúde Pública

---

**Versão:** 1.0.0  
**Última Atualização:** Outubro 2025
