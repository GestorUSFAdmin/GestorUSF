import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useLocation } from "wouter";
import { Plus, ArrowLeft, Trash2, Edit2 } from "lucide-react";
import { toast } from "sonner";

interface Usuario {
  id: string;
  nome: string;
  email: string;
  nivel: "Administrador" | "Gerente" | "Operador";
  telefone: string;
  ativo: boolean;
  criadoEm: string;
}

export default function CadastroUsuarioPage() {
  const [usuarios, setUsuarios] = useState<Usuario[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [, navigate] = useLocation();
  const [formData, setFormData] = useState<{
    nome: string;
    email: string;
    nivel: "Administrador" | "Gerente" | "Operador";
    telefone: string;
  }>({
    nome: "",
    email: "",
    nivel: "Operador",
    telefone: "",
  });

  useEffect(() => {
    const saved = localStorage.getItem("usuarios");
    if (saved) {
      setUsuarios(JSON.parse(saved));
    } else {
      // Dados iniciais de teste
      const usuariosIniciais: Usuario[] = [
        {
          id: "admin",
          nome: "Administrador",
          email: "admin@gestorUSF.com",
          nivel: "Administrador",
          telefone: "(11) 99999-0001",
          ativo: true,
          criadoEm: new Date().toISOString(),
        },
        {
          id: "gerente",
          nome: "Maria Silva",
          email: "maria@gestorUSF.com",
          nivel: "Gerente",
          telefone: "(11) 99999-0002",
          ativo: true,
          criadoEm: new Date().toISOString(),
        },
        {
          id: "operador",
          nome: "João Carlos",
          email: "joao@gestorUSF.com",
          nivel: "Operador",
          telefone: "(11) 99999-0003",
          ativo: true,
          criadoEm: new Date().toISOString(),
        },
      ];
      setUsuarios(usuariosIniciais);
      localStorage.setItem("usuarios", JSON.stringify(usuariosIniciais));
    }
  }, []);

  const salvarUsuarios = (novosUsuarios: Usuario[]) => {
    setUsuarios(novosUsuarios);
    localStorage.setItem("usuarios", JSON.stringify(novosUsuarios));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (editingId) {
      const updated = usuarios.map((u) =>
        u.id === editingId
          ? { ...u, ...formData, criadoEm: u.criadoEm }
          : u
      );
      salvarUsuarios(updated);
      toast.success("Usuário atualizado!");
      setEditingId(null);
    } else {
      const novoUsuario: Usuario = {
        id: `user_${Date.now()}`,
        ...formData,
        ativo: true,
        criadoEm: new Date().toISOString(),
      };
      salvarUsuarios([novoUsuario, ...usuarios]);
      toast.success("Usuário criado!");
    }

    setFormData({
      nome: "",
      email: "",
      nivel: "Operador",
      telefone: "",
    });
    setShowForm(false);
  };

  const handleDelete = (id: string) => {
    if (confirm("Tem certeza que deseja excluir este usuário?")) {
      salvarUsuarios(usuarios.filter((u) => u.id !== id));
      toast.success("Usuário excluído!");
    }
  };

  const handleEdit = (usuario: Usuario) => {
    setFormData({
      nome: usuario.nome,
      email: usuario.email,
      nivel: usuario.nivel,
      telefone: usuario.telefone,
    });
    setEditingId(usuario.id);
    setShowForm(true);
  };

  const toggleAtivo = (id: string) => {
    const updated = usuarios.map((u) =>
      u.id === id ? { ...u, ativo: !u.ativo } : u
    );
    salvarUsuarios(updated);
    toast.success("Status atualizado!");
  };

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate("/")}
              className="p-2 hover:bg-gray-200 rounded-lg"
            >
              <ArrowLeft className="w-6 h-6" />
            </button>
            <h1 className="text-3xl font-bold text-gray-900">
              Cadastro de Usuários
            </h1>
          </div>
          <Button
            onClick={() => {
              setShowForm(!showForm);
              setEditingId(null);
              setFormData({
                nome: "",
                email: "",
                nivel: "Operador",
                telefone: "",
              });
            }}
            className="bg-green-600 hover:bg-green-700 flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            Novo Usuário
          </Button>
        </div>

        {showForm && (
          <Card className="p-6 mb-8">
            <h2 className="text-xl font-semibold mb-4">
              {editingId ? "Editar" : "Novo"} Usuário
            </h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Nome
                </label>
                <Input
                  placeholder="Nome completo"
                  value={formData.nome}
                  onChange={(e) =>
                    setFormData({ ...formData, nome: e.target.value })
                  }
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Email
                  </label>
                  <Input
                    type="email"
                    placeholder="usuario@gestorUSF.com"
                    value={formData.email}
                    onChange={(e) =>
                      setFormData({ ...formData, email: e.target.value })
                    }
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Telefone
                  </label>
                  <Input
                    placeholder="(11) 99999-0000"
                    value={formData.telefone}
                    onChange={(e) =>
                      setFormData({ ...formData, telefone: e.target.value })
                    }
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Nível de Acesso
                </label>
                <select
                  value={formData.nivel}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      nivel: e.target.value as "Administrador" | "Gerente" | "Operador",
                    })
                  }
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500"
                >
                  <option value="Operador">Operador</option>
                  <option value="Gerente">Gerente</option>
                  <option value="Administrador">Administrador</option>
                </select>
              </div>

              <div className="flex gap-2">
                <Button
                  type="submit"
                  className="bg-green-600 hover:bg-green-700 flex-1"
                >
                  {editingId ? "Atualizar" : "Salvar"} Usuário
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setShowForm(false);
                    setEditingId(null);
                  }}
                  className="flex-1"
                >
                  Cancelar
                </Button>
              </div>
            </form>
          </Card>
        )}

        <div className="space-y-4">
          {usuarios.length === 0 ? (
            <Card className="p-8 text-center">
              <p className="text-gray-600">Nenhum usuário cadastrado.</p>
            </Card>
          ) : (
            usuarios.map((usuario) => (
              <Card key={usuario.id} className="p-6 hover:shadow-md transition">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="font-semibold text-lg text-gray-900">
                        {usuario.nome}
                      </h3>
                      <span
                        className={`px-2 py-1 text-xs rounded-full ${
                          usuario.ativo
                            ? "bg-green-100 text-green-800"
                            : "bg-gray-100 text-gray-800"
                        }`}
                      >
                        {usuario.ativo ? "✓ Ativo" : "✗ Inativo"}
                      </span>
                      <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">
                        {usuario.nivel}
                      </span>
                    </div>
                    <div className="text-sm text-gray-600">
                      <p>📧 {usuario.email}</p>
                      <p>📞 {usuario.telefone}</p>
                    </div>
                  </div>
                  <div className="flex gap-2 ml-4">
                    <button
                      onClick={() => toggleAtivo(usuario.id)}
                      className="px-3 py-1 text-sm rounded-lg hover:bg-yellow-100 text-yellow-600 border border-yellow-300"
                    >
                      {usuario.ativo ? "Desativar" : "Ativar"}
                    </button>
                    <button
                      onClick={() => handleEdit(usuario)}
                      className="p-2 hover:bg-blue-100 rounded-lg text-blue-600"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDelete(usuario.id)}
                      className="p-2 hover:bg-red-100 rounded-lg text-red-600"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
