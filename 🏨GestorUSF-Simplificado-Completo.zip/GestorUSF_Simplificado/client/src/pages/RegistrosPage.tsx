import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useLocation } from "wouter";
import { Plus, ArrowLeft, Trash2, Edit2, FileUp, Download, X } from "lucide-react";
import { toast } from "sonner";

interface Registro {
  id: string;
  titulo: string;
  data: string;
  unidade: string;
  observacoes: string;
  inconformidades: string;
  criadoEm: string;
  arquivos?: ArquivoAnexado[];
}

interface ArquivoAnexado {
  id: string;
  nome: string;
  tamanho: number;
  tipo: string;
  data: string;
  conteudo: string;
}

export default function RegistrosPage() {
  const [registros, setRegistros] = useState<Registro[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [, navigate] = useLocation();
  const [arquivosAnexados, setArquivosAnexados] = useState<ArquivoAnexado[]>([]);
  const [unidades, setUnidades] = useState<Array<{ id: string; nome: string }>>([]);
  const [formData, setFormData] = useState({
    titulo: "",
    data: new Date().toISOString().split("T")[0],
    unidade: "",
    observacoes: "",
    inconformidades: "",
  });

  useEffect(() => {
    const saved = localStorage.getItem("registros");
    if (saved) {
      setRegistros(JSON.parse(saved));
    }

    const unidadesSalvas = localStorage.getItem("unidades");
    if (unidadesSalvas) {
      setUnidades(JSON.parse(unidadesSalvas));
    }
  }, []);

  const salvarRegistros = (novoRegistros: Registro[]) => {
    setRegistros(novoRegistros);
    localStorage.setItem("registros", JSON.stringify(novoRegistros));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (editingId) {
      const updated = registros.map((r) =>
        r.id === editingId
          ? {
              ...r,
              ...formData,
              criadoEm: r.criadoEm,
              arquivos: arquivosAnexados,
            }
          : r
      );
      salvarRegistros(updated);
      toast.success("Registro atualizado!");
      setEditingId(null);
    } else {
      const novoRegistro: Registro = {
        id: `reg_${Date.now()}`,
        ...formData,
        criadoEm: new Date().toISOString(),
        arquivos: arquivosAnexados,
      };
      salvarRegistros([novoRegistro, ...registros]);
      toast.success("Registro criado!");
    }

    setFormData({
      titulo: "",
      data: new Date().toISOString().split("T")[0],
      unidade: "",
      observacoes: "",
      inconformidades: "",
    });
    setArquivosAnexados([]);
    setShowForm(false);
  };

  const handleDelete = (id: string) => {
    if (confirm("Tem certeza que deseja excluir este registro?")) {
      salvarRegistros(registros.filter((r) => r.id !== id));
      toast.success("Registro excluído!");
    }
  };

  const handleEdit = (registro: Registro) => {
    setFormData({
      titulo: registro.titulo,
      data: registro.data,
      unidade: registro.unidade,
      observacoes: registro.observacoes,
      inconformidades: registro.inconformidades,
    });
    setArquivosAnexados(registro.arquivos || []);
    setEditingId(registro.id);
    setShowForm(true);
  };

  const handleUploadArquivo = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    Array.from(files).forEach((file) => {
      const reader = new FileReader();
      reader.onload = (event: any) => {
        const novoArquivo: ArquivoAnexado = {
          id: `arq_${Date.now()}_${Math.random()}`,
          nome: file.name,
          tamanho: file.size,
          tipo: file.type,
          data: new Date().toISOString(),
          conteudo: event.target.result,
        };
        setArquivosAnexados([...arquivosAnexados, novoArquivo]);
        toast.success(`Arquivo "${file.name}" adicionado!`);
      };
      reader.readAsDataURL(file);
    });
  };

  const handleRemoverArquivo = (id: string) => {
    setArquivosAnexados(arquivosAnexados.filter((a) => a.id !== id));
    toast.success("Arquivo removido");
  };

  const formatarTamanho = (bytes: number) => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + " " + sizes[i];
  };

  const handleDownloadArquivo = (arquivo: ArquivoAnexado) => {
    const link = document.createElement("a");
    link.href = arquivo.conteudo;
    link.download = arquivo.nome;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success(`Arquivo "${arquivo.nome}" baixado!`);
  };

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate("/")}
              className="p-2 hover:bg-gray-200 rounded-lg"
            >
              <ArrowLeft className="w-6 h-6" />
            </button>
            <h1 className="text-3xl font-bold text-gray-900">Registros</h1>
          </div>
          <Button
            onClick={() => {
              setShowForm(!showForm);
              setEditingId(null);
              setFormData({
                titulo: "",
                data: new Date().toISOString().split("T")[0],
                unidade: "",
                observacoes: "",
                inconformidades: "",
              });
              setArquivosAnexados([]);
            }}
            className="bg-green-600 hover:bg-green-700 flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            Novo Registro
          </Button>
        </div>

        {showForm && (
          <Card className="p-6 mb-8">
            <h2 className="text-xl font-semibold mb-4">
              {editingId ? "Editar" : "Novo"} Registro
            </h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Título
                </label>
                <Input
                  placeholder="Ex: Inspeção Mensal - USF Centro"
                  value={formData.titulo}
                  onChange={(e) =>
                    setFormData({ ...formData, titulo: e.target.value })
                  }
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Data
                  </label>
                  <Input
                    type="date"
                    value={formData.data}
                    onChange={(e) =>
                      setFormData({ ...formData, data: e.target.value })
                    }
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Unidade
                  </label>
                  <select
                    value={formData.unidade}
                    onChange={(e) =>
                      setFormData({ ...formData, unidade: e.target.value })
                    }
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    required
                  >
                    <option value="">-- Selecione uma unidade --</option>
                    {unidades.map((unidade) => (
                      <option key={unidade.id} value={unidade.nome}>
                        {unidade.nome}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Observações
                </label>
                <Textarea
                  placeholder="Observações gerais sobre a inspeção..."
                  value={formData.observacoes}
                  onChange={(e) =>
                    setFormData({ ...formData, observacoes: e.target.value })
                  }
                  rows={4}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Inconformidades
                </label>
                <Textarea
                  placeholder="Listar inconformidades encontradas..."
                  value={formData.inconformidades}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      inconformidades: e.target.value,
                    })
                  }
                  rows={4}
                />
              </div>

              {/* Upload de Arquivos */}
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Anexar Arquivos (Opcional)
                </label>
                <div className="flex items-center justify-center">
                  <label className="cursor-pointer">
                    <div className="flex flex-col items-center gap-2 text-gray-600 hover:text-gray-900">
                      <FileUp className="w-6 h-6" />
                      <span className="text-sm">
                        Clique para selecionar arquivos
                      </span>
                    </div>
                    <input
                      type="file"
                      multiple
                      onChange={handleUploadArquivo}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>

              {/* Lista de Arquivos Anexados */}
              {arquivosAnexados.length > 0 && (
                <div className="bg-gray-50 rounded-lg p-4">
                  <h3 className="font-semibold text-gray-900 mb-3">
                    Arquivos Anexados ({arquivosAnexados.length})
                  </h3>
                  <div className="space-y-2">
                    {arquivosAnexados.map((arquivo) => (
                      <div
                        key={arquivo.id}
                        className="flex items-center justify-between p-2 bg-white rounded border border-gray-200"
                      >
                        <div className="flex-1">
                          <p className="text-sm font-medium text-gray-900">
                            {arquivo.nome}
                          </p>
                          <p className="text-xs text-gray-500">
                            {formatarTamanho(arquivo.tamanho)}
                          </p>
                        </div>
                        <div className="flex gap-2">
                          <button
                            type="button"
                            onClick={() => handleDownloadArquivo(arquivo)}
                            className="p-1 text-blue-600 hover:bg-blue-100 rounded"
                          >
                            <Download className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleRemoverArquivo(arquivo.id)}
                            className="p-1 text-red-600 hover:bg-red-100 rounded"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex gap-2">
                <Button
                  type="submit"
                  className="bg-green-600 hover:bg-green-700 flex-1"
                >
                  {editingId ? "Atualizar" : "Salvar"} Registro
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setShowForm(false);
                    setEditingId(null);
                    setArquivosAnexados([]);
                  }}
                  className="flex-1"
                >
                  Cancelar
                </Button>
              </div>
            </form>
          </Card>
        )}

        <div className="space-y-4">
          {registros.length === 0 ? (
            <Card className="p-8 text-center">
              <p className="text-gray-600">Nenhum registro ainda.</p>
              <p className="text-sm text-gray-500 mt-1">
                Clique em "Novo Registro" para começar.
              </p>
            </Card>
          ) : (
            registros.map((registro) => (
              <Card key={registro.id} className="p-6 hover:shadow-md transition">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="font-semibold text-lg text-gray-900">
                      {registro.titulo}
                    </h3>
                    <p className="text-sm text-gray-600 mt-1">
                      📍 {registro.unidade} • 📅{" "}
                      {new Date(registro.data).toLocaleDateString("pt-BR")}
                    </p>
                    {registro.observacoes && (
                      <p className="text-sm text-gray-700 mt-2">
                        <strong>Observações:</strong> {registro.observacoes}
                      </p>
                    )}
                    {registro.inconformidades && (
                      <p className="text-sm text-red-700 mt-1">
                        <strong>⚠️ Inconformidades:</strong>{" "}
                        {registro.inconformidades}
                      </p>
                    )}
                    {registro.arquivos && registro.arquivos.length > 0 && (
                      <div className="mt-3 p-2 bg-blue-50 rounded">
                        <p className="text-xs font-semibold text-blue-900 mb-1">
                          📎 {registro.arquivos.length} arquivo(s) anexado(s)
                        </p>
                        <div className="space-y-1">
                          {registro.arquivos.map((arq) => (
                            <div
                              key={arq.id}
                              className="flex items-center justify-between text-xs"
                            >
                              <span className="text-blue-700">{arq.nome}</span>
                              <button
                                onClick={() => handleDownloadArquivo(arq)}
                                className="text-blue-600 hover:text-blue-800"
                              >
                                <Download className="w-3 h-3" />
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                  <div className="flex gap-2 ml-4">
                    <button
                      onClick={() => handleEdit(registro)}
                      className="p-2 hover:bg-blue-100 rounded-lg text-blue-600"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDelete(registro.id)}
                      className="p-2 hover:bg-red-100 rounded-lg text-red-600"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
