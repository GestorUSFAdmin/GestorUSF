import { useAuth } from "@/contexts/AuthContext";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  FileText,
  Users,
  Building2,
  Settings,
  LogOut,
  Menu,
  Download,
  Upload,
  BarChart3,
  TrendingUp,
  AlertCircle,
} from "lucide-react";
import { useState, useEffect } from "react";
import { toast } from "sonner";

interface Registro {
  id: string;
  titulo: string;
  data: string;
  unidade: string;
  observacoes: string;
  inconformidades: string;
  criadoEm: string;
}

export default function DashboardPage() {
  const { user, logout } = useAuth();
  const [, navigate] = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [stats, setStats] = useState({
    totalRegistros: 0,
    registrosEste: 0,
    inconformidadesTotal: 0,
    unidadesAtivas: 0,
    usuariosAtivos: 0,
    relatoriosGerados: 0,
  });

  useEffect(() => {
    calcularEstatisticas();
  }, []);

  const calcularEstatisticas = () => {
    const registros = localStorage.getItem("registros");
    const unidades = localStorage.getItem("unidades");
    const usuarios = localStorage.getItem("usuarios");
    const relatorios = localStorage.getItem("relatorios");

    let regs: Registro[] = [];
    if (registros) {
      regs = JSON.parse(registros);
    }

    const agora = new Date();
    const esteAno = agora.getFullYear();
    const esteMs = agora.getMonth();

    const registrosEste = regs.filter((r) => {
      const data = new Date(r.data);
      return data.getFullYear() === esteAno && data.getMonth() === esteMs;
    }).length;

    const inconformidades = regs.filter(
      (r) => r.inconformidades && r.inconformidades.trim()
    ).length;

    const unidadesAtivas = unidades ? JSON.parse(unidades).length : 0;
    const usuariosAtivos = usuarios ? JSON.parse(usuarios).length : 0;
    const relatoriosGerados = relatorios ? JSON.parse(relatorios).length : 0;

    setStats({
      totalRegistros: regs.length,
      registrosEste,
      inconformidadesTotal: inconformidades,
      unidadesAtivas,
      usuariosAtivos,
      relatoriosGerados,
    });
  };

  const handleBackup = () => {
    try {
      const backup = {
        timestamp: new Date().toISOString(),
        versao: "1.0",
        dados: {
          registros: localStorage.getItem("registros"),
          relatorios: localStorage.getItem("relatorios"),
          unidades: localStorage.getItem("unidades"),
          usuarios: localStorage.getItem("usuarios"),
          configIA: localStorage.getItem("configIA"),
        },
      };

      const elemento = document.createElement("a");
      const arquivo = new Blob([JSON.stringify(backup, null, 2)], {
        type: "application/json",
      });
      elemento.href = URL.createObjectURL(arquivo);
      elemento.download = `backup_gestorUSF_${new Date().toISOString().split("T")[0]}.json`;
      document.body.appendChild(elemento);
      elemento.click();
      document.body.removeChild(elemento);
      URL.revokeObjectURL(elemento.href);
      toast.success("✅ Backup realizado com sucesso!");
    } catch (error) {
      toast.error("❌ Erro ao realizar backup");
    }
  };

  const handleRestore = () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".json";
    input.onchange = (e: any) => {
      const file = e.target.files[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (event: any) => {
        try {
          const backup = JSON.parse(event.target.result);

          if (!backup.dados) {
            throw new Error("Formato de backup inválido");
          }

          if (backup.dados.registros)
            localStorage.setItem("registros", backup.dados.registros);
          if (backup.dados.relatorios)
            localStorage.setItem("relatorios", backup.dados.relatorios);
          if (backup.dados.unidades)
            localStorage.setItem("unidades", backup.dados.unidades);
          if (backup.dados.usuarios)
            localStorage.setItem("usuarios", backup.dados.usuarios);
          if (backup.dados.configIA)
            localStorage.setItem("configIA", backup.dados.configIA);

          toast.success("✅ Dados restaurados com sucesso!");
          setTimeout(() => window.location.reload(), 1000);
        } catch (error) {
          toast.error("❌ Erro ao restaurar backup. Arquivo inválido.");
        }
      };
      reader.readAsText(file);
    };
    input.click();
  };

  const menuItems = [
    {
      label: "Registros",
      icon: FileText,
      path: "/registros",
      desc: "Gerenciar registros de inspeção",
    },
    {
      label: "Relatórios",
      icon: FileText,
      path: "/relatorios",
      desc: "Gerar e visualizar relatórios",
    },
    {
      label: "Unidades",
      icon: Building2,
      path: "/cadastro-unidade",
      desc: "Cadastrar unidades de saúde",
    },
    {
      label: "Usuários",
      icon: Users,
      path: "/cadastro-usuario",
      desc: "Gerenciar usuários do sistema",
    },
    {
      label: "Configurações IA",
      icon: Settings,
      path: "/configuracoes-ia",
      desc: "Configurar integração com IA",
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="p-2 hover:bg-gray-100 rounded-lg"
            >
              <Menu className="w-6 h-6" />
            </button>
            <h1 className="text-2xl font-bold text-green-700">🏥 GestorUSF</h1>
          </div>
          <div className="flex items-center gap-3">
            <Button
              variant="outline"
              size="sm"
              onClick={handleBackup}
              className="flex items-center gap-2"
              title="Fazer backup de todos os dados"
            >
              <Download className="w-4 h-4" />
              Backup
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={handleRestore}
              className="flex items-center gap-2"
              title="Restaurar dados de um backup"
            >
              <Upload className="w-4 h-4" />
              Restaurar
            </Button>
            <div className="text-right">
              <p className="font-semibold text-gray-900">{user?.nome}</p>
              <p className="text-sm text-gray-600">{user?.nivel}</p>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                logout();
                navigate("/login");
              }}
              className="flex items-center gap-2"
            >
              <LogOut className="w-4 h-4" />
              Sair
            </Button>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        {sidebarOpen && (
          <aside className="w-64 bg-white shadow-lg">
            <nav className="p-4 space-y-2">
              {menuItems.map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.path}
                    onClick={() => navigate(item.path)}
                    className="w-full text-left p-3 rounded-lg hover:bg-green-50 transition-colors group"
                  >
                    <div className="flex items-center gap-3">
                      <Icon className="w-5 h-5 text-green-600 group-hover:text-green-700" />
                      <div>
                        <p className="font-medium text-gray-900">{item.label}</p>
                        <p className="text-xs text-gray-500">{item.desc}</p>
                      </div>
                    </div>
                  </button>
                );
              })}
            </nav>
          </aside>
        )}

        {/* Main Content */}
        <main className="flex-1 p-8">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-3xl font-bold text-gray-900 mb-8">
              Bem-vindo, {user?.nome}!
            </h2>

            {/* Estatísticas em Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
              <Card className="p-6 bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Total de Registros</p>
                    <p className="text-3xl font-bold text-blue-600 mt-2">
                      {stats.totalRegistros}
                    </p>
                  </div>
                  <FileText className="w-8 h-8 text-blue-400" />
                </div>
              </Card>

              <Card className="p-6 bg-gradient-to-br from-green-50 to-green-100 border-green-200">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Este Mês</p>
                    <p className="text-3xl font-bold text-green-600 mt-2">
                      {stats.registrosEste}
                    </p>
                  </div>
                  <BarChart3 className="w-8 h-8 text-green-400" />
                </div>
              </Card>

              <Card className="p-6 bg-gradient-to-br from-red-50 to-red-100 border-red-200">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Inconformidades</p>
                    <p className="text-3xl font-bold text-red-600 mt-2">
                      {stats.inconformidadesTotal}
                    </p>
                  </div>
                  <AlertCircle className="w-8 h-8 text-red-400" />
                </div>
              </Card>

              <Card className="p-6 bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Unidades Ativas</p>
                    <p className="text-3xl font-bold text-purple-600 mt-2">
                      {stats.unidadesAtivas}
                    </p>
                  </div>
                  <Building2 className="w-8 h-8 text-purple-400" />
                </div>
              </Card>

              <Card className="p-6 bg-gradient-to-br from-yellow-50 to-yellow-100 border-yellow-200">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Usuários Ativos</p>
                    <p className="text-3xl font-bold text-yellow-600 mt-2">
                      {stats.usuariosAtivos}
                    </p>
                  </div>
                  <Users className="w-8 h-8 text-yellow-400" />
                </div>
              </Card>

              <Card className="p-6 bg-gradient-to-br from-indigo-50 to-indigo-100 border-indigo-200">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-sm text-gray-600">Relatórios Gerados</p>
                    <p className="text-3xl font-bold text-indigo-600 mt-2">
                      {stats.relatoriosGerados}
                    </p>
                  </div>
                  <TrendingUp className="w-8 h-8 text-indigo-400" />
                </div>
              </Card>
            </div>

            {/* Gráfico de Análise */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
              <Card className="p-6">
                <h3 className="font-semibold text-lg text-gray-900 mb-4">
                  Distribuição de Registros
                </h3>
                <div className="space-y-3">
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm text-gray-600">Este Mês</span>
                      <span className="text-sm font-semibold text-green-600">
                        {stats.totalRegistros > 0
                          ? Math.round(
                              (stats.registrosEste / stats.totalRegistros) * 100
                            )
                          : 0}
                        %
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-3">
                      <div
                        className="bg-green-600 h-3 rounded-full transition-all"
                        style={{
                          width: `${Math.min((stats.registrosEste / Math.max(stats.totalRegistros, 1)) * 100, 100)}%`,
                        }}
                      />
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm text-gray-600">
                        Com Inconformidades
                      </span>
                      <span className="text-sm font-semibold text-red-600">
                        {stats.totalRegistros > 0
                          ? Math.round(
                              (stats.inconformidadesTotal / stats.totalRegistros) *
                                100
                            )
                          : 0}
                        %
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-3">
                      <div
                        className="bg-red-600 h-3 rounded-full transition-all"
                        style={{
                          width: `${Math.min((stats.inconformidadesTotal / Math.max(stats.totalRegistros, 1)) * 100, 100)}%`,
                        }}
                      />
                    </div>
                  </div>
                </div>
              </Card>

              <Card className="p-6">
                <h3 className="font-semibold text-lg text-gray-900 mb-4">
                  Resumo do Sistema
                </h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between p-2 bg-gray-50 rounded">
                    <span className="text-gray-600">Total de Registros:</span>
                    <span className="font-semibold text-gray-900">
                      {stats.totalRegistros}
                    </span>
                  </div>
                  <div className="flex justify-between p-2 bg-gray-50 rounded">
                    <span className="text-gray-600">Unidades Cadastradas:</span>
                    <span className="font-semibold text-gray-900">
                      {stats.unidadesAtivas}
                    </span>
                  </div>
                  <div className="flex justify-between p-2 bg-gray-50 rounded">
                    <span className="text-gray-600">Usuários do Sistema:</span>
                    <span className="font-semibold text-gray-900">
                      {stats.usuariosAtivos}
                    </span>
                  </div>
                  <div className="flex justify-between p-2 bg-gray-50 rounded">
                    <span className="text-gray-600">Relatórios Gerados:</span>
                    <span className="font-semibold text-gray-900">
                      {stats.relatoriosGerados}
                    </span>
                  </div>
                </div>
              </Card>
            </div>

            {/* Menu de Funcionalidades */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
              {menuItems.map((item) => {
                const Icon = item.icon;
                return (
                  <Card
                    key={item.path}
                    className="p-6 hover:shadow-lg transition-shadow cursor-pointer"
                    onClick={() => navigate(item.path)}
                  >
                    <div className="flex items-start gap-4">
                      <div className="p-3 bg-green-100 rounded-lg">
                        <Icon className="w-6 h-6 text-green-600" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">
                          {item.label}
                        </h3>
                        <p className="text-sm text-gray-600 mt-1">
                          {item.desc}
                        </p>
                      </div>
                    </div>
                  </Card>
                );
              })}
            </div>

            <Card className="p-6 bg-blue-50 border-blue-200">
              <h3 className="font-semibold text-blue-900 mb-2">
                📋 Dicas de Uso
              </h3>
              <ul className="text-sm text-blue-800 space-y-1">
                <li>
                  • Use <strong>Backup</strong> para salvar todos os seus dados
                  regularmente
                </li>
                <li>
                  • Use <strong>Restaurar</strong> para recuperar dados de um
                  backup anterior
                </li>
                <li>
                  • Use a seção de <strong>Registros</strong> para adicionar
                  novos registros de inspeção
                </li>
                <li>
                  • Em <strong>Relatórios</strong>, gere relatórios automáticos
                  com IA
                </li>
                <li>
                  • Configure suas chaves de IA em{" "}
                  <strong>Configurações IA</strong>
                </li>
              </ul>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}
