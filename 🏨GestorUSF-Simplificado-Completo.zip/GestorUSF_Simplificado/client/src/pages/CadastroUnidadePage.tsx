import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useLocation } from "wouter";
import { Plus, ArrowLeft, Trash2, Edit2 } from "lucide-react";
import { toast } from "sonner";

interface Unidade {
  id: string;
  nome: string;
  cnes: string;
  responsavel: string;
  telefone: string;
  email: string;
  endereco: string;
  observacoes: string;
  criadoEm: string;
}

export default function CadastroUnidadePage() {
  const [unidades, setUnidades] = useState<Unidade[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [, navigate] = useLocation();
  const [formData, setFormData] = useState({
    nome: "",
    cnes: "",
    responsavel: "",
    telefone: "",
    email: "",
    endereco: "",
    observacoes: "",
  });

  useEffect(() => {
    const saved = localStorage.getItem("unidades");
    if (saved) {
      setUnidades(JSON.parse(saved));
    }
  }, []);

  const salvarUnidades = (novasUnidades: Unidade[]) => {
    setUnidades(novasUnidades);
    localStorage.setItem("unidades", JSON.stringify(novasUnidades));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (editingId) {
      const updated = unidades.map((u) =>
        u.id === editingId ? { ...u, ...formData, criadoEm: u.criadoEm } : u
      );
      salvarUnidades(updated);
      toast.success("Unidade atualizada!");
      setEditingId(null);
    } else {
      const novaUnidade: Unidade = {
        id: `usf_${Date.now()}`,
        ...formData,
        criadoEm: new Date().toISOString(),
      };
      salvarUnidades([novaUnidade, ...unidades]);
      toast.success("Unidade criada!");
    }

    setFormData({
      nome: "",
      cnes: "",
      responsavel: "",
      telefone: "",
      email: "",
      endereco: "",
      observacoes: "",
    });
    setShowForm(false);
  };

  const handleDelete = (id: string) => {
    if (confirm("Tem certeza que deseja excluir esta unidade?")) {
      salvarUnidades(unidades.filter((u) => u.id !== id));
      toast.success("Unidade excluída!");
    }
  };

  const handleEdit = (unidade: Unidade) => {
    setFormData({
      nome: unidade.nome,
      cnes: unidade.cnes,
      responsavel: unidade.responsavel,
      telefone: unidade.telefone,
      email: unidade.email,
      endereco: unidade.endereco,
      observacoes: unidade.observacoes,
    });
    setEditingId(unidade.id);
    setShowForm(true);
  };

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate("/")}
              className="p-2 hover:bg-gray-200 rounded-lg"
            >
              <ArrowLeft className="w-6 h-6" />
            </button>
            <h1 className="text-3xl font-bold text-gray-900">
              Cadastro de Unidades
            </h1>
          </div>
          <Button
            onClick={() => {
              setShowForm(!showForm);
              setEditingId(null);
              setFormData({
                nome: "",
                cnes: "",
                responsavel: "",
                telefone: "",
                email: "",
                endereco: "",
                observacoes: "",
              });
            }}
            className="bg-green-600 hover:bg-green-700 flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            Nova Unidade
          </Button>
        </div>

        {showForm && (
          <Card className="p-6 mb-8">
            <h2 className="text-xl font-semibold mb-4">
              {editingId ? "Editar" : "Nova"} Unidade
            </h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Nome da Unidade
                </label>
                <Input
                  placeholder="USF Centro Dr. José Marques"
                  value={formData.nome}
                  onChange={(e) =>
                    setFormData({ ...formData, nome: e.target.value })
                  }
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    CNES
                  </label>
                  <Input
                    placeholder="Código CNES"
                    value={formData.cnes}
                    onChange={(e) =>
                      setFormData({ ...formData, cnes: e.target.value })
                    }
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Responsável
                  </label>
                  <Input
                    placeholder="Nome do responsável"
                    value={formData.responsavel}
                    onChange={(e) =>
                      setFormData({ ...formData, responsavel: e.target.value })
                    }
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Telefone
                  </label>
                  <Input
                    placeholder="(83) 3333-1001"
                    value={formData.telefone}
                    onChange={(e) =>
                      setFormData({ ...formData, telefone: e.target.value })
                    }
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Email
                  </label>
                  <Input
                    type="email"
                    placeholder="unidade@saude.gov.br"
                    value={formData.email}
                    onChange={(e) =>
                      setFormData({ ...formData, email: e.target.value })
                    }
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Endereço
                </label>
                <Input
                  placeholder="Rua Principal, 100 - Centro"
                  value={formData.endereco}
                  onChange={(e) =>
                    setFormData({ ...formData, endereco: e.target.value })
                  }
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Observações
                </label>
                <Textarea
                  placeholder="Informações adicionais..."
                  value={formData.observacoes}
                  onChange={(e) =>
                    setFormData({ ...formData, observacoes: e.target.value })
                  }
                  rows={3}
                />
              </div>

              <div className="flex gap-2">
                <Button
                  type="submit"
                  className="bg-green-600 hover:bg-green-700 flex-1"
                >
                  {editingId ? "Atualizar" : "Salvar"} Unidade
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setShowForm(false);
                    setEditingId(null);
                  }}
                  className="flex-1"
                >
                  Cancelar
                </Button>
              </div>
            </form>
          </Card>
        )}

        <div className="space-y-4">
          {unidades.length === 0 ? (
            <Card className="p-8 text-center">
              <p className="text-gray-600">Nenhuma unidade cadastrada.</p>
            </Card>
          ) : (
            unidades.map((unidade) => (
              <Card key={unidade.id} className="p-6 hover:shadow-md transition">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="font-semibold text-lg text-gray-900">
                      {unidade.nome}
                    </h3>
                    <div className="grid grid-cols-2 gap-2 mt-2 text-sm text-gray-600">
                      <p>📍 {unidade.endereco}</p>
                      <p>👤 {unidade.responsavel}</p>
                      <p>📞 {unidade.telefone}</p>
                      <p>📧 {unidade.email}</p>
                      {unidade.cnes && <p>🏥 CNES: {unidade.cnes}</p>}
                    </div>
                    {unidade.observacoes && (
                      <p className="text-sm text-gray-700 mt-2">
                        <strong>Obs:</strong> {unidade.observacoes}
                      </p>
                    )}
                  </div>
                  <div className="flex gap-2 ml-4">
                    <button
                      onClick={() => handleEdit(unidade)}
                      className="p-2 hover:bg-blue-100 rounded-lg text-blue-600"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDelete(unidade.id)}
                      className="p-2 hover:bg-red-100 rounded-lg text-red-600"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
