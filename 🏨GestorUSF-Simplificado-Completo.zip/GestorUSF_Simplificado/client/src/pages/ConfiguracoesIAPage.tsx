import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useLocation } from "wouter";
import { ArrowLeft, Save, Eye, EyeOff, Zap, Loader2 } from "lucide-react";
import { toast } from "sonner";

interface ConfigIA {
  provider: "perplexity" | "claude" | "gemini";
  apiKey: string;
  modelo: string;
}

export default function ConfiguracoesIAPage() {
  const [config, setConfig] = useState<ConfigIA>({
    provider: "perplexity",
    apiKey: "",
    modelo: "",
  });
  const [showKey, setShowKey] = useState(false);
  const [, navigate] = useLocation();
  const [testando, setTestando] = useState(false);

  const modelos: Record<string, string[]> = {
    perplexity: ["sonar-pro", "sonar"],
    claude: [
      "claude-3-opus-20240229",
      "claude-3-sonnet-20240229",
      "claude-3-haiku-20240307",
    ],
    gemini: ["gemini-2.5-flash", "gemini-1.5-pro", "gemini-1.5-flash"],
  };

  useEffect(() => {
    const saved = localStorage.getItem("configIA");
    if (saved) {
      try {
        setConfig(JSON.parse(saved));
      } catch (e) {
        console.error("Erro ao carregar configurações:", e);
      }
    }
  }, []);

  const handleSave = () => {
    if (!config.apiKey) {
      toast.error("Chave de API é obrigatória!");
      return;
    }

    localStorage.setItem("configIA", JSON.stringify(config));
    toast.success("Configurações salvas com sucesso!");
  };

  const handleReset = () => {
    if (confirm("Tem certeza que deseja remover as configurações?")) {
      localStorage.removeItem("configIA");
      setConfig({
        provider: "perplexity",
        apiKey: "",
        modelo: "",
      });
      toast.success("Configurações removidas!");
    }
  };

  const testarConexao = async () => {
    if (!config.apiKey) {
      toast.error("Configure uma chave de API primeiro!");
      return;
    }

    setTestando(true);
    try {
      let response;

      if (config.provider === "perplexity") {
        response = await fetch("https://api.perplexity.ai/chat/completions", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${config.apiKey}`,
          },
          body: JSON.stringify({
            model: config.modelo || "sonar-pro",
            messages: [
              {
                role: "user",
                content: "Teste de conexão. Responda com OK.",
              },
            ],
            max_tokens: 10,
          }),
        });
      } else if (config.provider === "claude") {
        response = await fetch("https://api.anthropic.com/v1/messages", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-api-key": config.apiKey,
            "anthropic-version": "2023-06-01",
          },
          body: JSON.stringify({
            model: config.modelo || "claude-3-opus-20240229",
            max_tokens: 10,
            messages: [
              {
                role: "user",
                content: "Teste de conexão. Responda com OK.",
              },
            ],
          }),
        });
      } else if (config.provider === "gemini") {
        response = await fetch(
          `https://generativelanguage.googleapis.com/v1beta/models/${config.modelo || "gemini-2.5-flash"}:generateContent?key=${config.apiKey}`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              contents: [
                {
                  parts: [
                    {
                      text: "Teste de conexão. Responda com OK.",
                    },
                  ],
                },
              ],
              generationConfig: {
                maxOutputTokens: 10,
              },
            }),
          }
        );
      }

      if (response && response.ok) {
        toast.success(
          `Conexão com ${config.provider.toUpperCase()} estabelecida com sucesso!`
        );
      } else {
        toast.error(
          `Erro na conexão: ${response?.status} - Verifique sua chave de API`
        );
      }
    } catch (error) {
      toast.error(
        "Erro ao testar conexão. Verifique sua internet e configurações."
      );
    } finally {
      setTestando(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <button
            onClick={() => navigate("/")}
            className="p-2 hover:bg-gray-200 rounded-lg"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-3xl font-bold text-gray-900">
            Configurações de IA
          </h1>
        </div>

        <Card className="p-6 mb-6 bg-blue-50 border-blue-200">
          <h2 className="font-semibold text-blue-900 mb-2">ℹ️ Sobre</h2>
          <p className="text-sm text-blue-800">
            Configure sua chave de API de um provedor de IA para gerar
            relatórios automaticamente. Os relatórios serão criados com base
            nos dados dos registros de inspeção.
          </p>
        </Card>

        <div className="space-y-6">
          {/* Seleção de Provedor */}
          <Card className="p-6">
            <h2 className="text-lg font-semibold mb-4">Provedor de IA</h2>
            <div className="grid grid-cols-3 gap-4">
              {(["perplexity", "claude", "gemini"] as const).map((provider) => (
                <button
                  key={provider}
                  onClick={() => setConfig({ ...config, provider })}
                  className={`p-4 rounded-lg border-2 transition ${
                    config.provider === provider
                      ? "border-green-500 bg-green-50"
                      : "border-gray-200 hover:border-gray-300"
                  }`}
                >
                  <div className="text-2xl mb-2">
                    {provider === "perplexity" && "🔍"}
                    {provider === "claude" && "🤖"}
                    {provider === "gemini" && "✨"}
                  </div>
                  <p className="font-semibold text-gray-900 capitalize">
                    {provider}
                  </p>
                  <p className="text-xs text-gray-600 mt-1">
                    {provider === "perplexity" &&
                      "Pesquisa com IA em tempo real"}
                    {provider === "claude" && "IA avançada da Anthropic"}
                    {provider === "gemini" && "IA do Google"}
                  </p>
                </button>
              ))}
            </div>
          </Card>

          {/* Chave de API */}
          <Card className="p-6">
            <h2 className="text-lg font-semibold mb-4">Chave de API</h2>
            <div className="space-y-3">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Chave de API para {config.provider.toUpperCase()}
                </label>
                <div className="flex gap-2">
                  <Input
                    type={showKey ? "text" : "password"}
                    placeholder="Cole sua chave de API aqui"
                    value={config.apiKey}
                    onChange={(e) =>
                      setConfig({ ...config, apiKey: e.target.value })
                    }
                    className="flex-1"
                  />
                  <button
                    onClick={() => setShowKey(!showKey)}
                    className="p-2 hover:bg-gray-100 rounded-lg"
                  >
                    {showKey ? (
                      <EyeOff className="w-5 h-5 text-gray-600" />
                    ) : (
                      <Eye className="w-5 h-5 text-gray-600" />
                    )}
                  </button>
                </div>
              </div>

              <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                <p className="text-xs text-yellow-800">
                  <strong>⚠️ Segurança:</strong> Sua chave de API é armazenada
                  localmente no navegador. Nunca compartilhe sua chave com
                  terceiros.
                </p>
              </div>
            </div>
          </Card>

          {/* Modelo */}
          <Card className="p-6">
            <h2 className="text-lg font-semibold mb-4">Modelo de IA</h2>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Selecione o modelo
              </label>
              <select
                value={config.modelo}
                onChange={(e) =>
                  setConfig({ ...config, modelo: e.target.value })
                }
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              >
                <option value="">-- Selecione um modelo --</option>
                {modelos[config.provider].map((modelo) => (
                  <option key={modelo} value={modelo}>
                    {modelo}
                  </option>
                ))}
              </select>
              <p className="text-xs text-gray-600 mt-2">
                Modelos disponíveis para {config.provider}
              </p>
            </div>
          </Card>

          {/* Teste de Conexão */}
          <Card className="p-6 bg-purple-50 border-purple-200">
            <h2 className="text-lg font-semibold mb-4 text-purple-900">
              🧪 Testar Conexão
            </h2>
            <p className="text-sm text-purple-800 mb-4">
              Clique no botão abaixo para testar se sua chave de API está
              funcionando corretamente.
            </p>
            <Button
              onClick={testarConexao}
              disabled={testando || !config.apiKey}
              className="w-full bg-purple-600 hover:bg-purple-700 flex items-center justify-center gap-2"
            >
              {testando ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Testando conexão...
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4" />
                  Testar Conexão com API
                </>
              )}
            </Button>
          </Card>

          {/* Informações de Obtenção de Chaves */}
          <Card className="p-6 bg-gray-50">
            <h2 className="text-lg font-semibold mb-4">
              Como obter sua chave de API
            </h2>
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold text-green-700 mb-2">
                  🔍 Perplexity
                </h3>
                <ol className="text-sm text-gray-700 space-y-1 list-decimal list-inside">
                  <li>Acesse https://www.perplexity.ai/</li>
                  <li>Faça login ou crie uma conta</li>
                  <li>Vá para Configurações → Chaves de API</li>
                  <li>Crie uma nova chave e copie</li>
                </ol>
              </div>
              <div>
                <h3 className="font-semibold text-green-700 mb-2">
                  🤖 Claude (Anthropic)
                </h3>
                <ol className="text-sm text-gray-700 space-y-1 list-decimal list-inside">
                  <li>Acesse https://console.anthropic.com/</li>
                  <li>Faça login ou crie uma conta</li>
                  <li>Vá para API Keys</li>
                  <li>Crie uma nova chave e copie</li>
                </ol>
              </div>
              <div>
                <h3 className="font-semibold text-green-700 mb-2">
                  ✨ Google Gemini
                </h3>
                <ol className="text-sm text-gray-700 space-y-1 list-decimal list-inside">
                  <li>Acesse https://ai.google.dev/</li>
                  <li>Clique em "Get API Key"</li>
                  <li>Crie um novo projeto</li>
                  <li>Gere uma chave de API e copie</li>
                </ol>
              </div>
            </div>
          </Card>

          {/* Botões de Ação */}
          <div className="flex gap-3">
            <Button
              onClick={handleSave}
              className="flex-1 bg-green-600 hover:bg-green-700 flex items-center justify-center gap-2"
            >
              <Save className="w-4 h-4" />
              Salvar Configurações
            </Button>
            <Button
              onClick={handleReset}
              variant="outline"
              className="flex-1 text-red-600 hover:bg-red-50"
            >
              Remover Configurações
            </Button>
          </div>

          {/* Status */}
          {config.apiKey && (
            <Card className="p-4 bg-green-50 border-green-200">
              <p className="text-sm text-green-800">
                ✓ Configurações ativas. Você pode gerar relatórios com IA.
              </p>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
