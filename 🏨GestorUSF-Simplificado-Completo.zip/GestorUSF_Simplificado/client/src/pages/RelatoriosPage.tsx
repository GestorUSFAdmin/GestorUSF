import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useLocation } from "wouter";
import { ArrowLeft, Download, Loader2, FileText } from "lucide-react";
import { toast } from "sonner";

interface Registro {
  id: string;
  titulo: string;
  data: string;
  unidade: string;
  observacoes: string;
  inconformidades: string;
  criadoEm: string;
  arquivos?: Array<{
    id: string;
    nome: string;
    tamanho: number;
    tipo: string;
    data: string;
    conteudo: string;
  }>;
}

const formatarTamanho = (bytes: number) => {
  if (bytes === 0) return "0 Bytes";
  const k = 1024;
  const sizes = ["Bytes", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + " " + sizes[i];
}

interface Relatorio {
  id: string;
  titulo: string;
  conteudo: string;
  registroId: string;
  criadoEm: string;
  tipo: "ia" | "manual";
}

export default function RelatoriosPage() {
  const [registros, setRegistros] = useState<Registro[]>([]);
  const [relatorios, setRelatorios] = useState<Relatorio[]>([]);
  const [selectedRegistroId, setSelectedRegistroId] = useState<string>("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [, navigate] = useLocation();
  const [expandedRelatorio, setExpandedRelatorio] = useState<string | null>(null);

  useEffect(() => {
    const savedRegistros = localStorage.getItem("registros");
    const savedRelatorios = localStorage.getItem("relatorios");

    if (savedRegistros) {
      setRegistros(JSON.parse(savedRegistros));
    }
    if (savedRelatorios) {
      setRelatorios(JSON.parse(savedRelatorios));
    }
  }, []);

  const salvarRelatorios = (novosRelatorios: Relatorio[]) => {
    setRelatorios(novosRelatorios);
    localStorage.setItem("relatorios", JSON.stringify(novosRelatorios));
  };

  const gerarRelatorioComIA = async () => {
    if (!selectedRegistroId) {
      toast.error("Selecione um registro!");
      return;
    }

    const registro = registros.find((r) => r.id === selectedRegistroId);
    if (!registro) {
      toast.error("Registro não encontrado!");
      return;
    }

    setIsGenerating(true);
    try {
      const conteudo = await gerarRelatorioIA(registro);

      const novoRelatorio: Relatorio = {
        id: `rel_${Date.now()}`,
        titulo: `Relatório IA - ${registro.titulo}`,
        conteudo,
        registroId: registro.id,
        criadoEm: new Date().toISOString(),
        tipo: "ia",
      };

      salvarRelatorios([novoRelatorio, ...relatorios]);
      toast.success("Relatório gerado com sucesso!");
      setSelectedRegistroId("");
    } catch (error) {
      console.error("Erro ao gerar relatório:", error);
      toast.error(
        error instanceof Error ? error.message : "Erro ao gerar relatório"
      );
    } finally {
      setIsGenerating(false);
    }
  };

  const downloadRelatorio = (relatorio: Relatorio, formato: string = "txt") => {
    let conteudo: any = relatorio.conteudo;
    let tipo = "text/plain";
    let extensao = "txt";

    if (formato === "txt") {
      tipo = "text/plain";
      extensao = "txt";
    } else if (formato === "html") {
      tipo = "text/html";
      extensao = "html";
      conteudo = gerarHTML(relatorio);
    } else if (formato === "json") {
      tipo = "application/json";
      extensao = "json";
      conteudo = JSON.stringify(relatorio, null, 2);
    } else if (formato === "docx") {
      tipo = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
      extensao = "docx";
      conteudo = gerarDOCX(relatorio);
    } else if (formato === "pdf") {
      tipo = "application/pdf";
      extensao = "pdf";
      conteudo = gerarPDF(relatorio);
    }

    const elemento = document.createElement("a");
    const arquivo = new Blob([conteudo], { type: tipo });
    elemento.href = URL.createObjectURL(arquivo);
    elemento.download = `${relatorio.titulo.replace(/\s+/g, "_")}.${extensao}`;
    document.body.appendChild(elemento);
    elemento.click();
    document.body.removeChild(elemento);
    URL.revokeObjectURL(elemento.href);
    toast.success(`Relatório baixado em ${formato.toUpperCase()}!`);
  };

  const gerarHTML = (relatorio: Relatorio) => {
    return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${relatorio.titulo}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { 
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
      line-height: 1.6; 
      color: #333; 
      background: #f5f5f5;
    }
    .container { 
      max-width: 900px; 
      margin: 0 auto; 
      padding: 40px 20px;
      background: white;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }
    .header { 
      border-bottom: 3px solid #2ecc71; 
      padding-bottom: 20px; 
      margin-bottom: 30px; 
    }
    .header h1 { 
      color: #2ecc71; 
      font-size: 28px;
      margin-bottom: 10px;
    }
    .header p { 
      color: #666; 
      font-size: 14px;
    }
    .content { 
      white-space: pre-wrap; 
      word-wrap: break-word;
      background: #f9f9f9;
      padding: 20px;
      border-radius: 5px;
      border-left: 4px solid #2ecc71;
    }
    .footer { 
      margin-top: 30px; 
      padding-top: 20px; 
      border-top: 1px solid #ddd; 
      font-size: 12px; 
      color: #999;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>🏥 GestorUSF - Relatório</h1>
      <p><strong>${relatorio.titulo}</strong></p>
      <p>Gerado em: ${new Date(relatorio.criadoEm).toLocaleDateString("pt-BR")} às ${new Date(relatorio.criadoEm).toLocaleTimeString("pt-BR")}</p>
    </div>
    <div class="content">${relatorio.conteudo}</div>
    <div class="footer">
      <p>Este relatório foi gerado automaticamente pelo sistema GestorUSF.</p>
    </div>
  </div>
</body>
</html>`;
  };

  const gerarDOCX = (relatorio: Relatorio) => {
    // Estrutura básica de DOCX em XML
    const docxContent = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:body>
    <w:p>
      <w:pPr>
        <w:pStyle w:val="Heading1"/>
      </w:pPr>
      <w:r>
        <w:rPr>
          <w:b/>
          <w:sz w:val="48"/>
        </w:rPr>
        <w:t>GestorUSF - Relatório</w:t>
      </w:r>
    </w:p>
    <w:p>
      <w:r>
        <w:t>${relatorio.titulo}</w:t>
      </w:r>
    </w:p>
    <w:p>
      <w:r>
        <w:t>Gerado em: ${new Date(relatorio.criadoEm).toLocaleDateString("pt-BR")}</w:t>
      </w:r>
    </w:p>
    <w:p>
      <w:r>
        <w:br/>
      </w:r>
    </w:p>
    <w:p>
      <w:r>
        <w:t>${relatorio.conteudo.replace(/\n/g, "</w:t></w:r></w:p><w:p><w:r><w:t>")}</w:t>
      </w:r>
    </w:p>
  </w:body>
</w:document>`;
    return docxContent;
  };

  const gerarPDF = (relatorio: Relatorio) => {
    // Estrutura básica de PDF
    const pdfContent = `%PDF-1.4
1 0 obj
<< /Type /Catalog /Pages 2 0 R >>
endobj
2 0 obj
<< /Type /Pages /Kids [3 0 R] /Count 1 >>
endobj
3 0 obj
<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>
endobj
4 0 obj
<< /Length 500 >>
stream
BT
/F1 12 Tf
50 750 Td
(GestorUSF - Relatório) Tj
0 -20 Td
(${relatorio.titulo}) Tj
0 -20 Td
(Gerado em: ${new Date(relatorio.criadoEm).toLocaleDateString("pt-BR")}) Tj
0 -40 Td
(${relatorio.conteudo.substring(0, 500)}) Tj
ET
endstream
endobj
5 0 obj
<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>
endobj
xref
0 6
0000000000 65535 f
0000000009 00000 n
0000000058 00000 n
0000000115 00000 n
0000000244 00000 n
0000000848 00000 n
trailer
<< /Size 6 /Root 1 0 R >>
startxref
945
%%EOF`;
    return pdfContent;
  };

  const copiarParaClipboard = (texto: string) => {
    navigator.clipboard.writeText(texto);
    toast.success("Conteúdo copiado para a área de transferência!");
  };

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <button
            onClick={() => navigate("/")}
            className="p-2 hover:bg-gray-200 rounded-lg"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-3xl font-bold text-gray-900">Relatórios</h1>
        </div>

        {/* Seção de Geração */}
        <Card className="p-6 mb-8 bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
          <h2 className="text-xl font-semibold mb-4">🤖 Gerar Relatório com IA</h2>
          <p className="text-gray-700 mb-4">
            Selecione um registro para gerar um relatório detalhado utilizando
            Inteligência Artificial.
          </p>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Selecione um Registro
              </label>
              <select
                value={selectedRegistroId}
                onChange={(e) => setSelectedRegistroId(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              >
                <option value="">-- Escolha um registro --</option>
                {registros.length === 0 ? (
                  <option disabled>Nenhum registro disponível</option>
                ) : (
                  registros.map((r) => (
                    <option key={r.id} value={r.id}>
                      {r.titulo} ({new Date(r.data).toLocaleDateString("pt-BR")})
                    </option>
                  ))
                )}
              </select>
            </div>

            <Button
              onClick={gerarRelatorioComIA}
              disabled={isGenerating || !selectedRegistroId}
              className="w-full bg-green-600 hover:bg-green-700"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Gerando relatório...
                </>
              ) : (
                "Gerar Relatório com IA"
              )}
            </Button>
          </div>
        </Card>

        {/* Lista de Relatórios */}
        <div>
          <h2 className="text-xl font-semibold mb-4">
            📋 Relatórios Gerados ({relatorios.length})
          </h2>
          {relatorios.length === 0 ? (
            <Card className="p-8 text-center">
              <FileText className="w-12 h-12 text-gray-400 mx-auto mb-3" />
              <p className="text-gray-600">Nenhum relatório gerado ainda.</p>
              <p className="text-sm text-gray-500 mt-1">
                Gere seu primeiro relatório usando a seção acima.
              </p>
            </Card>
          ) : (
            <div className="space-y-4">
              {relatorios.map((relatorio) => (
                <Card
                  key={relatorio.id}
                  className="p-6 hover:shadow-md transition"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="font-semibold text-lg text-gray-900">
                          {relatorio.titulo}
                        </h3>
                        <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full font-semibold">
                          {relatorio.tipo === "ia" ? "🤖 IA" : "📝 Manual"}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600">
                        📅{" "}
                        {new Date(relatorio.criadoEm).toLocaleDateString(
                          "pt-BR"
                        )}{" "}
                        às{" "}
                        {new Date(relatorio.criadoEm).toLocaleTimeString(
                          "pt-BR"
                        )}
                      </p>

                      {/* Prévia do Conteúdo */}
                      <div className="mt-3 p-3 bg-gray-50 rounded-lg max-h-40 overflow-y-auto border-l-4 border-green-300">
                        <p className="text-sm text-gray-700 whitespace-pre-wrap">
                          {expandedRelatorio === relatorio.id
                            ? relatorio.conteudo
                            : relatorio.conteudo.substring(0, 400) + "..."}
                        </p>
                      </div>

                      {relatorio.conteudo.length > 400 && (
                        <button
                          onClick={() =>
                            setExpandedRelatorio(
                              expandedRelatorio === relatorio.id
                                ? null
                                : relatorio.id
                            )
                          }
                          className="mt-2 text-sm text-blue-600 hover:text-blue-800"
                        >
                          {expandedRelatorio === relatorio.id
                            ? "▼ Ver menos"
                            : "▶ Ver mais"}
                        </button>
                      )}
                    </div>

                    {/* Botões de Ação */}
                    <div className="ml-4 flex flex-col gap-2">
                      <div className="flex gap-1 flex-wrap">
                        <button
                          onClick={() => downloadRelatorio(relatorio, "txt")}
                          className="p-2 hover:bg-blue-100 rounded-lg text-blue-600 text-xs"
                          title="Baixar como TXT"
                        >
                          TXT
                        </button>
                        <button
                          onClick={() => downloadRelatorio(relatorio, "html")}
                          className="p-2 hover:bg-purple-100 rounded-lg text-purple-600 text-xs"
                          title="Baixar como HTML"
                        >
                          HTML
                        </button>
                        <button
                          onClick={() => downloadRelatorio(relatorio, "json")}
                          className="p-2 hover:bg-orange-100 rounded-lg text-orange-600 text-xs"
                          title="Baixar como JSON"
                        >
                          JSON
                        </button>
                        <button
                          onClick={() => downloadRelatorio(relatorio, "docx")}
                          className="p-2 hover:bg-red-100 rounded-lg text-red-600 text-xs"
                          title="Baixar como DOCX"
                        >
                          DOCX
                        </button>
                        <button
                          onClick={() => downloadRelatorio(relatorio, "pdf")}
                          className="p-2 hover:bg-red-100 rounded-lg text-red-700 text-xs font-semibold"
                          title="Baixar como PDF"
                        >
                          PDF
                        </button>
                      </div>
                      <button
                        onClick={() => copiarParaClipboard(relatorio.conteudo)}
                        className="p-2 hover:bg-gray-200 rounded-lg text-gray-600 text-xs"
                        title="Copiar para área de transferência"
                      >
                        📋 Copiar
                      </button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>

        {/* Informações sobre Formatos */}
        <Card className="mt-8 p-4 bg-blue-50 border-blue-200">
          <h3 className="font-semibold text-blue-900 mb-2">
            ℹ️ Formatos de Exportação
          </h3>
          <ul className="text-sm text-blue-800 space-y-1">
            <li>
              • <strong>TXT</strong> - Texto simples, compatível com qualquer
              editor
            </li>
            <li>
              • <strong>HTML</strong> - Página web formatada, abra no navegador
            </li>
            <li>
              • <strong>JSON</strong> - Formato estruturado para integração com
              outros sistemas
            </li>
          </ul>
        </Card>
      </div>
    </div>
  );
}

/**
 * LÓGICA DE GERAÇÃO DE RELATÓRIOS COM IA
 * =====================================
 *
 * Este sistema gera relatórios profissionais automaticamente usando IA.
 *
 * FLUXO:
 * 1. Usuário seleciona um registro de inspeção
 * 2. Sistema prepara um prompt estruturado com os dados do registro
 * 3. Prompt é enviado para a API de IA configurada
 * 4. IA gera um relatório profissional e estruturado
 * 5. Relatório é salvo e pode ser exportado em vários formatos
 */

async function gerarRelatorioIA(registro: Registro): Promise<string> {
  const configIA = localStorage.getItem("configIA");
  if (!configIA) {
    throw new Error(
      "Configurações de IA não encontradas. Configure em Configurações IA."
    );
  }

  const config = JSON.parse(configIA);

  // Preparar informações sobre anexos
  let infoAnexos = "";
  if (registro.arquivos && registro.arquivos.length > 0) {
    infoAnexos = `\n\n**ARQUIVOS ANEXADOS:**\n`;
    registro.arquivos.forEach((arq) => {
      infoAnexos += `- ${arq.nome} (${formatarTamanho(arq.tamanho)})\n`;
    });
    infoAnexos += `\nTotal de ${registro.arquivos.length} arquivo(s) anexado(s) à inspeção.`;
  }

  const prompt = `
Você é um especialista em gestão de saúde pública e auditoria de Unidades de Saúde da Família (USF).

Gere um relatório profissional e detalhado baseado nos seguintes dados de inspeção:

**DADOS DA INSPEÇÃO:**
- Título: ${registro.titulo}
- Data: ${new Date(registro.data).toLocaleDateString("pt-BR")}
- Unidade: ${registro.unidade}
- Observações: ${registro.observacoes}
- Inconformidades Encontradas: ${registro.inconformidades}${infoAnexos}

**INSTRUÇÕES PARA O RELATÓRIO:**
1. Crie um relatório estruturado com as seguintes seções:
   - RESUMO EXECUTIVO (2-3 linhas)
   - DADOS DA INSPEÇÃO (listar todos os dados)
   - ANÁLISE SITUACIONAL (análise dos dados coletados)
   - INCONFORMIDADES IDENTIFICADAS (listar cada uma com detalhes)
   - RECOMENDAÇÕES (ações corretivas sugeridas)
   - CONCLUSÃO

2. Use linguagem formal e técnica apropriada para documentos oficiais
3. Seja objetivo e claro nas recomendações
4. Formate o relatório de forma profissional e legível

Gere o relatório completo agora:
`;

  try {
    const relatorioGerado = await chamarAPIIA(config, prompt);
    return relatorioGerado;
  } catch (error) {
    console.error("Erro ao chamar API de IA:", error);
    throw new Error(
      "Erro ao gerar relatório com IA. Verifique suas configurações."
    );
  }
}

async function chamarAPIIA(config: any, prompt: string): Promise<string> {
  const { provider, apiKey, modelo } = config;

  if (!apiKey) {
    throw new Error("Chave de API não configurada");
  }

  if (provider === "perplexity") {
    return await chamarPerplexity(apiKey, modelo, prompt);
  } else if (provider === "claude") {
    return await chamarClaude(apiKey, modelo, prompt);
  } else if (provider === "gemini") {
    return await chamarGemini(apiKey, modelo, prompt);
  } else {
    throw new Error("Provedor de IA não suportado");
  }
}

async function chamarPerplexity(
  apiKey: string,
  modelo: string,
  prompt: string
): Promise<string> {
  const response = await fetch("https://api.perplexity.ai/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: modelo || "sonar-pro",
      messages: [
        {
          role: "user",
          content: prompt,
        },
      ],
      temperature: 0.7,
      max_tokens: 2000,
    }),
  });

  if (!response.ok) {
    throw new Error(`Erro na API Perplexity: ${response.statusText}`);
  }

  const data = await response.json();
  return data.choices[0].message.content;
}

async function chamarClaude(
  apiKey: string,
  modelo: string,
  prompt: string
): Promise<string> {
  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: modelo || "claude-3-opus-20240229",
      max_tokens: 2000,
      messages: [
        {
          role: "user",
          content: prompt,
        },
      ],
    }),
  });

  if (!response.ok) {
    throw new Error(`Erro na API Claude: ${response.statusText}`);
  }

  const data = await response.json();
  return data.content[0].text;
}

async function chamarGemini(
  apiKey: string,
  modelo: string,
  prompt: string
): Promise<string> {
  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${modelo || "gemini-2.5-flash"}:generateContent?key=${apiKey}`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        contents: [
          {
            parts: [
              {
                text: prompt,
              },
            ],
          },
        ],
        generationConfig: {
          temperature: 0.7,
          maxOutputTokens: 2000,
        },
      }),
    }
  );

  if (!response.ok) {
    throw new Error(`Erro na API Gemini: ${response.statusText}`);
  }

  const data = await response.json();
  return data.candidates[0].content.parts[0].text;
}
