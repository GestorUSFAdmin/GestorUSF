import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import LoginPage from "./pages/LoginPage";
import DashboardPage from "./pages/DashboardPage";
import RegistrosPage from "./pages/RegistrosPage";
import RelatoriosPage from "./pages/RelatoriosPage";
import CadastroUnidadePage from "./pages/CadastroUnidadePage";
import CadastroUsuarioPage from "./pages/CadastroUsuarioPage";
import ConfiguracoesIAPage from "./pages/ConfiguracoesIAPage";
import { useAuth } from "./contexts/AuthContext";

function Router() {
  const { user } = useAuth();

  return (
    <Switch>
      <Route path="/login" component={LoginPage} />
      {user ? (
        <>
          <Route path="/" component={DashboardPage} />
          <Route path="/registros" component={RegistrosPage} />
          <Route path="/relatorios" component={RelatoriosPage} />
          <Route path="/cadastro-unidade" component={CadastroUnidadePage} />
          <Route path="/cadastro-usuario" component={CadastroUsuarioPage} />
          <Route path="/configuracoes-ia" component={ConfiguracoesIAPage} />
        </>
      ) : (
        <Route path="*" component={LoginPage} />
      )}
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

import { AuthProvider } from "./contexts/AuthContext";

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        // switchable
      >
        <AuthProvider>
          <TooltipProvider>
            <Toaster />
            <Router />
          </TooltipProvider>
        </AuthProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
