# 🏥 Guia do Usuário - GestorUSF Simplificado

## Bem-vindo ao Sistema de Gestão de Unidades de Saúde

O **GestorUSF Simplificado** é um sistema moderno e intuitivo para gerenciar inspeções, registros e gerar relatórios profissionais automaticamente usando Inteligência Artificial.

---

## 🚀 Começando

### Login

Acesse o sistema com uma das credenciais de teste:

- **Admin:** `admin@gestorUSF.com` / `123`
- **Gerente:** `maria@gestorUSF.com` / `456`
- **Operador:** `joao@gestorUSF.com` / `789`

Após o login, você verá o **Dashboard** com acesso a todas as funcionalidades.

---

## 📊 Funcionalidades Principais

### 1️⃣ Registros - Criar e Gerenciar Inspeções

**O que é?** Registros são documentos de inspeção das Unidades de Saúde onde você anota observações e inconformidades encontradas.

**Como Usar:**
1. Clique em **"Registros"** no menu lateral
2. Clique em **"Novo Registro"**
3. Preencha os campos:
   - **Título:** Dê um nome descritivo (ex: "Inspeção Mensal - USF Centro")
   - **Data:** Selecione a data da inspeção
   - **Unidade:** Escolha a unidade de saúde
   - **Observações:** Descreva como foi a inspeção
   - **Inconformidades:** Liste os problemas encontrados
4. Clique em **"Salvar Registro"**

**Ações Disponíveis:**
- ✏️ **Editar:** Clique no ícone de lápis para modificar
- 🗑️ **Excluir:** Clique no ícone de lixo para remover

---

### 2️⃣ Relatórios - Gerar com IA

**O que é?** Relatórios são documentos profissionais gerados automaticamente pela IA baseados nos seus registros.

**Como Usar:**
1. Acesse **"Relatórios"** no menu
2. Selecione um registro na lista
3. Clique em **"Gerar Relatório com IA"**
4. Aguarde alguns segundos enquanto a IA processa
5. Visualize o relatório gerado
6. Clique no ícone de download para salvar em seu computador

**⚠️ Importante:** Antes de usar esta funcionalidade, configure sua chave de IA em **"Configurações IA"**.

**Relatórios Incluem:**
- Resumo executivo
- Análise situacional
- Inconformidades identificadas
- Recomendações
- Conclusão profissional

---

### 3️⃣ Unidades - Cadastrar Unidades de Saúde

**O que é?** Cadastro das Unidades de Saúde da Família que você gerencia.

**Como Usar:**
1. Clique em **"Unidades"** no menu
2. Clique em **"Nova Unidade"**
3. Preencha as informações:
   - Nome da unidade
   - Código CNES
   - Responsável
   - Telefone e email
   - Endereço
4. Clique em **"Salvar Unidade"**

---

### 4️⃣ Usuários - Gerenciar Acessos

**O que é?** Gerencie quem tem acesso ao sistema e qual é o nível de permissão.

**Como Usar:**
1. Clique em **"Usuários"** no menu
2. Clique em **"Novo Usuário"**
3. Preencha:
   - Nome completo
   - Email
   - Telefone
   - Nível de acesso (Operador, Gerente, Administrador)
4. Clique em **"Salvar Usuário"**

**Níveis de Acesso:**
- 👤 **Operador:** Pode criar e editar registros
- 👔 **Gerente:** Pode gerenciar registros, relatórios e unidades
- 🔑 **Administrador:** Acesso total ao sistema

---

### 5️⃣ Configurações IA - Ativar Geração de Relatórios

**O que é?** Aqui você configura qual provedor de IA usar para gerar relatórios.

**Como Usar:**

#### Passo 1: Escolher Provedor
Escolha um dos três provedores disponíveis:
- 🔍 **Perplexity** - Melhor para pesquisa em tempo real
- 🤖 **Claude** - Melhor para análise profunda
- ✨ **Gemini** - Rápido e eficiente

#### Passo 2: Obter Chave de API

**Para Perplexity:**
1. Acesse https://www.perplexity.ai/
2. Faça login ou crie conta
3. Vá em Configurações → Chaves de API
4. Crie uma nova chave e copie

**Para Claude:**
1. Acesse https://console.anthropic.com/
2. Faça login ou crie conta
3. Vá em API Keys
4. Crie uma nova chave e copie

**Para Gemini:**
1. Acesse https://ai.google.dev/
2. Clique em "Get API Key"
3. Crie um novo projeto
4. Gere uma chave e copie

#### Passo 3: Configurar no Sistema
1. Cole a chave no campo **"Chave de API"**
2. Selecione o modelo desejado
3. Clique em **"Salvar Configurações"**

✅ Pronto! Agora você pode gerar relatórios com IA.

---

## 💡 Dicas Importantes

### Para Gerar Melhores Relatórios
- ✅ Preencha **todos** os campos do registro
- ✅ Seja **específico** nas observações
- ✅ Liste **todas** as inconformidades encontradas
- ✅ Use linguagem **clara** e profissional

### Segurança
- 🔒 **Nunca** compartilhe sua chave de API
- 🔒 Se a chave vazar, regenere no site do provedor
- 🔒 Seus dados ficam apenas no seu navegador

### Backup
- 💾 Seus dados são salvos localmente
- 💾 Se limpar o navegador, os dados serão perdidos
- 💾 Faça download regular dos relatórios importantes

---

## ❓ Perguntas Frequentes

**P: Como faço backup dos meus dados?**
R: Baixe seus relatórios regularmente. Os dados são salvos no navegador, então recomenda-se fazer backups.

**P: Posso usar em outro computador?**
R: Não. Cada computador/navegador tem seus próprios dados. Para compartilhar, baixe os relatórios.

**P: O que acontece se eu limpar o navegador?**
R: Todos os dados serão perdidos. Certifique-se de fazer backup antes.

**P: Qual provedor de IA é melhor?**
R: Todos funcionam bem. Teste cada um e escolha o que preferir.

**P: Posso gerar relatórios sem configurar IA?**
R: Não. É necessário configurar uma chave de API primeiro.

---

## 🆘 Resolvendo Problemas

**Problema:** "Configurações de IA não encontradas"
- **Solução:** Acesse "Configurações IA" e configure uma chave de API

**Problema:** "Erro ao gerar relatório"
- **Solução:** Verifique se a chave de API está correta e tente novamente

**Problema:** Dados desapareceram
- **Solução:** Dados são salvos no navegador. Se limpou o navegador, foram perdidos.

**Problema:** Não consigo fazer login
- **Solução:** Use uma das credenciais de teste fornecidas

---

## 📱 Acessando em Diferentes Dispositivos

O sistema funciona em qualquer navegador moderno:
- ✅ Chrome / Edge
- ✅ Firefox
- ✅ Safari
- ✅ Dispositivos móveis

**Nota:** Cada dispositivo tem seus próprios dados. Para compartilhar, use os relatórios baixados.

---

## 🎯 Próximos Passos

1. ✅ Faça login com as credenciais fornecidas
2. ✅ Configure sua chave de IA em "Configurações IA"
3. ✅ Crie um novo registro de teste
4. ✅ Gere um relatório com IA
5. ✅ Explore todas as funcionalidades

---

## 📞 Precisa de Ajuda?

Consulte a documentação técnica completa em **LOGICA_IA_RELATORIOS.md** para detalhes sobre como o sistema funciona.

---

**Versão:** 1.0.0  
**Última Atualização:** Outubro 2025  
**Desenvolvido por:** Manus AI
