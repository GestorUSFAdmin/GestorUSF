# 🤖 Lógica de Geração de Relatórios com IA - Documentação Completa

## 📋 Visão Geral

O **GestorUSF** implementa um sistema completo e automático de geração de relatórios profissionais usando Inteligência Artificial. Este documento detalha como o sistema funciona, desde a seleção do registro até a exportação final do relatório.

---

## 🔄 Fluxo Completo de Geração

```
┌─────────────────────────────────────────────────────────────────┐
│                    FLUXO DE GERAÇÃO DE RELATÓRIOS                │
└─────────────────────────────────────────────────────────────────┘

1. Usuário seleciona um registro
   ↓
2. Sistema prepara os dados do registro
   ↓
3. Sistema constrói um prompt estruturado
   ↓
4. Prompt é enviado para a API de IA configurada
   ↓
5. IA processa e gera relatório profissional
   ↓
6. Sistema recebe e armazena o relatório
   ↓
7. Usuário visualiza, copia ou exporta o relatório
```

---

## 📊 Dados Coletados do Registro

Quando um usuário cria um registro de inspeção, os seguintes dados são coletados:

```typescript
interface Registro {
  id: string;                    // ID único do registro
  titulo: string;                // Ex: "Inspeção Mensal - USF Centro"
  data: string;                  // Data da inspeção (ISO 8601)
  unidade: string;               // Nome da unidade de saúde
  observacoes: string;           // Observações gerais
  inconformidades: string;       // Problemas encontrados
  criadoEm: string;              // Data de criação (ISO 8601)
  arquivos?: ArquivoAnexado[];   // Arquivos anexados (opcional)
}
```

### Exemplo de Dados Reais

```
Título: Inspeção Mensal - USF Centro
Data: 15/10/2025
Unidade: USF Centro Dr. José Marques
Observações: Inspeção realizada conforme protocolo. Equipe presente e equipamentos em funcionamento.
Inconformidades: Falta de álcool 70% em alguns consultórios. Geladeira de vacinas com temperatura inadequada.
```

---

## 🎯 Construção do Prompt para IA

O sistema constrói um prompt estruturado que inclui:

### 1. **Contexto do Especialista**
```
"Você é um especialista em gestão de saúde pública e auditoria de 
Unidades de Saúde da Família (USF)."
```

### 2. **Dados do Registro**
```
**DADOS DA INSPEÇÃO:**
- Título: [título do registro]
- Data: [data formatada]
- Unidade: [nome da unidade]
- Observações: [observações do inspetor]
- Inconformidades Encontradas: [lista de problemas]
```

### 3. **Instruções Estruturadas**
```
**INSTRUÇÕES PARA O RELATÓRIO:**
1. Crie um relatório com as seções:
   - RESUMO EXECUTIVO
   - DADOS DA INSPEÇÃO
   - ANÁLISE SITUACIONAL
   - INCONFORMIDADES IDENTIFICADAS
   - RECOMENDAÇÕES
   - CONCLUSÃO

2. Use linguagem formal e técnica
3. Seja objetivo nas recomendações
4. Formate de forma profissional
```

### Prompt Completo Enviado

```
Você é um especialista em gestão de saúde pública e auditoria de Unidades de Saúde da Família (USF).

Gere um relatório profissional e detalhado baseado nos seguintes dados de inspeção:

**DADOS DA INSPEÇÃO:**
- Título: Inspeção Mensal - USF Centro
- Data: 15/10/2025
- Unidade: USF Centro Dr. José Marques
- Observações: Inspeção realizada conforme protocolo. Equipe presente e equipamentos em funcionamento.
- Inconformidades Encontradas: Falta de álcool 70% em alguns consultórios. Geladeira de vacinas com temperatura inadequada.

**INSTRUÇÕES PARA O RELATÓRIO:**
1. Crie um relatório estruturado com as seguintes seções:
   - RESUMO EXECUTIVO (2-3 linhas)
   - DADOS DA INSPEÇÃO (listar todos os dados)
   - ANÁLISE SITUACIONAL (análise dos dados coletados)
   - INCONFORMIDADES IDENTIFICADAS (listar cada uma com detalhes)
   - RECOMENDAÇÕES (ações corretivas sugeridas)
   - CONCLUSÃO

2. Use linguagem formal e técnica apropriada para documentos oficiais
3. Seja objetivo e claro nas recomendações
4. Formate o relatório de forma profissional e legível

Gere o relatório completo agora:
```

---

## 🌐 Provedores de IA Suportados

### 1. **Perplexity** 🔍
**Características:**
- Pesquisa em tempo real
- Acesso a informações atualizadas
- Modelos: `sonar-pro`, `sonar`

**Endpoint:** `https://api.perplexity.ai/chat/completions`

**Exemplo de Requisição:**
```json
{
  "model": "sonar-pro",
  "messages": [
    {
      "role": "user",
      "content": "[prompt do relatório]"
    }
  ],
  "temperature": 0.7,
  "max_tokens": 2000
}
```

### 2. **Claude (Anthropic)** 🤖
**Características:**
- IA avançada e precisa
- Excelente compreensão de contexto
- Modelos: `claude-3-opus`, `claude-3-sonnet`, `claude-3-haiku`

**Endpoint:** `https://api.anthropic.com/v1/messages`

**Exemplo de Requisição:**
```json
{
  "model": "claude-3-opus-20240229",
  "max_tokens": 2000,
  "messages": [
    {
      "role": "user",
      "content": "[prompt do relatório]"
    }
  ]
}
```

### 3. **Google Gemini** ✨
**Características:**
- IA rápida e eficiente
- Multimodal (texto, imagem)
- Modelos: `gemini-2.5-flash`, `gemini-1.5-pro`, `gemini-1.5-flash`

**Endpoint:** `https://generativelanguage.googleapis.com/v1beta/models/{modelo}:generateContent`

**Exemplo de Requisição:**
```json
{
  "contents": [
    {
      "parts": [
        {
          "text": "[prompt do relatório]"
        }
      ]
    }
  ],
  "generationConfig": {
    "temperature": 0.7,
    "maxOutputTokens": 2000
  }
}
```

---

## 🔐 Fluxo de Autenticação com API

### Perplexity
```typescript
headers: {
  "Content-Type": "application/json",
  "Authorization": "Bearer {API_KEY}"
}
```

### Claude
```typescript
headers: {
  "Content-Type": "application/json",
  "x-api-key": "{API_KEY}",
  "anthropic-version": "2023-06-01"
}
```

### Gemini
```typescript
// A chave é incluída na URL
https://generativelanguage.googleapis.com/v1beta/models/{modelo}:generateContent?key={API_KEY}
```

---

## 📝 Processamento da Resposta

Após receber a resposta da IA, o sistema:

### 1. **Valida a Resposta**
```typescript
if (!response.ok) {
  throw new Error(`Erro na API: ${response.statusText}`);
}
```

### 2. **Extrai o Conteúdo**
```typescript
// Perplexity e Claude
const conteudo = data.choices[0].message.content;

// Gemini
const conteudo = data.candidates[0].content.parts[0].text;
```

### 3. **Armazena no Sistema**
```typescript
const novoRelatorio: Relatorio = {
  id: `rel_${Date.now()}`,
  titulo: `Relatório IA - ${registro.titulo}`,
  conteudo: conteudoGerado,
  registroId: registro.id,
  criadoEm: new Date().toISOString(),
  tipo: "ia"
};

localStorage.setItem("relatorios", JSON.stringify([novoRelatorio, ...relatorios]));
```

---

## 💾 Armazenamento de Dados

Todos os dados são armazenados no **localStorage** do navegador:

```typescript
// Registros
localStorage.setItem("registros", JSON.stringify(registros));

// Relatórios
localStorage.setItem("relatorios", JSON.stringify(relatorios));

// Configurações de IA
localStorage.setItem("configIA", JSON.stringify(config));

// Unidades
localStorage.setItem("unidades", JSON.stringify(unidades));

// Usuários
localStorage.setItem("usuarios", JSON.stringify(usuarios));
```

### Limite de Armazenamento
- **Limite padrão:** ~5-10 MB por domínio
- **Formato:** JSON
- **Persistência:** Até que o usuário limpe o cache do navegador

---

## 📤 Exportação em Múltiplos Formatos

### 1. **TXT (Texto Simples)**
```typescript
const tipo = "text/plain";
const extensao = "txt";
const conteudo = relatorio.conteudo;
```

**Resultado:** Arquivo de texto puro, compatível com qualquer editor

### 2. **HTML (Página Web)**
```typescript
const tipo = "text/html";
const extensao = "html";
const conteudo = `
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>${relatorio.titulo}</title>
  <style>
    body { font-family: Arial, sans-serif; line-height: 1.6; }
    .header { border-bottom: 3px solid #2ecc71; padding-bottom: 20px; }
  </style>
</head>
<body>
  <div class="header">
    <h1>🏥 GestorUSF - Relatório</h1>
    <p>${relatorio.titulo}</p>
  </div>
  <div class="content">${relatorio.conteudo}</div>
</body>
</html>
`;
```

**Resultado:** Página web formatada, aberta no navegador

### 3. **JSON (Formato Estruturado)**
```typescript
const tipo = "application/json";
const extensao = "json";
const conteudo = JSON.stringify(relatorio, null, 2);
```

**Resultado:**
```json
{
  "id": "rel_1728924000000",
  "titulo": "Relatório IA - Inspeção Mensal",
  "conteudo": "RESUMO EXECUTIVO...",
  "registroId": "reg_1728923000000",
  "criadoEm": "2025-10-15T14:00:00.000Z",
  "tipo": "ia"
}
```

---

## ⚠️ Tratamento de Erros

O sistema implementa tratamento robusto de erros:

### 1. **Erro de Configuração**
```typescript
if (!configIA) {
  throw new Error("Configurações de IA não encontradas. Configure em Configurações IA.");
}
```

### 2. **Erro de Conexão**
```typescript
if (!response.ok) {
  throw new Error(`Erro na API ${provider}: ${response.statusText}`);
}
```

### 3. **Erro de Chave de API**
```typescript
if (!apiKey) {
  throw new Error("Chave de API não configurada");
}
```

### 4. **Erro de Parsing**
```typescript
try {
  const data = await response.json();
} catch (error) {
  throw new Error("Erro ao processar resposta da IA");
}
```

---

## 🧪 Teste de Conexão com API

Antes de usar a API, o usuário pode testar a conexão:

```typescript
const testarConexao = async () => {
  // Envia um prompt simples
  const response = await fetch(apiEndpoint, {
    method: "POST",
    headers: {...},
    body: JSON.stringify({
      messages: [{
        role: "user",
        content: "Teste de conexão. Responda com OK."
      }],
      max_tokens: 10
    })
  });

  if (response.ok) {
    toast.success("Conexão estabelecida com sucesso!");
  } else {
    toast.error("Erro na conexão. Verifique sua chave de API.");
  }
};
```

---

## 📊 Exemplo Completo de Relatório Gerado

```
RESUMO EXECUTIVO
A inspeção realizada na USF Centro Dr. José Marques em 15 de outubro de 2025 
identificou duas inconformidades críticas relacionadas a controle de infecção e 
manutenção de insumos. A unidade apresenta estrutura adequada e equipe presente, 
porém requer ações corretivas imediatas.

DADOS DA INSPEÇÃO
- Título: Inspeção Mensal - USF Centro
- Data: 15/10/2025
- Unidade: USF Centro Dr. José Marques
- Observações: Inspeção realizada conforme protocolo. Equipe presente e equipamentos em funcionamento.
- Inconformidades Encontradas: Falta de álcool 70% em alguns consultórios. Geladeira de vacinas com temperatura inadequada.

ANÁLISE SITUACIONAL
A unidade de saúde apresenta infraestrutura adequada com equipe presente durante 
a inspeção. Os equipamentos estão em funcionamento e a rotina de atendimento 
segue o protocolo estabelecido.

INCONFORMIDADES IDENTIFICADAS
1. Falta de álcool 70% em alguns consultórios
   - Risco: Contaminação e infecção cruzada
   - Prioridade: ALTA
   - Norma: RDC 42/2010 (Boas Práticas de Farmácia)

2. Geladeira de vacinas com temperatura inadequada
   - Risco: Perda de potência vacinal
   - Prioridade: CRÍTICA
   - Norma: Portaria 597/2004 (Controle de Temperatura de Vacinas)

RECOMENDAÇÕES
1. Providenciar reabastecimento imediato de álcool 70% em todos os consultórios
2. Realizar manutenção preventiva da geladeira de vacinas
3. Implementar sistema de monitoramento de temperatura com alarme
4. Realizar treinamento de equipe sobre controle de infecção
5. Estabelecer cronograma mensal de verificação de insumos críticos

CONCLUSÃO
A unidade requer ações corretivas imediatas, especialmente relacionadas ao 
controle de temperatura de vacinas. Recomenda-se acompanhamento em 15 dias 
para verificação do cumprimento das recomendações.
```

---

## 🔄 Backup e Restore

O sistema permite fazer backup completo de todos os relatórios gerados:

```typescript
const backup = {
  timestamp: new Date().toISOString(),
  versao: "1.0",
  dados: {
    registros: localStorage.getItem("registros"),
    relatorios: localStorage.getItem("relatorios"),
    unidades: localStorage.getItem("unidades"),
    usuarios: localStorage.getItem("usuarios"),
    configIA: localStorage.getItem("configIA")
  }
};
```

**Arquivo de Backup:**
```json
{
  "timestamp": "2025-10-15T14:30:00.000Z",
  "versao": "1.0",
  "dados": {
    "registros": "[...]",
    "relatorios": "[...]",
    "unidades": "[...]",
    "usuarios": "[...]",
    "configIA": "{\"provider\":\"perplexity\",\"apiKey\":\"***\",\"modelo\":\"sonar-pro\"}"
  }
}
```

---

## 🚀 Melhorias Futuras

1. **Integração com Pesquisa Web**
   - Adicionar fundamentação legal automática
   - Buscar normas do SUS relevantes
   - Citar portarias e regulamentos

2. **Geração de PDF**
   - Usar biblioteca `jsPDF`
   - Incluir assinatura digital
   - Adicionar código de barras

3. **Geração de DOCX**
   - Usar biblioteca `docx`
   - Formatação profissional
   - Cabeçalho e rodapé

4. **Geração de XLSX**
   - Usar biblioteca `xlsx`
   - Tabelas estruturadas
   - Gráficos e análises

5. **Integração com Banco de Dados**
   - Migrar de localStorage para PostgreSQL/MongoDB
   - Sincronização em nuvem
   - Acesso multi-dispositivo

6. **Análise de Sentimento**
   - Detectar tom dos relatórios
   - Sugerir melhorias de linguagem
   - Validar conformidade com padrões

---

## 📞 Suporte e Troubleshooting

### Problema: "Configurações de IA não encontradas"
**Solução:** Acesse "Configurações IA" e configure uma chave de API

### Problema: "Erro na API"
**Solução:** Verifique sua conexão de internet e chave de API

### Problema: "Relatório não foi salvo"
**Solução:** Verifique se o localStorage não está cheio (limite ~5-10 MB)

### Problema: "Arquivo não baixa"
**Solução:** Verifique as configurações de bloqueador de pop-ups do navegador

---

## 📚 Referências

- [Perplexity API Docs](https://docs.perplexity.ai/)
- [Anthropic Claude API Docs](https://docs.anthropic.com/)
- [Google Gemini API Docs](https://ai.google.dev/gemini-api/docs)
- [Portaria 597/2004 - Vacinas](http://bvsms.saude.gov.br/)
- [RDC 42/2010 - Boas Práticas de Farmácia](http://www.anvisa.gov.br/)

---

**Versão:** 1.0  
**Última Atualização:** Outubro 2025  
**Autor:** GestorUSF Development Team
