# 📖 Manual Completo do Usuário - GestorUSF

## Índice
1. [Introdução](#introdução)
2. [Começando](#começando)
3. [Dashboard](#dashboard)
4. [Registros](#registros)
5. [Relatórios](#relatórios)
6. [Unidades](#unidades)
7. [Usuários](#usuários)
8. [Configurações de IA](#configurações-de-ia)
9. [Dicas e Truques](#dicas-e-truques)
10. [Suporte](#suporte)

---

## Introdução

**GestorUSF** é um sistema completo de gestão para Unidades de Saúde da Família (USFs). Ele permite que você:

- ✅ Registre inspeções e observações
- ✅ Gere relatórios automaticamente com IA
- ✅ Gerencie unidades e usuários
- ✅ Analise dados com gráficos e estatísticas
- ✅ Faça backup e restaure seus dados

---

## Começando

### Primeiro Acesso

1. **Abra o aplicativo** em seu navegador
2. **Faça login** com suas credenciais
3. **Veja o tour interativo** (opcional) para conhecer as funcionalidades

### Navegação

A navegação é feita através da **barra lateral**:

- **Dashboard**: Visão geral do sistema
- **Registros**: Criar e gerenciar inspeções
- **Relatórios**: Gerar relatórios com IA
- **Unidades**: Cadastrar USFs
- **Usuários**: Gerenciar usuários (Admin)
- **Configurações IA**: Configurar provedoras de IA

### Busca Global (Cmd+K)

Pressione **Cmd+K** (Mac) ou **Ctrl+K** (Windows) para abrir a busca global e encontrar rapidamente:
- Registros
- Relatórios
- Páginas
- Unidades

---

## Dashboard

O **Dashboard** mostra uma visão geral do seu sistema com:

### KPIs (Indicadores-Chave)

- **Taxa de Conformidade**: Percentual de registros sem inconformidades
- **Tempo Médio de Resolução**: Dias médios para resolver problemas
- **Inconformidades**: Total de problemas identificados
- **Registros Ativos**: Total de inspeções registradas

### Gráficos

- **Distribuição por Unidade**: Quantos registros cada USF tem
- **Estatísticas Gerais**: Resumo de dados do sistema

### Atividades Recentes

Veja os últimos registros e relatórios criados.

### Ações Rápidas

Botões para criar rapidamente:
- Novo Registro
- Novo Relatório
- Nova Unidade
- Novo Usuário

---

## Registros

### Criar um Novo Registro

1. Clique em **"+ Novo Registro"** no Dashboard ou vá para **Registros**
2. Preencha os campos:
   - **Título**: Nome da inspeção (ex: "Inspeção Mensal - Setembro")
   - **Data**: Data da inspeção
   - **Unidade**: Selecione a USF (dropdown)
   - **Observações**: Detalhes da inspeção
   - **Inconformidades**: Problemas encontrados
3. **Anexe arquivos** (fotos, documentos, etc.)
4. Clique em **"Salvar"**

### Anexar Arquivos

1. Na seção "Arquivos Anexados", clique em **"Escolher Arquivo"**
2. Selecione o arquivo desejado
3. O arquivo será adicionado automaticamente
4. Você pode **baixar** ou **remover** arquivos anexados

### Editar Registro

1. Clique no registro na lista
2. Modifique os campos desejados
3. Clique em **"Atualizar"**

### Deletar Registro

1. Clique no registro
2. Clique em **"Deletar"**
3. Confirme a ação

---

## Relatórios

### Gerar um Relatório com IA

#### Opção 1: Por Registro Específico

1. Vá para **Relatórios**
2. Selecione um **Registro** no dropdown
3. Escolha uma **Provedora de IA** (Perplexity, Claude, Gemini, etc.)
4. Marque **"Incluir Anexos"** se desejar
5. Clique em **"Gerar Relatório"**
6. Aguarde a geração (pode levar alguns segundos)

#### Opção 2: Por Unidade (Agregado)

1. Vá para **Relatórios**
2. Selecione uma **Unidade** no dropdown
3. O sistema agregará **todos os registros** dessa unidade
4. Escolha uma **Provedora de IA**
5. Clique em **"Gerar Relatório"**

### Visualizar Relatório

Após a geração, uma **janela flutuante** abrirá com o relatório.

#### Controles de Visualização

- **Zoom In/Out**: Aumentar ou diminuir o tamanho do texto
- **Resetar Zoom**: Voltar ao tamanho original (100%)
- **Modo Leitura**: Modo sem distrações com fundo bege
- **Imprimir**: Abrir diálogo de impressão
- **Copiar**: Copiar todo o relatório
- **Baixar TXT**: Baixar como arquivo de texto

#### Copiar Texto

1. **Selecione o texto** que deseja copiar
2. Um botão **"Copiar Seleção"** aparecerá
3. Clique para copiar para a área de transferência

### Exportar Relatório

Na janela do relatório, clique em:
- **TXT**: Baixa como arquivo de texto
- **PDF**: Baixa como PDF (requer configuração adicional)
- **DOCX**: Baixa como Word (requer configuração adicional)

---

## Unidades

### Cadastrar uma Nova Unidade

1. Vá para **Unidades**
2. Clique em **"+ Nova Unidade"**
3. Preencha:
   - **Nome**: Nome da USF
   - **Endereço**: Localização
   - **Telefone**: Contato
   - **Responsável**: Pessoa responsável
4. Clique em **"Salvar"**

### Editar Unidade

1. Clique na unidade na lista
2. Modifique os campos
3. Clique em **"Atualizar"**

### Deletar Unidade

1. Clique na unidade
2. Clique em **"Deletar"**
3. Confirme

---

## Usuários

### Cadastrar Novo Usuário (Admin)

1. Vá para **Usuários**
2. Clique em **"+ Novo Usuário"**
3. Preencha:
   - **Nome**: Nome completo
   - **Email**: Email do usuário
   - **Nível**: Administrador, Gerente ou Operador
4. Clique em **"Salvar"**

### Níveis de Acesso

- **Administrador**: Acesso total, pode gerenciar usuários
- **Gerente**: Pode criar registros e relatórios
- **Operador**: Pode visualizar e criar registros básicos

### Editar Usuário

1. Clique no usuário
2. Modifique os campos
3. Clique em **"Atualizar"**

### Deletar Usuário

1. Clique no usuário
2. Clique em **"Deletar"**
3. Confirme

---

## Configurações de IA

### Adicionar Chave de API

1. Vá para **Configurações IA**
2. Selecione uma **Provedora**:
   - Perplexity
   - Claude (Anthropic)
   - Google Gemini
   - ChatGPT (OpenAI)
   - Cohere
   - OpenRouter

3. Clique no **link azul** para ir ao site da provedora
4. Gere sua **chave de API**
5. Cole a chave no campo
6. Clique em **"Testar Conexão"**
7. Se OK, clique em **"Salvar"**

### Testar Conexão

Antes de usar uma chave:

1. Preencha o campo com a chave
2. Clique em **"Testar Conexão"**
3. Aguarde a validação
4. Se passar, você verá uma mensagem de sucesso

### Obter Chaves de API

Clique nos links azuis para ir aos sites:

- **Perplexity**: https://www.perplexity.ai/api
- **Claude**: https://console.anthropic.com
- **Gemini**: https://ai.google.dev
- **ChatGPT**: https://platform.openai.com
- **Cohere**: https://dashboard.cohere.ai
- **OpenRouter**: https://openrouter.ai

---

## Backup e Restauração

### Fazer Backup

1. No Dashboard, clique em **"Backup"**
2. Um arquivo JSON será baixado
3. **Salve em local seguro**

### Restaurar Backup

1. No Dashboard, clique em **"Restaurar"**
2. Selecione o arquivo JSON de backup
3. Confirme a restauração
4. O sistema será recarregado com os dados

---

## Dicas e Truques

### 🎯 Atalhos de Teclado

| Atalho | Ação |
|--------|------|
| Cmd+K / Ctrl+K | Abrir busca global |
| Esc | Fechar modais |
| Enter | Confirmar ações |

### 💡 Boas Práticas

1. **Faça backup regularmente** - Proteja seus dados
2. **Use títulos descritivos** - Facilita a busca depois
3. **Anexe evidências** - Fotos e documentos comprovam
4. **Revise antes de gerar** - Verifique os dados
5. **Teste as IAs** - Escolha a que funciona melhor para você

### 📱 Em Dispositivos Móveis

- Clique no **botão flutuante** (canto inferior direito) para abrir o menu
- Use a **busca global** para navegar rapidamente
- O **modo leitura** é ideal para ler relatórios

### 🔍 Buscando Registros

1. Pressione **Cmd+K** ou **Ctrl+K**
2. Digite o **título**, **unidade** ou **data**
3. Clique no resultado para ir direto

---

## Suporte

### Problemas Comuns

**P: Não consigo fazer login**
R: Verifique seu email e senha. Contate o administrador se esquecer.

**P: A IA não gera relatório**
R: Verifique se a chave de API está correta. Teste a conexão nas configurações.

**P: Meus dados sumiram**
R: Restaure a partir de um backup anterior.

**P: Como faço para mudar minha senha?**
R: Entre em contato com o administrador do sistema.

### Contato

Para dúvidas ou problemas:
- Contate o **administrador do sistema**
- Consulte a documentação técnica
- Verifique o **tour interativo** (primeira visita)

---

## Glossário

- **USF**: Unidade de Saúde da Família
- **IA**: Inteligência Artificial
- **API**: Interface de Programação de Aplicações
- **Backup**: Cópia de segurança dos dados
- **KPI**: Indicador-Chave de Desempenho
- **Inconformidade**: Problema ou não-conformidade encontrada

---

## Versão

**GestorUSF v3.0**
Última atualização: Novembro 2025

---

**Obrigado por usar GestorUSF! 🏥**
