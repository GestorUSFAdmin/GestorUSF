# 💻 Guia de Instalação Local - GestorUSF Simplificado

## Visão Geral

Este documento fornece instruções para instalar e executar o **GestorUSF Simplificado** em sua máquina local para desenvolvimento ou testes.

---

## 📋 Pré-requisitos

Antes de começar, certifique-se de ter instalado:

1. **Node.js** (v16 ou superior)
   - Download: https://nodejs.org/
   - Verificar instalação: `node --version`

2. **pnpm** (gerenciador de pacotes)
   - Instalação: `npm install -g pnpm`
   - Verificar instalação: `pnpm --version`

3. **Git** (opcional, para clonar repositório)
   - Download: https://git-scm.com/
   - Verificar instalação: `git --version`

---

## 🚀 Passo 1: Obter o Código

### Opção A: Clonar do GitHub

```bash
# Clonar o repositório
git clone https://github.com/USERNAME/GestorUSF-Simplificado.git

# Navegar para o diretório
cd GestorUSF-Simplificado
```

### Opção B: Extrair arquivo ZIP

```bash
# Extrair o arquivo
unzip GestorUSF-Simplificado.zip

# Navegar para o diretório
cd GestorUSF-Simplificado
```

---

## 📦 Passo 2: Instalar Dependências

```bash
# Instalar todas as dependências
pnpm install

# Ou se preferir usar npm
npm install

# Ou se preferir usar yarn
yarn install
```

**Tempo estimado**: 2-5 minutos (depende da velocidade da internet)

---

## 🏃 Passo 3: Executar em Desenvolvimento

### Iniciar servidor de desenvolvimento

```bash
# Com pnpm (recomendado)
pnpm dev

# Ou com npm
npm run dev

# Ou com yarn
yarn dev
```

**Saída esperada**:
```
  ➜  Local:   http://localhost:3000/
  ➜  Network: http://192.168.x.x:3000/
```

### Acessar a aplicação

Abra seu navegador e acesse: **http://localhost:3000**

---

## 🔐 Passo 4: Fazer Login

Use uma das credenciais de teste:

| Perfil | Email | Senha |
|--------|-------|-------|
| Admin | admin@gestorUSF.com | 123 |
| Gerente | maria@gestorUSF.com | 456 |
| Operador | joao@gestorUSF.com | 789 |

---

## 🧪 Passo 5: Testar Funcionalidades

### Dashboard
- [ ] Visualizar gráficos e estatísticas
- [ ] Verificar totais de registros, inconformidades, unidades

### Registros
- [ ] Criar novo registro
- [ ] Selecionar unidade do dropdown
- [ ] Upload de arquivos
- [ ] Editar registro
- [ ] Deletar registro

### Relatórios
- [ ] Gerar relatório com IA
- [ ] Exportar em TXT, HTML, JSON
- [ ] Exportar em DOCX, PDF
- [ ] Copiar conteúdo para clipboard

### Configurações
- [ ] Configurar chave de API de IA
- [ ] Testar conexão com API
- [ ] Fazer backup de dados
- [ ] Restaurar dados do backup

---

## 🔨 Passo 6: Compilar para Produção

### Build da aplicação

```bash
# Com pnpm
pnpm build

# Ou com npm
npm run build

# Ou com yarn
yarn build
```

**Saída esperada**:
```
dist/
├── index.html
├── assets/
│   ├── index-xxxxx.js
│   └── index-xxxxx.css
└── ...
```

### Visualizar build localmente

```bash
# Com pnpm
pnpm preview

# Ou com npm
npm run preview

# Ou com yarn
yarn preview
```

Acesse: **http://localhost:4173**

---

## 📁 Estrutura do Projeto

```
GestorUSF-Simplificado/
├── client/                          # Código frontend
│   ├── public/                      # Assets estáticos
│   │   ├── favicon.ico
│   │   └── ...
│   ├── src/
│   │   ├── pages/                   # Páginas da aplicação
│   │   │   ├── LoginPage.tsx
│   │   │   ├── DashboardPage.tsx
│   │   │   ├── RegistrosPage.tsx
│   │   │   ├── RelatoriosPage.tsx
│   │   │   ├── CadastroUnidadePage.tsx
│   │   │   ├── CadastroUsuarioPage.tsx
│   │   │   └── ConfiguracoesIAPage.tsx
│   │   ├── components/              # Componentes reutilizáveis
│   │   ├── contexts/                # React Contexts
│   │   │   └── AuthContext.tsx
│   │   ├── lib/                     # Funções utilitárias
│   │   ├── App.tsx                  # Componente raiz
│   │   ├── main.tsx                 # Entry point
│   │   └── index.css                # Estilos globais
│   ├── index.html                   # HTML template
│   └── package.json
├── server/                          # Placeholder para backend
├── shared/                          # Código compartilhado
├── package.json                     # Dependências do projeto
├── pnpm-lock.yaml                   # Lock file do pnpm
├── tsconfig.json                    # Configuração TypeScript
├── vite.config.ts                   # Configuração Vite
├── tailwind.config.ts               # Configuração Tailwind
├── netlify.toml                     # Configuração Netlify
├── .gitignore                       # Arquivos ignorados pelo Git
├── README.md                        # Documentação principal
├── INSTALLATION.md                  # Este arquivo
├── DEPLOY_GUIDE.md                  # Guia de publicação
├── LOGICA_IA_RELATORIOS_DETALHADA.md  # Documentação de IA
└── todo.md                          # Lista de funcionalidades
```

---

## 🔧 Comandos Úteis

```bash
# Instalar dependências
pnpm install

# Iniciar desenvolvimento
pnpm dev

# Build para produção
pnpm build

# Visualizar build
pnpm preview

# Lint do código (se configurado)
pnpm lint

# Formatar código (se configurado)
pnpm format

# Executar testes (se configurado)
pnpm test
```

---

## 🌍 Variáveis de Ambiente

Crie um arquivo `.env.local` na raiz do projeto para configurar variáveis:

```env
# Título da aplicação
VITE_APP_TITLE=GestorUSF

# Logo da aplicação
VITE_APP_LOGO=/logo.svg

# Endpoint de analytics (opcional)
VITE_ANALYTICS_ENDPOINT=

# ID do website para analytics (opcional)
VITE_ANALYTICS_WEBSITE_ID=
```

---

## 🐛 Troubleshooting

### Problema: "pnpm: command not found"

**Solução**:
```bash
# Instalar pnpm globalmente
npm install -g pnpm

# Verificar instalação
pnpm --version
```

### Problema: "Port 3000 is already in use"

**Solução**:
```bash
# Usar porta diferente
pnpm dev -- --port 3001
```

### Problema: Módulos não encontrados

**Solução**:
```bash
# Limpar cache e reinstalar
rm -rf node_modules pnpm-lock.yaml
pnpm install
```

### Problema: Erro de compilação TypeScript

**Solução**:
1. Verifique se há erros de sintaxe
2. Limpe o cache: `rm -rf dist`
3. Reinstale dependências: `pnpm install`

### Problema: Dados não persistem após refresh

**Solução**:
- Este é o comportamento esperado (dados em localStorage)
- Use a função de **Backup** para preservar dados
- Dados serão mantidos enquanto o cache do navegador não for limpo

---

## 📊 Monitoramento em Desenvolvimento

### DevTools do Navegador

1. Abra **F12** ou **Ctrl+Shift+I**
2. Acesse a aba **Console** para ver logs
3. Acesse a aba **Application** → **Local Storage** para ver dados armazenados

### React DevTools

Instale a extensão React DevTools no seu navegador para melhor debugging.

---

## 🚀 Próximos Passos

Após testar localmente:

1. **Fazer commit do código**:
   ```bash
   git add .
   git commit -m "Teste local completo"
   git push origin main
   ```

2. **Publicar no Netlify**: Veja `DEPLOY_GUIDE.md`

3. **Configurar domínio customizado**: Veja `DEPLOY_GUIDE.md`

---

## 📚 Recursos Adicionais

- **Documentação Vite**: https://vitejs.dev
- **Documentação React**: https://react.dev
- **Documentação Tailwind**: https://tailwindcss.com
- **Documentação shadcn/ui**: https://ui.shadcn.com

---

## 📞 Suporte

Para problemas ou dúvidas:

1. Verifique o `README.md` para visão geral
2. Consulte `LOGICA_IA_RELATORIOS_DETALHADA.md` para IA
3. Abra uma issue no GitHub

---

**Versão**: 1.0  
**Última Atualização**: Outubro 2025  
**Autor**: GestorUSF Development Team
