import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { AuthProvider, useAuth } from "./contexts/AuthContext";
import Sidebar from "./components/Sidebar";
import TopBar from "./components/TopBar";
import OnboardingTour from "./components/OnboardingTour";
import LoginPage from "./pages/LoginPage";
import DashboardPage from "./pages/DashboardPage";
import RegistrosPage from "./pages/RegistrosPage";
import RelatoriosPage from "./pages/RelatoriosPage";
import CadastroUnidadePage from "./pages/CadastroUnidadePage";
import CadastroUsuarioPage from "./pages/CadastroUsuarioPage";
import ConfiguracoesIAPage from "./pages/ConfiguracoesIAPage";

function Router() {
  const { user } = useAuth();

  // Se não está autenticado, mostrar apenas login
  if (!user) {
    return (
      <Switch>
        <Route path="/login" component={LoginPage} />
        <Route component={LoginPage} />
      </Switch>
    );
  }

  // Se está autenticado, mostrar sidebar + conteúdo
  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex-1 flex flex-col">
        <TopBar />
        <main className="flex-1">
          <Switch>
            <Route path="/" component={DashboardPage} />
            <Route path="/registros" component={RegistrosPage} />
            <Route path="/relatorios" component={RelatoriosPage} />
            <Route path="/unidades" component={CadastroUnidadePage} />
            <Route path="/usuarios" component={CadastroUsuarioPage} />
            <Route path="/config-ia" component={ConfiguracoesIAPage} />
            <Route path="/404" component={NotFound} />
            <Route component={NotFound} />
          </Switch>
        </main>
      </div>
      <OnboardingTour />
    </div>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        // switchable
      >
        <AuthProvider>
          <TooltipProvider>
            <Toaster />
            <Router />
          </TooltipProvider>
        </AuthProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
