import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useLocation } from "wouter";
import { ArrowLeft, Save, Eye, EyeOff, Zap, Loader2, ExternalLink } from "lucide-react";
import { toast } from "sonner";

interface ConfigIA {
  provider: "perplexity" | "claude" | "gemini" | "openai" | "cohere" | "openrouter";
  apiKey: string;
  modelo: string;
}

const PROVIDERS_INFO: Record<string, { nome: string; url: string; docs: string; descricao: string }> = {
  perplexity: {
    nome: "Perplexity AI",
    url: "https://www.perplexity.ai/",
    docs: "https://docs.perplexity.ai/getting-started/quickstart",
    descricao: "IA com busca em tempo real na web",
  },
  claude: {
    nome: "Claude (Anthropic)",
    url: "https://claude.ai/",
    docs: "https://docs.anthropic.com/en/home",
    descricao: "IA avançada com raciocínio profundo",
  },
  gemini: {
    nome: "Google Gemini",
    url: "https://gemini.google.com/",
    docs: "https://ai.google.dev/gemini-api/docs",
    descricao: "IA multimodal do Google",
  },
  openai: {
    nome: "OpenAI (ChatGPT)",
    url: "https://openai.com/",
    docs: "https://platform.openai.com/docs/api-reference",
    descricao: "ChatGPT e GPT-4 da OpenAI",
  },
  cohere: {
    nome: "Cohere",
    url: "https://cohere.ai/",
    docs: "https://docs.cohere.com/",
    descricao: "IA para processamento de linguagem natural",
  },
  openrouter: {
    nome: "OpenRouter",
    url: "https://openrouter.ai/",
    docs: "https://openrouter.ai/docs/api-reference",
    descricao: "Acesso unificado a múltiplas IAs",
  },
};

const MODELOS: Record<string, string[]> = {
  perplexity: ["sonar-pro", "sonar"],
  claude: [
    "claude-3-opus-20240229",
    "claude-3-sonnet-20240229",
    "claude-3-haiku-20240307",
  ],
  gemini: ["gemini-2.5-flash", "gemini-1.5-pro", "gemini-1.5-flash"],
  openai: ["gpt-4", "gpt-4-turbo", "gpt-3.5-turbo"],
  cohere: ["command-r-plus", "command-r", "command"],
  openrouter: ["openai/gpt-4", "anthropic/claude-3-opus", "google/gemini-pro"],
};

export default function ConfiguracoesIAPage() {
  const [config, setConfig] = useState<ConfigIA>({
    provider: "perplexity",
    apiKey: "",
    modelo: "",
  });
  const [showKey, setShowKey] = useState(false);
  const [, navigate] = useLocation();
  const [testando, setTestando] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem("configIA");
    if (saved) {
      try {
        setConfig(JSON.parse(saved));
      } catch (e) {
        console.error("Erro ao carregar configurações:", e);
      }
    }
  }, []);

  const handleSave = () => {
    if (!config.apiKey) {
      toast.error("Chave de API é obrigatória!");
      return;
    }

    localStorage.setItem("configIA", JSON.stringify(config));
    toast.success("Configurações salvas com sucesso!");
  };

  const handleReset = () => {
    if (confirm("Tem certeza que deseja remover as configurações?")) {
      localStorage.removeItem("configIA");
      setConfig({
        provider: "perplexity",
        apiKey: "",
        modelo: "",
      });
      toast.success("Configurações removidas!");
    }
  };

  const testarConexao = async () => {
    if (!config.apiKey) {
      toast.error("Configure uma chave de API primeiro!");
      return;
    }

    setTestando(true);
    try {
      let response;
      let sucesso = false;

      if (config.provider === "perplexity") {
        response = await fetch("https://api.perplexity.ai/chat/completions", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${config.apiKey}`,
          },
          body: JSON.stringify({
            model: config.modelo || "sonar-pro",
            messages: [
              {
                role: "user",
                content: "Teste de conexão. Responda com OK.",
              },
            ],
            max_tokens: 10,
          }),
        });
        sucesso = response.ok;
      } else if (config.provider === "claude") {
        response = await fetch("https://api.anthropic.com/v1/messages", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-api-key": config.apiKey,
            "anthropic-version": "2023-06-01",
          },
          body: JSON.stringify({
            model: config.modelo || "claude-3-opus-20240229",
            max_tokens: 10,
            messages: [
              {
                role: "user",
                content: "Teste de conexão. Responda com OK.",
              },
            ],
          }),
        });
        sucesso = response.ok;
      } else if (config.provider === "gemini") {
        response = await fetch(
          `https://generativelanguage.googleapis.com/v1beta/models/${config.modelo || "gemini-2.5-flash"}:generateContent?key=${config.apiKey}`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              contents: [
                {
                  parts: [
                    {
                      text: "Teste de conexão. Responda com OK.",
                    },
                  ],
                },
              ],
            }),
          }
        );
        sucesso = response.ok;
      } else if (config.provider === "openai") {
        response = await fetch("https://api.openai.com/v1/chat/completions", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${config.apiKey}`,
          },
          body: JSON.stringify({
            model: config.modelo || "gpt-3.5-turbo",
            messages: [
              {
                role: "user",
                content: "Teste de conexão. Responda com OK.",
              },
            ],
            max_tokens: 10,
          }),
        });
        sucesso = response.ok;
      } else if (config.provider === "cohere") {
        response = await fetch("https://api.cohere.ai/v2/chat", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${config.apiKey}`,
          },
          body: JSON.stringify({
            model: config.modelo || "command-r",
            messages: [
              {
                role: "user",
                content: "Teste de conexão. Responda com OK.",
              },
            ],
          }),
        });
        sucesso = response.ok;
      } else if (config.provider === "openrouter") {
        response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${config.apiKey}`,
          },
          body: JSON.stringify({
            model: config.modelo || "openai/gpt-4",
            messages: [
              {
                role: "user",
                content: "Teste de conexão. Responda com OK.",
              },
            ],
            max_tokens: 10,
          }),
        });
        sucesso = response.ok;
      }

      if (sucesso) {
        toast.success(`✅ Conexão com ${PROVIDERS_INFO[config.provider].nome} estabelecida com sucesso!`);
      } else {
        toast.error(`❌ Erro ao conectar com ${PROVIDERS_INFO[config.provider].nome}. Verifique sua chave de API.`);
      }
    } catch (error) {
      toast.error(`❌ Erro ao testar conexão: ${error instanceof Error ? error.message : "Erro desconhecido"}`);
    } finally {
      setTestando(false);
    }
  };

  const providerInfo = PROVIDERS_INFO[config.provider];

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <button
            onClick={() => navigate("/")}
            className="p-2 hover:bg-gray-200 rounded-lg"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-3xl font-bold text-gray-900">Configurações de IA</h1>
        </div>

        {/* Card Principal */}
        <Card className="p-8 mb-8 bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200">
          <h2 className="text-2xl font-semibold mb-6">🤖 Configurar Provedor de IA</h2>

          <div className="space-y-6">
            {/* Seleção de Provider */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Selecione um Provedor de IA
              </label>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {Object.entries(PROVIDERS_INFO).map(([key, info]) => (
                  <button
                    key={key}
                    onClick={() =>
                      setConfig({
                        ...config,
                        provider: key as ConfigIA["provider"],
                        modelo: MODELOS[key][0] || "",
                      })
                    }
                    className={`p-4 rounded-lg border-2 transition text-left ${
                      config.provider === key
                        ? "border-purple-600 bg-purple-100"
                        : "border-gray-300 bg-white hover:border-purple-400"
                    }`}
                  >
                    <p className="font-semibold text-gray-900">{info.nome}</p>
                    <p className="text-xs text-gray-600 mt-1">{info.descricao}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Info do Provider Selecionado */}
            <Card className="p-4 bg-white border-l-4 border-purple-600">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">
                    {providerInfo.nome}
                  </h3>
                  <p className="text-sm text-gray-600 mb-3">
                    {providerInfo.descricao}
                  </p>
                  <div className="flex gap-2">
                    <a
                      href={providerInfo.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm font-medium"
                    >
                      Ir para {providerInfo.nome}
                      <ExternalLink className="w-4 h-4" />
                    </a>
                    <a
                      href={providerInfo.docs}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 px-3 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 text-sm font-medium"
                    >
                      Documentação
                      <ExternalLink className="w-4 h-4" />
                    </a>
                  </div>
                </div>
              </div>
            </Card>

            {/* Chave de API */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Chave de API
              </label>
              <div className="relative">
                <Input
                  type={showKey ? "text" : "password"}
                  placeholder="Cole sua chave de API aqui..."
                  value={config.apiKey}
                  onChange={(e) =>
                    setConfig({ ...config, apiKey: e.target.value })
                  }
                  className="pr-10"
                />
                <button
                  onClick={() => setShowKey(!showKey)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-gray-700"
                >
                  {showKey ? (
                    <EyeOff className="w-5 h-5" />
                  ) : (
                    <Eye className="w-5 h-5" />
                  )}
                </button>
              </div>
              <p className="text-xs text-gray-600 mt-2">
                🔒 Sua chave é armazenada apenas localmente no seu navegador. Nunca é enviada para servidores.
              </p>
            </div>

            {/* Seleção de Modelo */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Modelo
              </label>
              <select
                value={config.modelo}
                onChange={(e) =>
                  setConfig({ ...config, modelo: e.target.value })
                }
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              >
                <option value="">-- Selecione um modelo --</option>
                {MODELOS[config.provider]?.map((modelo) => (
                  <option key={modelo} value={modelo}>
                    {modelo}
                  </option>
                ))}
              </select>
            </div>

            {/* Botões de Ação */}
            <div className="flex gap-3 pt-4">
              <Button
                onClick={handleSave}
                className="flex-1 bg-green-600 hover:bg-green-700"
              >
                <Save className="mr-2 h-4 w-4" />
                Salvar Configurações
              </Button>
              <Button
                onClick={testarConexao}
                disabled={testando || !config.apiKey}
                variant="outline"
                className="flex-1"
              >
                {testando ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Testando...
                  </>
                ) : (
                  <>
                    <Zap className="mr-2 h-4 w-4" />
                    Testar Conexão
                  </>
                )}
              </Button>
              <Button
                onClick={handleReset}
                variant="destructive"
              >
                Remover
              </Button>
            </div>
          </div>
        </Card>

        {/* Informações Úteis */}
        <Card className="p-6 bg-blue-50 border-blue-200">
          <h3 className="font-semibold text-gray-900 mb-4">📚 Como Obter Sua Chave de API</h3>
          <div className="space-y-3 text-sm text-gray-700">
            <div>
              <p className="font-semibold text-gray-900 mb-1">🔗 Links Rápidos:</p>
              <ul className="space-y-2 ml-4">
                {Object.entries(PROVIDERS_INFO).map(([key, info]) => (
                  <li key={key}>
                    <a
                      href={info.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:text-blue-800 underline inline-flex items-center gap-1"
                    >
                      {info.nome}
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="font-semibold text-gray-900 mb-1">💡 Dicas:</p>
              <ul className="list-disc ml-6 space-y-1">
                <li>Cada provedor tem seus próprios planos de preço</li>
                <li>Você pode usar múltiplos provedores alternando entre eles</li>
                <li>Teste a conexão antes de usar em relatórios importantes</li>
                <li>Mantenha sua chave de API segura e confidencial</li>
              </ul>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
