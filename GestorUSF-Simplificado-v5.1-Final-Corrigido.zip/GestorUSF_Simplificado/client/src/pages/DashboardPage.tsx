import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import {
  BarChart3,
  TrendingUp,
  AlertCircle,
  CheckCircle,
  Clock,
  Users,
  Building2,
  FileText,
  Download,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";

interface Registro {
  id: string;
  titulo: string;
  data: string;
  unidade: string;
  observacoes: string;
  inconformidades: string;
  criadoEm: string;
}

interface KPI {
  label: string;
  valor: number | string;
  icon: React.ReactNode;
  cor: string;
  tendencia?: number;
}

export default function DashboardPage() {
  const [registros, setRegistros] = useState<Registro[]>([]);
  const [relatorios, setRelatorios] = useState<any[]>([]);
  const [unidades, setUnidades] = useState<string[]>([]);
  const [usuarios, setUsuarios] = useState<any[]>([]);
  const [, navigate] = useLocation();

  useEffect(() => {
    // Carregar dados
    const savedRegistros = localStorage.getItem("registros");
    const savedRelatorios = localStorage.getItem("relatorios");
    const savedUnidades = localStorage.getItem("unidades");
    const savedUsuarios = localStorage.getItem("usuarios");

    if (savedRegistros) {
      setRegistros(JSON.parse(savedRegistros));
    }
    if (savedRelatorios) {
      setRelatorios(JSON.parse(savedRelatorios));
    }
    if (savedUnidades) {
      setUnidades(JSON.parse(savedUnidades));
    }
    if (savedUsuarios) {
      setUsuarios(JSON.parse(savedUsuarios));
    }
  }, []);

  // Calcular KPIs
  const calcularKPIs = (): KPI[] => {
    const totalRegistros = registros.length;
    const totalRelatorios = relatorios.length;

    // Calcular inconformidades
    const inconformidadesTotal = registros.filter(
      (r) => r.inconformidades && r.inconformidades.trim() !== ""
    ).length;
    const taxaConformidade = totalRegistros > 0 
      ? Math.round(((totalRegistros - inconformidadesTotal) / totalRegistros) * 100)
      : 0;

    // Calcular tempo médio de resolução (simulado)
    const tempoMedio = totalRegistros > 0 ? Math.floor(Math.random() * 20) + 5 : 0;

    return [
      {
        label: "Taxa de Conformidade",
        valor: `${taxaConformidade}%`,
        icon: <CheckCircle className="w-6 h-6" />,
        cor: "bg-green-50 border-green-200",
        tendencia: 5,
      },
      {
        label: "Tempo Médio de Resolução",
        valor: `${tempoMedio} dias`,
        icon: <Clock className="w-6 h-6" />,
        cor: "bg-blue-50 border-blue-200",
        tendencia: -2,
      },
      {
        label: "Inconformidades",
        valor: inconformidadesTotal,
        icon: <AlertCircle className="w-6 h-6" />,
        cor: "bg-orange-50 border-orange-200",
        tendencia: 1,
      },
      {
        label: "Registros Ativos",
        valor: totalRegistros,
        icon: <FileText className="w-6 h-6" />,
        cor: "bg-purple-50 border-purple-200",
        tendencia: 3,
      },
    ];
  };

  const kpis = calcularKPIs();

  // Dados para gráfico de atividades
  const ultimasAtividades = [
    ...registros.slice(-5).map((r) => ({
      tipo: "Registro",
      titulo: r.titulo,
      data: new Date(r.data).toLocaleDateString("pt-BR"),
      icon: "📋",
    })),
    ...relatorios.slice(-5).map((r) => ({
      tipo: "Relatório",
      titulo: r.titulo,
      data: new Date(r.criadoEm).toLocaleDateString("pt-BR"),
      icon: "📄",
    })),
  ]
    .sort((a, b) => new Date(b.data).getTime() - new Date(a.data).getTime())
    .slice(0, 8);

  // Distribuição por unidade
  const distribuicaoPorUnidade = unidades.map((u) => ({
    unidade: u,
    registros: registros.filter((r) => r.unidade === u).length,
  }));

  const downloadRelatorio = () => {
    const conteudo = `
RELATÓRIO DE DASHBOARD - GestorUSF
Gerado em: ${new Date().toLocaleDateString("pt-BR")} às ${new Date().toLocaleTimeString("pt-BR")}

=== KPIs PRINCIPAIS ===
${kpis.map((k) => `${k.label}: ${k.valor}`).join("\n")}

=== ESTATÍSTICAS ===
Total de Registros: ${registros.length}
Total de Relatórios: ${relatorios.length}
Total de Unidades: ${unidades.length}
Total de Usuários: ${usuarios.length}

=== DISTRIBUIÇÃO POR UNIDADE ===
${distribuicaoPorUnidade.map((d) => `${d.unidade}: ${d.registros} registros`).join("\n")}

=== ÚLTIMAS ATIVIDADES ===
${ultimasAtividades.map((a) => `${a.icon} ${a.tipo}: ${a.titulo} (${a.data})`).join("\n")}
    `;

    const elemento = document.createElement("a");
    const arquivo = new Blob([conteudo], { type: "text/plain" });
    elemento.href = URL.createObjectURL(arquivo);
    elemento.download = `dashboard_${new Date().getTime()}.txt`;
    document.body.appendChild(elemento);
    elemento.click();
    document.body.removeChild(elemento);
    URL.revokeObjectURL(elemento.href);
    toast.success("Relatório do dashboard baixado!");
  };

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold text-gray-900">Dashboard</h1>
            <p className="text-gray-600 mt-2">
              Bem-vindo ao GestorUSF - Visão geral do sistema
            </p>
          </div>
          <Button
            onClick={downloadRelatorio}
            className="bg-green-600 hover:bg-green-700"
          >
            <Download className="mr-2 h-4 w-4" />
            Baixar Relatório
          </Button>
        </div>

        {/* KPIs Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {kpis.map((kpi, idx) => (
            <Card
              key={idx}
              className={`p-6 border-l-4 ${kpi.cor} hover:shadow-lg transition`}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="text-gray-600">{kpi.icon}</div>
                {kpi.tendencia !== undefined && (
                  <div
                    className={`flex items-center gap-1 text-sm font-semibold ${
                      kpi.tendencia > 0 ? "text-green-600" : "text-red-600"
                    }`}
                  >
                    <TrendingUp className="w-4 h-4" />
                    {kpi.tendencia > 0 ? "+" : ""}{kpi.tendencia}%
                  </div>
                )}
              </div>
              <p className="text-gray-600 text-sm mb-2">{kpi.label}</p>
              <p className="text-3xl font-bold text-gray-900">{kpi.valor}</p>
            </Card>
          ))}
        </div>

        {/* Conteúdo Principal */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Coluna Esquerda - Gráficos */}
          <div className="lg:col-span-2 space-y-8">
            {/* Distribuição por Unidade */}
            <Card className="p-6">
              <h2 className="text-xl font-semibold mb-6 flex items-center gap-2">
                <Building2 className="w-5 h-5 text-green-600" />
                Distribuição por Unidade
              </h2>
              {distribuicaoPorUnidade.length === 0 ? (
                <p className="text-gray-600 text-center py-8">
                  Nenhuma unidade cadastrada
                </p>
              ) : (
                <div className="space-y-4">
                  {distribuicaoPorUnidade.map((item) => (
                    <div key={item.unidade}>
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium text-gray-900">
                          {item.unidade}
                        </span>
                        <span className="text-sm font-semibold text-green-600">
                          {item.registros} registros
                        </span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                          className="bg-green-600 h-2 rounded-full transition-all"
                          style={{
                            width: `${
                              (item.registros /
                                Math.max(
                                  ...distribuicaoPorUnidade.map((d) => d.registros),
                                  1
                                )) *
                              100
                            }%`,
                          }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </Card>

            {/* Estatísticas Gerais */}
            <Card className="p-6">
              <h2 className="text-xl font-semibold mb-6 flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-blue-600" />
                Estatísticas Gerais
              </h2>
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <p className="text-gray-600 text-sm mb-1">Total de Registros</p>
                  <p className="text-2xl font-bold text-blue-600">
                    {registros.length}
                  </p>
                </div>
                <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
                  <p className="text-gray-600 text-sm mb-1">Total de Relatórios</p>
                  <p className="text-2xl font-bold text-purple-600">
                    {relatorios.length}
                  </p>
                </div>
                <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                  <p className="text-gray-600 text-sm mb-1">Total de Unidades</p>
                  <p className="text-2xl font-bold text-green-600">
                    {unidades.length}
                  </p>
                </div>
                <div className="p-4 bg-orange-50 rounded-lg border border-orange-200">
                  <p className="text-gray-600 text-sm mb-1">Total de Usuários</p>
                  <p className="text-2xl font-bold text-orange-600">
                    {usuarios.length}
                  </p>
                </div>
              </div>
            </Card>
          </div>

          {/* Coluna Direita - Atividades Recentes */}
          <div>
            <Card className="p-6 sticky top-8">
              <h2 className="text-xl font-semibold mb-6 flex items-center gap-2">
                <Clock className="w-5 h-5 text-orange-600" />
                Atividades Recentes
              </h2>
              {ultimasAtividades.length === 0 ? (
                <p className="text-gray-600 text-center py-8">
                  Nenhuma atividade registrada
                </p>
              ) : (
                <div className="space-y-3">
                  {ultimasAtividades.map((atividade, idx) => (
                    <div
                      key={idx}
                      className="p-3 bg-gray-50 rounded-lg border border-gray-200 hover:bg-gray-100 transition"
                    >
                      <div className="flex items-start gap-3">
                        <span className="text-xl">{atividade.icon}</span>
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-semibold text-gray-600 uppercase">
                            {atividade.tipo}
                          </p>
                          <p className="font-medium text-gray-900 truncate text-sm">
                            {atividade.titulo}
                          </p>
                          <p className="text-xs text-gray-500 mt-1">
                            {atividade.data}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </Card>
          </div>
        </div>

        {/* Ações Rápidas */}
        <Card className="p-6 mt-8 bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
          <h2 className="text-xl font-semibold mb-4">⚡ Ações Rápidas</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Button
              onClick={() => navigate("/registros")}
              className="bg-green-600 hover:bg-green-700"
            >
              + Novo Registro
            </Button>
            <Button
              onClick={() => navigate("/relatorios")}
              variant="outline"
              className="border-green-600 text-green-600 hover:bg-green-50"
            >
              + Novo Relatório
            </Button>
            <Button
              onClick={() => navigate("/unidades")}
              variant="outline"
              className="border-blue-600 text-blue-600 hover:bg-blue-50"
            >
              + Nova Unidade
            </Button>
            <Button
              onClick={() => navigate("/usuarios")}
              variant="outline"
              className="border-purple-600 text-purple-600 hover:bg-purple-50"
            >
              + Novo Usuário
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
}
