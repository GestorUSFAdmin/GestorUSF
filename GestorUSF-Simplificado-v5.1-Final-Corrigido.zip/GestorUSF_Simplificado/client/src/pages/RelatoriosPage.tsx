import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useLocation } from "wouter";
import { ArrowLeft, Download, Loader2, FileText, BarChart3, X } from "lucide-react";
import { toast } from "sonner";
import { OrquestradorRelatorio } from "@/services/orquestradorRelatorio";
import { ArmazenadorRelatorio } from "@/services/armazenadorRelatorio";
import type { Relatorio, ConfiguracaoRelatorio, ConfiguracaoIA, DadosInspeção } from "@/services/relatorioTypes";

interface Registro {
  id: string;
  titulo: string;
  data: string;
  unidade: string;
  observacoes: string;
  inconformidades: string;
  criadoEm: string;
  arquivos?: Array<{
    id: string;
    nome: string;
    tamanho: number;
    tipo: string;
    data: string;
    conteudo: string;
  }>;
}

export default function RelatoriosPage() {
  const [registros, setRegistros] = useState<Registro[]>([]);
  const [relatorios, setRelatorios] = useState<Relatorio[]>([]);
  const [selectedRegistroId, setSelectedRegistroId] = useState<string>("");
  const [selectedUnidade, setSelectedUnidade] = useState<string>("");
  const [modoGeracao, setModoGeracao] = useState<"registro" | "unidade">("registro");
  const [isGenerating, setIsGenerating] = useState(false);
  const [, navigate] = useLocation();
  const [expandedRelatorio, setExpandedRelatorio] = useState<string | null>(null);
  const [mostrarEstatisticas, setMostrarEstatisticas] = useState(false);
  const [modalRelatorio, setModalRelatorio] = useState<Relatorio | null>(null);
  const [incluirAnexos, setIncluirAnexos] = useState(true);
  const [configRelatorio, setConfigRelatorio] = useState<ConfiguracaoRelatorio>({
    template: "completo",
    incluirGraficos: false,
    incluirRecomendacoes: true,
    incluirAnexos: true,
    idioma: "pt-BR",
    nivelDetalhe: "normal",
  });

  useEffect(() => {
    const savedRegistros = localStorage.getItem("registros");
    const savedRelatorios = ArmazenadorRelatorio.obterTodos();

    if (savedRegistros) {
      setRegistros(JSON.parse(savedRegistros));
    }
    setRelatorios(savedRelatorios);
  }, []);

  const unidadesCadastradas = Array.from(new Set(registros.map((r) => r.unidade))).filter(Boolean);

  const salvarRelatorios = (novosRelatorios: Relatorio[]) => {
    setRelatorios(novosRelatorios);
  };

  const gerarRelatorioComIA = async () => {
    if (modoGeracao === "registro" && !selectedRegistroId) {
      toast.error("Selecione um registro!");
      return;
    }

    if (modoGeracao === "unidade" && !selectedUnidade) {
      toast.error("Selecione uma unidade!");
      return;
    }

    setIsGenerating(true);
    try {
      const configIAJson = localStorage.getItem("configIA");
      if (!configIAJson) {
        toast.error("Configure a IA em 'Configurações IA' primeiro!");
        setIsGenerating(false);
        return;
      }

      const configIA: ConfiguracaoIA = JSON.parse(configIAJson);
      const configAtualizada = { ...configRelatorio, incluirAnexos };

      let dados: DadosInspeção;

      if (modoGeracao === "registro") {
        // Gerar para registro específico
        const registro = registros.find((r) => r.id === selectedRegistroId);
        if (!registro) {
          toast.error("Registro não encontrado!");
          setIsGenerating(false);
          return;
        }

        dados = {
          id: registro.id,
          titulo: registro.titulo,
          data: registro.data,
          unidade: registro.unidade,
          observacoes: registro.observacoes,
          inconformidades: registro.inconformidades,
          arquivos: incluirAnexos ? registro.arquivos : undefined,
        };
      } else {
        // Gerar para unidade (agregar todos os registros)
        const registrosDaUnidade = registros.filter((r) => r.unidade === selectedUnidade);
        if (registrosDaUnidade.length === 0) {
          toast.error("Nenhum registro encontrado para esta unidade!");
          setIsGenerating(false);
          return;
        }

        // Agregar dados
        const todosOsArquivos = incluirAnexos
          ? registrosDaUnidade.flatMap((r) => r.arquivos || [])
          : undefined;

        dados = {
          id: `unidade_${selectedUnidade}_${Date.now()}`,
          titulo: `Relatório Agregado - ${selectedUnidade}`,
          data: new Date().toISOString().split("T")[0],
          unidade: selectedUnidade,
          observacoes: registrosDaUnidade.map((r) => `${r.titulo}: ${r.observacoes}`).join("\n---\n"),
          inconformidades: registrosDaUnidade.map((r) => `${r.titulo}: ${r.inconformidades}`).join("\n---\n"),
          arquivos: todosOsArquivos,
        };
      }

      // Gerar relatório com novo modelo
      const resultado = await OrquestradorRelatorio.gerar(dados, configAtualizada, configIA);

      if (resultado.sucesso && resultado.relatorio) {
        salvarRelatorios([resultado.relatorio, ...relatorios]);
        setModalRelatorio(resultado.relatorio);
        toast.success(
          `✓ Relatório gerado com sucesso!\nQualidade: ${resultado.metadados.scoreQualidade}%\nTempo: ${resultado.metadados.tempoGeração}ms`
        );
      } else if (resultado.relatorio) {
        toast.warning(
          `⚠️ Relatório gerado com avisos:\n${resultado.metadados.validacoes.join("\n")}`
        );
        setModalRelatorio(resultado.relatorio);
        salvarRelatorios([resultado.relatorio, ...relatorios]);
      }

      setSelectedRegistroId("");
      setSelectedUnidade("");
    } catch (error) {
      console.error("Erro ao gerar relatório:", error);
      toast.error(
        error instanceof Error ? error.message : "Erro ao gerar relatório"
      );
    } finally {
      setIsGenerating(false);
    }
  };

  const downloadRelatorio = (relatorio: Relatorio, formato: string = "txt") => {
    let conteudo: any = relatorio.conteudo;
    let tipo = "text/plain";
    let extensao = "txt";

    if (formato === "txt") {
      tipo = "text/plain";
      extensao = "txt";
    } else if (formato === "html") {
      tipo = "text/html";
      extensao = "html";
      conteudo = gerarHTML(relatorio);
    } else if (formato === "json") {
      tipo = "application/json";
      extensao = "json";
      conteudo = JSON.stringify(relatorio, null, 2);
    } else if (formato === "docx") {
      tipo = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
      extensao = "docx";
      conteudo = gerarDOCX(relatorio);
    } else if (formato === "pdf") {
      tipo = "application/pdf";
      extensao = "pdf";
      conteudo = gerarPDF(relatorio);
    }

    const elemento = document.createElement("a");
    const arquivo = new Blob([conteudo], { type: tipo });
    elemento.href = URL.createObjectURL(arquivo);
    elemento.download = `${relatorio.titulo.replace(/\s+/g, "_")}.${extensao}`;
    document.body.appendChild(elemento);
    elemento.click();
    document.body.removeChild(elemento);
    URL.revokeObjectURL(elemento.href);
    toast.success(`Relatório baixado em ${formato.toUpperCase()}!`);
  };

  const gerarHTML = (relatorio: Relatorio) => {
    return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${relatorio.titulo}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { 
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
      line-height: 1.6; 
      color: #333; 
      background: #f5f5f5;
    }
    .container { 
      max-width: 900px; 
      margin: 0 auto; 
      padding: 40px 20px;
      background: white;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }
    .header { 
      border-bottom: 3px solid #2ecc71; 
      padding-bottom: 20px; 
      margin-bottom: 30px; 
    }
    .header h1 { 
      color: #2ecc71; 
      font-size: 28px;
      margin-bottom: 10px;
    }
    .header p { 
      color: #666; 
      font-size: 14px;
    }
    .metadata {
      background: #f9f9f9;
      padding: 10px;
      margin: 10px 0;
      border-left: 4px solid #2ecc71;
      font-size: 12px;
      color: #666;
    }
    .content { 
      white-space: pre-wrap; 
      word-wrap: break-word;
      background: #f9f9f9;
      padding: 20px;
      border-radius: 5px;
      border-left: 4px solid #2ecc71;
    }
    .footer { 
      margin-top: 30px; 
      padding-top: 20px; 
      border-top: 1px solid #ddd; 
      font-size: 12px; 
      color: #999;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>🏥 GestorUSF - Relatório</h1>
      <p><strong>${relatorio.titulo}</strong></p>
      <p>Gerado em: ${new Date(relatorio.criadoEm).toLocaleDateString("pt-BR")} às ${new Date(relatorio.criadoEm).toLocaleTimeString("pt-BR")}</p>
    </div>
    <div class="metadata">
      <strong>Qualidade:</strong> ${relatorio.metadados.scoreQualidade}% | 
      <strong>Provider:</strong> ${relatorio.metadados.provider} | 
      <strong>Modelo:</strong> ${relatorio.metadados.modelo} | 
      <strong>Tokens:</strong> ${relatorio.metadados.tokensUsados}
    </div>
    <div class="content">${relatorio.conteudo}</div>
    <div class="footer">
      <p>Este relatório foi gerado automaticamente pelo sistema GestorUSF com IA.</p>
    </div>
  </div>
</body>
</html>`;
  };

  const gerarDOCX = (relatorio: Relatorio) => {
    // Criar um DOCX simples em formato XML
    const docxXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:body>
    <w:p>
      <w:pPr>
        <w:pStyle w:val="Heading1"/>
      </w:pPr>
      <w:r>
        <w:rPr>
          <w:b/>
          <w:sz w:val="48"/>
        </w:rPr>
        <w:t>GestorUSF - Relatório</w:t>
      </w:r>
    </w:p>
    <w:p>
      <w:r>
        <w:t>${relatorio.titulo}</w:t>
      </w:r>
    </w:p>
    <w:p>
      <w:r>
        <w:t>Gerado em: ${new Date(relatorio.criadoEm).toLocaleDateString("pt-BR")}</w:t>
      </w:r>
    </w:p>
    <w:p>
      <w:r>
        <w:t>Qualidade: ${relatorio.metadados.scoreQualidade}% | Provider: ${relatorio.metadados.provider}</w:t>
      </w:r>
    </w:p>
    <w:p>
      <w:r>
        <w:br/>
      </w:r>
    </w:p>
    ${relatorio.conteudo
      .split("\n")
      .map(
        (linha) => `<w:p>
      <w:r>
        <w:t>${linha.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")}</w:t>
      </w:r>
    </w:p>`
      )
      .join("")}
  </w:body>
</w:document>`;

    return new Blob([docxXml], {
      type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    });
  };

  const gerarPDF = (relatorio: Relatorio) => {
    // Gerar PDF simples
    const pdfContent = `%PDF-1.4
1 0 obj
<< /Type /Catalog /Pages 2 0 R >>
endobj
2 0 obj
<< /Type /Pages /Kids [3 0 R] /Count 1 >>
endobj
3 0 obj
<< /Type /Page /Parent 2 0 R /Resources << /Font << /F1 4 0 R >> >> /MediaBox [0 0 612 792] /Contents 5 0 R >>
endobj
4 0 obj
<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>
endobj
5 0 obj
<< /Length ${relatorio.conteudo.length + 500} >>
stream
BT
/F1 12 Tf
50 750 Td
(GestorUSF - Relatorio) Tj
0 -20 Td
(${relatorio.titulo.substring(0, 50)}) Tj
0 -20 Td
(Gerado em: ${new Date(relatorio.criadoEm).toLocaleDateString("pt-BR")}) Tj
0 -20 Td
(Qualidade: ${relatorio.metadados.scoreQualidade}%) Tj
0 -40 Td
(${relatorio.conteudo.substring(0, 300).replace(/\n/g, " ")}) Tj
ET
endstream
endobj
xref
0 6
0000000000 65535 f
0000000009 00000 n
0000000058 00000 n
0000000115 00000 n
0000000229 00000 n
0000000310 00000 n
trailer
<< /Size 6 /Root 1 0 R >>
startxref
${relatorio.conteudo.length + 860}
%%EOF`;

    return new Blob([pdfContent], { type: "application/pdf" });
  };

  const copiarParaClipboard = (texto: string) => {
    navigator.clipboard.writeText(texto);
    toast.success("Conteúdo copiado para a área de transferência!");
  };

  const obterEstatisticas = () => {
    return ArmazenadorRelatorio.obterEstatisticas();
  };

  const deletarRelatorio = (id: string) => {
    if (confirm("Tem certeza que deseja deletar este relatório?")) {
      ArmazenadorRelatorio.deletar(id);
      setRelatorios(relatorios.filter((r) => r.id !== id));
      toast.success("Relatório deletado!");
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <button
            onClick={() => navigate("/")}
            className="p-2 hover:bg-gray-200 rounded-lg"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-3xl font-bold text-gray-900">Relatórios</h1>
          <button
            onClick={() => setMostrarEstatisticas(!mostrarEstatisticas)}
            className="ml-auto p-2 hover:bg-blue-100 rounded-lg text-blue-600"
            title="Ver estatísticas"
          >
            <BarChart3 className="w-6 h-6" />
          </button>
        </div>

        {/* Estatísticas */}
        {mostrarEstatisticas && (
          <Card className="p-6 mb-8 bg-blue-50 border-blue-200">
            <h2 className="text-lg font-semibold mb-4">📊 Estatísticas</h2>
            {(() => {
              const stats = obterEstatisticas();
              return (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="bg-white p-3 rounded border border-blue-200">
                    <p className="text-sm text-gray-600">Total de Relatórios</p>
                    <p className="text-2xl font-bold text-blue-600">{stats.totalRelatorios}</p>
                  </div>
                  <div className="bg-white p-3 rounded border border-blue-200">
                    <p className="text-sm text-gray-600">Taxa de Sucesso</p>
                    <p className="text-2xl font-bold text-green-600">{stats.taxaSucesso}%</p>
                  </div>
                  <div className="bg-white p-3 rounded border border-blue-200">
                    <p className="text-sm text-gray-600">Qualidade Média</p>
                    <p className="text-2xl font-bold text-purple-600">{stats.scoreQualidadeMedia}%</p>
                  </div>
                  <div className="bg-white p-3 rounded border border-blue-200">
                    <p className="text-sm text-gray-600">Tempo Médio</p>
                    <p className="text-2xl font-bold text-orange-600">{stats.tempoMedioGeração}ms</p>
                  </div>
                </div>
              );
            })()}
          </Card>
        )}

        {/* Seção de Geração */}
        <Card className="p-6 mb-8 bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
          <h2 className="text-xl font-semibold mb-4">🤖 Gerar Relatório com IA</h2>
          <p className="text-gray-700 mb-4">
            Selecione um registro específico ou uma unidade para gerar um relatório detalhado com Inteligência Artificial.
          </p>

          <div className="space-y-4">
            {/* Seleção de Modo */}
            <div className="flex gap-4">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="radio"
                  value="registro"
                  checked={modoGeracao === "registro"}
                  onChange={(e) => setModoGeracao(e.target.value as "registro" | "unidade")}
                  className="w-4 h-4"
                />
                <span className="text-sm font-medium">Registro Específico</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="radio"
                  value="unidade"
                  checked={modoGeracao === "unidade"}
                  onChange={(e) => setModoGeracao(e.target.value as "registro" | "unidade")}
                  className="w-4 h-4"
                />
                <span className="text-sm font-medium">Por Unidade (Agregado)</span>
              </label>
            </div>

            {/* Seleção de Registro ou Unidade */}
            {modoGeracao === "registro" ? (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Selecione um Registro
                </label>
                <select
                  value={selectedRegistroId}
                  onChange={(e) => setSelectedRegistroId(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                >
                  <option value="">-- Escolha um registro --</option>
                  {registros.length === 0 ? (
                    <option disabled>Nenhum registro disponível</option>
                  ) : (
                    registros.map((r) => (
                      <option key={r.id} value={r.id}>
                        {r.titulo} ({new Date(r.data).toLocaleDateString("pt-BR")})
                      </option>
                    ))
                  )}
                </select>
              </div>
            ) : (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Selecione uma Unidade
                </label>
                <select
                  value={selectedUnidade}
                  onChange={(e) => setSelectedUnidade(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                >
                  <option value="">-- Escolha uma unidade --</option>
                  {unidadesCadastradas.length === 0 ? (
                    <option disabled>Nenhuma unidade disponível</option>
                  ) : (
                    unidadesCadastradas.map((u) => (
                      <option key={u} value={u}>
                        {u} ({registros.filter((r) => r.unidade === u).length} registros)
                      </option>
                    ))
                  )}
                </select>
              </div>
            )}

            {/* Opções de Configuração */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Template
                </label>
                <select
                  value={configRelatorio.template}
                  onChange={(e) =>
                    setConfigRelatorio({
                      ...configRelatorio,
                      template: e.target.value as any,
                    })
                  }
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                >
                  <option value="executivo">Executivo</option>
                  <option value="completo">Completo</option>
                  <option value="tecnico">Técnico</option>
                  <option value="customizado">Customizado</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Nível de Detalhe
                </label>
                <select
                  value={configRelatorio.nivelDetalhe}
                  onChange={(e) =>
                    setConfigRelatorio({
                      ...configRelatorio,
                      nivelDetalhe: e.target.value as any,
                    })
                  }
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg"
                >
                  <option value="resumido">Resumido</option>
                  <option value="normal">Normal</option>
                  <option value="detalhado">Detalhado</option>
                </select>
              </div>

              <div>
                <label className="flex items-center gap-2 mt-8 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={incluirAnexos}
                    onChange={(e) => setIncluirAnexos(e.target.checked)}
                    className="w-4 h-4"
                  />
                  <span className="text-sm font-medium">Incluir Anexos</span>
                </label>
              </div>
            </div>

            <Button
              onClick={gerarRelatorioComIA}
              disabled={isGenerating || (modoGeracao === "registro" && !selectedRegistroId) || (modoGeracao === "unidade" && !selectedUnidade)}
              className="w-full bg-green-600 hover:bg-green-700"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Gerando relatório...
                </>
              ) : (
                "Gerar Relatório com IA"
              )}
            </Button>
          </div>
        </Card>

        {/* Modal Flutuante de Visualização */}
        {modalRelatorio && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <Card className="w-full max-w-2xl max-h-[90vh] flex flex-col bg-white">
              {/* Header do Modal */}
              <div className="flex items-center justify-between p-6 border-b">
                <h2 className="text-xl font-semibold">{modalRelatorio.titulo}</h2>
                <button
                  onClick={() => setModalRelatorio(null)}
                  className="p-1 hover:bg-gray-100 rounded-lg"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              {/* Conteúdo com Scroll */}
              <div className="flex-1 overflow-y-auto p-6">
                <div className="bg-gray-50 p-4 rounded-lg mb-4">
                  <p className="text-xs text-gray-600">
                    <strong>Qualidade:</strong> {modalRelatorio.metadados.scoreQualidade}% | 
                    <strong> Provider:</strong> {modalRelatorio.metadados.provider} | 
                    <strong> Tokens:</strong> {modalRelatorio.metadados.tokensUsados}
                  </p>
                </div>
                <div className="whitespace-pre-wrap text-sm text-gray-700">
                  {modalRelatorio.conteudo}
                </div>
              </div>

              {/* Footer com Botões de Download */}
              <div className="border-t p-6 bg-gray-50">
                <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
                  <Button
                    onClick={() => downloadRelatorio(modalRelatorio, "txt")}
                    variant="outline"
                    size="sm"
                    className="text-xs"
                  >
                    📄 TXT
                  </Button>
                  <Button
                    onClick={() => downloadRelatorio(modalRelatorio, "html")}
                    variant="outline"
                    size="sm"
                    className="text-xs"
                  >
                    🌐 HTML
                  </Button>
                  <Button
                    onClick={() => downloadRelatorio(modalRelatorio, "docx")}
                    variant="outline"
                    size="sm"
                    className="text-xs"
                  >
                    📘 DOCX
                  </Button>
                  <Button
                    onClick={() => downloadRelatorio(modalRelatorio, "pdf")}
                    variant="outline"
                    size="sm"
                    className="text-xs"
                  >
                    📕 PDF
                  </Button>
                  <Button
                    onClick={() => copiarParaClipboard(modalRelatorio.conteudo)}
                    variant="outline"
                    size="sm"
                    className="text-xs"
                  >
                    📋 Copiar
                  </Button>
                </div>
              </div>
            </Card>
          </div>
        )}

        {/* Lista de Relatórios */}
        <div>
          <h2 className="text-xl font-semibold mb-4">
            📋 Relatórios Gerados ({relatorios.length})
          </h2>
          {relatorios.length === 0 ? (
            <Card className="p-8 text-center">
              <FileText className="w-12 h-12 text-gray-400 mx-auto mb-3" />
              <p className="text-gray-600">Nenhum relatório gerado ainda.</p>
              <p className="text-sm text-gray-500 mt-1">
                Gere seu primeiro relatório usando a seção acima.
              </p>
            </Card>
          ) : (
            <div className="space-y-4">
              {relatorios.map((relatorio) => (
                <Card
                  key={relatorio.id}
                  className="p-6 hover:shadow-md transition"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="font-semibold text-lg text-gray-900">
                          {relatorio.titulo}
                        </h3>
                        <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full font-semibold">
                          {relatorio.tipo === "ia" ? "🤖 IA" : "📝 Manual"}
                        </span>
                        <span className="px-2 py-1 bg-purple-100 text-purple-800 text-xs rounded-full">
                          {relatorio.metadados.scoreQualidade}%
                        </span>
                      </div>
                      <p className="text-sm text-gray-600">
                        📅{" "}
                        {new Date(relatorio.criadoEm).toLocaleDateString(
                          "pt-BR"
                        )}{" "}
                        às{" "}
                        {new Date(relatorio.criadoEm).toLocaleTimeString(
                          "pt-BR"
                        )}
                      </p>
                      <p className="text-xs text-gray-500 mt-1">
                        Provider: {relatorio.metadados.provider} | Tokens: {relatorio.metadados.tokensUsados}
                      </p>

                      {/* Prévia do Conteúdo */}
                      <div className="mt-3 p-3 bg-gray-50 rounded-lg max-h-40 overflow-y-auto border-l-4 border-green-300">
                        <p className="text-sm text-gray-700 whitespace-pre-wrap">
                          {expandedRelatorio === relatorio.id
                            ? relatorio.conteudo
                            : relatorio.conteudo.substring(0, 400) + "..."}
                        </p>
                      </div>

                      {relatorio.conteudo.length > 400 && (
                        <button
                          onClick={() =>
                            setExpandedRelatorio(
                              expandedRelatorio === relatorio.id
                                ? null
                                : relatorio.id
                            )
                          }
                          className="mt-2 text-sm text-blue-600 hover:text-blue-800"
                        >
                          {expandedRelatorio === relatorio.id
                            ? "▼ Ver menos"
                            : "▶ Ver mais"}
                        </button>
                      )}
                    </div>

                    {/* Botões de Ação */}
                    <div className="ml-4 flex flex-col gap-2">
                      <button
                        onClick={() => setModalRelatorio(relatorio)}
                        className="p-2 hover:bg-blue-100 rounded-lg text-blue-600 text-xs font-semibold"
                        title="Abrir em modal"
                      >
                        🔍 Visualizar
                      </button>
                      <div className="flex gap-1 flex-wrap justify-end">
                        <button
                          onClick={() => downloadRelatorio(relatorio, "txt")}
                          className="p-2 hover:bg-blue-100 rounded-lg text-blue-600 text-xs"
                          title="Baixar como TXT"
                        >
                          TXT
                        </button>
                        <button
                          onClick={() => downloadRelatorio(relatorio, "html")}
                          className="p-2 hover:bg-purple-100 rounded-lg text-purple-600 text-xs"
                          title="Baixar como HTML"
                        >
                          HTML
                        </button>
                        <button
                          onClick={() => downloadRelatorio(relatorio, "docx")}
                          className="p-2 hover:bg-red-100 rounded-lg text-red-600 text-xs"
                          title="Baixar como DOCX"
                        >
                          DOCX
                        </button>
                        <button
                          onClick={() => downloadRelatorio(relatorio, "pdf")}
                          className="p-2 hover:bg-orange-100 rounded-lg text-orange-600 text-xs"
                          title="Baixar como PDF"
                        >
                          PDF
                        </button>
                      </div>
                      <button
                        onClick={() => copiarParaClipboard(relatorio.conteudo)}
                        className="p-2 hover:bg-green-100 rounded-lg text-green-600 text-xs"
                        title="Copiar para clipboard"
                      >
                        📋 Copiar
                      </button>
                      <button
                        onClick={() => deletarRelatorio(relatorio.id)}
                        className="p-2 hover:bg-red-100 rounded-lg text-red-600 text-xs"
                        title="Deletar relatório"
                      >
                        🗑️ Deletar
                      </button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
