/**
 * CAMADA 1: PREPARAÇÃO DE DADOS
 * Validação, enriquecimento e formatação de dados de inspeção
 */

import { DadosInspeção, Arquivo } from './relatorioTypes';

export class PreparadorDados {
  /**
   * Valida se os dados obrigatórios estão presentes
   */
  static validarDados(dados: DadosInspeção): boolean {
    if (!dados.titulo || dados.titulo.trim().length === 0) {
      throw new Error('Título da inspeção é obrigatório');
    }
    if (!dados.unidade || dados.unidade.trim().length === 0) {
      throw new Error('Unidade é obrigatória');
    }
    if (!dados.data || dados.data.trim().length === 0) {
      throw new Error('Data da inspeção é obrigatória');
    }
    if (!dados.inconformidades || dados.inconformidades.trim().length === 0) {
      throw new Error('Inconformidades são obrigatórias');
    }
    return true;
  }

  /**
   * Enriquece os dados com valores padrão
   */
  static enriquecerContexto(dados: DadosInspeção): DadosInspeção {
    return {
      ...dados,
      responsavel: dados.responsavel || 'Não especificado',
      tipo: dados.tipo || 'Inspeção Geral',
      observacoes: dados.observacoes || 'Nenhuma observação adicional',
    };
  }

  /**
   * Formata o tamanho de arquivo em unidades legíveis
   */
  static formatarTamanho(bytes: number): string {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return (
      Math.round((bytes / Math.pow(k, i)) * 100) / 100 + ' ' + sizes[i]
    );
  }

  /**
   * Formata informações sobre arquivos anexados
   */
  static formatarAnexos(arquivos?: Arquivo[]): string {
    if (!arquivos || arquivos.length === 0) {
      return '';
    }

    let infoAnexos = '\n\n**ARQUIVOS ANEXADOS:**\n';
    arquivos.forEach((arq) => {
      infoAnexos += `- ${arq.nome} (${this.formatarTamanho(arq.tamanho)})\n`;
    });
    infoAnexos += `\nTotal: ${arquivos.length} arquivo(s) anexado(s) à inspeção.`;

    return infoAnexos;
  }

  /**
   * Formata todos os dados de inspeção em texto estruturado
   */
  static formatarDados(dados: DadosInspeção): string {
    const dataFormatada = new Date(dados.data).toLocaleDateString('pt-BR');
    const infoAnexos = this.formatarAnexos(dados.arquivos);

    return `
**DADOS DA INSPEÇÃO:**
- ID: ${dados.id}
- Título: ${dados.titulo}
- Data: ${dataFormatada}
- Unidade: ${dados.unidade}
- Tipo: ${dados.tipo || 'Inspeção Geral'}
- Responsável: ${dados.responsavel || 'Não especificado'}
- Observações: ${dados.observacoes || 'Nenhuma observação adicional'}
- Inconformidades: ${dados.inconformidades}${infoAnexos}
`;
  }

  /**
   * Sanitiza texto para remover caracteres perigosos
   */
  static sanitizarTexto(texto: string): string {
    return texto
      .replace(/[<>]/g, '') // Remove < e >
      .replace(/\n{3,}/g, '\n\n') // Remove quebras de linha excessivas
      .trim();
  }

  /**
   * Prepara dados completos para geração de relatório
   */
  static preparar(dados: DadosInspeção): {
    valido: boolean;
    dadosEnriquecidos: DadosInspeção;
    dadosFormatados: string;
  } {
    this.validarDados(dados);
    const dadosEnriquecidos = this.enriquecerContexto(dados);
    const dadosFormatados = this.formatarDados(dadosEnriquecidos);

    return {
      valido: true,
      dadosEnriquecidos,
      dadosFormatados,
    };
  }
}
