/**
 * CAMADA 4: PROCESSAMENTO DE RESPOSTA
 * Validação de qualidade, parsing de conteúdo e enriquecimento de metadados
 */

import {
  ValidacaoQualidade,
  SecoeRelatorio,
  ResultadoProcessamento,
  Relatorio,
  ConfiguracaoIA,
} from './relatorioTypes';

export class ValidadorRelatorio {
  /**
   * Valida a qualidade do relatório gerado
   */
  static validarQualidade(conteudo: string): ValidacaoQualidade {
    const problemas: string[] = [];
    let score = 100;

    // 1. Verificar comprimento mínimo
    if (conteudo.length < 200) {
      problemas.push('Conteúdo muito curto (< 200 caracteres)');
      score -= 20;
    }

    if (conteudo.length < 500) {
      problemas.push('Conteúdo abaixo do esperado (< 500 caracteres)');
      score -= 10;
    }

    // 2. Verificar estrutura esperada
    const temResumo = /resumo|summary|executive/i.test(conteudo);
    const temRecomendacoes = /recomendação|recomendações|recommendation/i.test(conteudo);
    const temConclusao = /conclusão|conclusion|conclusões/i.test(conteudo);
    const temAnalise = /análise|analysis|avaliação/i.test(conteudo);

    if (!temResumo) {
      problemas.push('Falta seção de resumo');
      score -= 15;
    }

    if (!temAnalise) {
      problemas.push('Falta seção de análise');
      score -= 10;
    }

    if (!temRecomendacoes) {
      problemas.push('Falta seção de recomendações');
      score -= 15;
    }

    if (!temConclusao) {
      problemas.push('Falta seção de conclusão');
      score -= 10;
    }

    // 3. Verificar erros comuns
    if (/\[ERROR\]|\[ERRO\]|error|erro/i.test(conteudo.substring(0, 100))) {
      problemas.push('Conteúdo contém marcadores de erro');
      score -= 30;
    }

    // 4. Verificar se há conteúdo repetido (possível erro)
    const linhas = conteudo.split('\n');
    const linhasUnicas = new Set(linhas);
    if (linhas.length > 10 && linhasUnicas.size < linhas.length * 0.5) {
      problemas.push('Conteúdo com muita repetição');
      score -= 15;
    }

    // 5. Verificar formatação
    const temTitulos = /^#+\s/m.test(conteudo) || /^[A-Z][A-Z\s]+$/m.test(conteudo);
    if (!temTitulos) {
      problemas.push('Formatação fraca (sem títulos claros)');
      score -= 5;
    }

    // 6. Verificar se há números ou dados específicos
    const temDados = /\d+|%|R\$|data|período/i.test(conteudo);
    if (!temDados) {
      problemas.push('Faltam dados específicos ou números');
      score -= 5;
    }

    return {
      valido: score >= 70,
      score: Math.max(0, Math.min(100, score)),
      problemas,
    };
  }

  /**
   * Extrai seções do conteúdo
   */
  static extrairSecoes(conteudo: string): SecoeRelatorio {
    return {
      resumoExecutivo: this.extrairSecao(conteudo, [
        'RESUMO EXECUTIVO',
        'RESUMO',
        'EXECUTIVE SUMMARY',
      ]),
      dadosInspeção: this.extrairSecao(conteudo, [
        'DADOS DA INSPEÇÃO',
        'DADOS',
        'INSPECTION DATA',
      ]),
      analise: this.extrairSecao(conteudo, [
        'ANÁLISE SITUACIONAL',
        'ANÁLISE',
        'ANALYSIS',
      ]),
      inconformidades: this.extrairSecao(conteudo, [
        'INCONFORMIDADES',
        'FINDINGS',
        'ACHADOS',
      ]),
      recomendacoes: this.extrairSecao(conteudo, [
        'RECOMENDAÇÕES',
        'RECOMMENDATIONS',
        'PLANO DE AÇÃO',
      ]),
      conclusao: this.extrairSecao(conteudo, [
        'CONCLUSÃO',
        'CONCLUSION',
        'CONCLUSÕES',
      ]),
    };
  }

  /**
   * Extrai uma seção específica do conteúdo
   */
  private static extrairSecao(conteudo: string, titulos: string[]): string {
    for (const titulo of titulos) {
      const regex = new RegExp(
        `(^|\\n)#+?\\s*${titulo}.*?(?=(\\n#+|$))`,
        'is'
      );
      const match = conteudo.match(regex);
      if (match) {
        return match[0].trim();
      }
    }

    // Se não encontrar com títulos markdown, tenta sem
    for (const titulo of titulos) {
      const regex = new RegExp(
        `(^|\\n)${titulo}.*?(?=(\\n[A-Z]+|$))`,
        'is'
      );
      const match = conteudo.match(regex);
      if (match) {
        return match[0].trim();
      }
    }

    return '';
  }

  /**
   * Extrai resumo executivo (primeiras linhas significativas)
   */
  static extrairResumoExecutivo(conteudo: string, maxCaracteres: number = 300): string {
    // Tentar extrair seção de resumo
    const secaoResumo = this.extrairSecao(conteudo, [
      'RESUMO EXECUTIVO',
      'RESUMO',
      'EXECUTIVE SUMMARY',
    ]);

    if (secaoResumo) {
      return secaoResumo.substring(0, maxCaracteres);
    }

    // Fallback: primeiras linhas
    const linhas = conteudo
      .split('\n')
      .filter((l) => l.trim().length > 0)
      .slice(0, 5);

    return linhas.join(' ').substring(0, maxCaracteres);
  }
}

export class ProcessadorResposta {
  /**
   * Processa a resposta da IA e cria estrutura de relatório
   */
  static processar(
    conteudo: string,
    tokensUsados: number,
    configIA: ConfiguracaoIA
  ): ResultadoProcessamento {
    // Validar qualidade
    const validacao = ValidadorRelatorio.validarQualidade(conteudo);

    // Extrair seções
    const secoes = ValidadorRelatorio.extrairSecoes(conteudo);

    // Extrair resumo executivo
    const resumoExecutivo = ValidadorRelatorio.extrairResumoExecutivo(conteudo);

    // Construir relatório
    const relatorio: Omit<Relatorio, 'id' | 'criadoEm'> = {
      titulo: 'Relatório Gerado por IA',
      conteudo,
      resumoExecutivo,
      secoes,
      registroId: '', // Será preenchido depois
      tipo: 'ia',
      template: 'completo',
      metadados: {
        provider: configIA.provider,
        modelo: configIA.modelo,
        temperatura: configIA.temperatura,
        tokensUsados,
        scoreQualidade: validacao.score,
      },
    };

    return {
      relatorio,
      validacao,
    };
  }

  /**
   * Sanitiza conteúdo para remover caracteres perigosos
   */
  static sanitizar(conteudo: string): string {
    return conteudo
      .replace(/[<>]/g, '') // Remove < e >
      .replace(/\n{4,}/g, '\n\n') // Remove quebras de linha excessivas
      .trim();
  }

  /**
   * Formata conteúdo para melhor legibilidade
   */
  static formatar(conteudo: string): string {
    // Normalizar quebras de linha
    let formatado = conteudo.replace(/\r\n/g, '\n');

    // Garantir espaçamento entre seções
    formatado = formatado.replace(/\n([A-Z][A-Z\s]+):/g, '\n\n$1:');

    // Melhorar formatação de listas
    formatado = formatado.replace(/^-\s/gm, '• ');

    return formatado.trim();
  }
}
