/**
 * CAMADA 5: ARMAZENAMENTO E AUDITORIA
 * Persistência de relatórios e registro de logs
 */

import { Relatorio, LogRelatorio, DadosInspeção, ResultadoGeracaoRelatorio } from './relatorioTypes';

export class ArmazenadorRelatorio {
  private static readonly CHAVE_RELATORIOS = 'relatorios';
  private static readonly CHAVE_LOGS = 'logsRelatorios';
  private static readonly CHAVE_HISTORICO = 'historicoRelatorios';

  /**
   * Salva um relatório no localStorage
   */
  static salvar(relatorio: Relatorio): void {
    try {
      const relatorios = this.obterTodos();
      relatorios.unshift(relatorio);

      // Manter apenas os últimos 100 relatórios
      if (relatorios.length > 100) {
        relatorios.pop();
      }

      localStorage.setItem(this.CHAVE_RELATORIOS, JSON.stringify(relatorios));
      console.log(`[Armazenamento] Relatório ${relatorio.id} salvo com sucesso`);
    } catch (erro) {
      console.error('[Armazenamento] Erro ao salvar relatório:', erro);
      throw new Error('Erro ao salvar relatório no localStorage');
    }
  }

  /**
   * Obtém todos os relatórios
   */
  static obterTodos(): Relatorio[] {
    try {
      const dados = localStorage.getItem(this.CHAVE_RELATORIOS);
      return dados ? JSON.parse(dados) : [];
    } catch (erro) {
      console.error('[Armazenamento] Erro ao obter relatórios:', erro);
      return [];
    }
  }

  /**
   * Obtém um relatório específico por ID
   */
  static obterPorId(id: string): Relatorio | null {
    const relatorios = this.obterTodos();
    return relatorios.find((r) => r.id === id) || null;
  }

  /**
   * Obtém relatórios de um registro específico
   */
  static obterPorRegistroId(registroId: string): Relatorio[] {
    const relatorios = this.obterTodos();
    return relatorios.filter((r) => r.registroId === registroId);
  }

  /**
   * Deleta um relatório
   */
  static deletar(id: string): void {
    try {
      const relatorios = this.obterTodos();
      const filtrados = relatorios.filter((r) => r.id !== id);
      localStorage.setItem(this.CHAVE_RELATORIOS, JSON.stringify(filtrados));
      console.log(`[Armazenamento] Relatório ${id} deletado`);
    } catch (erro) {
      console.error('[Armazenamento] Erro ao deletar relatório:', erro);
      throw new Error('Erro ao deletar relatório');
    }
  }

  /**
   * Atualiza um relatório existente
   */
  static atualizar(id: string, atualizacoes: Partial<Relatorio>): void {
    try {
      const relatorios = this.obterTodos();
      const indice = relatorios.findIndex((r) => r.id === id);

      if (indice === -1) {
        throw new Error(`Relatório ${id} não encontrado`);
      }

      relatorios[indice] = { ...relatorios[indice], ...atualizacoes };
      localStorage.setItem(this.CHAVE_RELATORIOS, JSON.stringify(relatorios));
      console.log(`[Armazenamento] Relatório ${id} atualizado`);
    } catch (erro) {
      console.error('[Armazenamento] Erro ao atualizar relatório:', erro);
      throw new Error('Erro ao atualizar relatório');
    }
  }

  /**
   * Registra um log de geração de relatório
   */
  static registrarLog(resultado: ResultadoGeracaoRelatorio, dados: DadosInspeção): void {
    try {
      const log: LogRelatorio = {
        timestamp: new Date().toISOString(),
        registroId: dados.id,
        relatorioId: resultado.relatorio?.id || 'N/A',
        sucesso: resultado.sucesso,
        metadados: resultado.metadados,
        erros: resultado.erros,
      };

      const logs = this.obterLogs();
      logs.unshift(log);

      // Manter apenas os últimos 1000 logs
      if (logs.length > 1000) {
        logs.pop();
      }

      localStorage.setItem(this.CHAVE_LOGS, JSON.stringify(logs));
      console.log(`[Auditoria] Log registrado para relatório ${log.relatorioId}`);
    } catch (erro) {
      console.error('[Auditoria] Erro ao registrar log:', erro);
    }
  }

  /**
   * Obtém todos os logs
   */
  static obterLogs(): LogRelatorio[] {
    try {
      const dados = localStorage.getItem(this.CHAVE_LOGS);
      return dados ? JSON.parse(dados) : [];
    } catch (erro) {
      console.error('[Auditoria] Erro ao obter logs:', erro);
      return [];
    }
  }

  /**
   * Obtém logs de um período específico
   */
  static obterLogsPorPeriodo(dataInicio: Date, dataFim: Date): LogRelatorio[] {
    const logs = this.obterLogs();
    return logs.filter((log) => {
      const data = new Date(log.timestamp);
      return data >= dataInicio && data <= dataFim;
    });
  }

  /**
   * Obtém estatísticas de geração
   */
  static obterEstatisticas(): {
    totalRelatorios: number;
    totalLogs: number;
    taxaSucesso: number;
    tempoMedioGeração: number;
    scoreQualidadeMedia: number;
    providersUsados: string[];
  } {
    const relatorios = this.obterTodos();
    const logs = this.obterLogs();

    const logsComSucesso = logs.filter((l) => l.sucesso);
    const temposGeração = logs.map((l) => l.metadados.tempoGeração);
    const scores = logs.map((l) => l.metadados.scoreQualidade);
    const providers = new Set(logs.map((l) => l.metadados.providerUsado));

    return {
      totalRelatorios: relatorios.length,
      totalLogs: logs.length,
      taxaSucesso:
        logs.length > 0
          ? Math.round((logsComSucesso.length / logs.length) * 100)
          : 0,
      tempoMedioGeração:
        temposGeração.length > 0
          ? Math.round(
              temposGeração.reduce((a, b) => a + b, 0) / temposGeração.length
            )
          : 0,
      scoreQualidadeMedia:
        scores.length > 0
          ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length)
          : 0,
      providersUsados: Array.from(providers),
    };
  }

  /**
   * Exporta dados de auditoria em JSON
   */
  static exportarAuditoria(): string {
    const relatorios = this.obterTodos();
    const logs = this.obterLogs();
    const estatisticas = this.obterEstatisticas();

    return JSON.stringify(
      {
        exportadoEm: new Date().toISOString(),
        estatisticas,
        relatorios,
        logs,
      },
      null,
      2
    );
  }

  /**
   * Limpa todos os relatórios e logs (CUIDADO!)
   */
  static limparTudo(): void {
    if (
      confirm(
        'Tem certeza que deseja deletar TODOS os relatórios e logs? Esta ação não pode ser desfeita!'
      )
    ) {
      localStorage.removeItem(this.CHAVE_RELATORIOS);
      localStorage.removeItem(this.CHAVE_LOGS);
      console.log('[Armazenamento] Todos os relatórios e logs foram deletados');
    }
  }

  /**
   * Obtém informações de uso de armazenamento
   */
  static obterInfoArmazenamento(): {
    tamanhoRelatorios: number;
    tamanhoLogs: number;
    tamanhoTotal: number;
    percentualUsado: number;
  } {
    const relatorios = localStorage.getItem(this.CHAVE_RELATORIOS) || '';
    const logs = localStorage.getItem(this.CHAVE_LOGS) || '';

    const tamanhoRelatorios = new Blob([relatorios]).size;
    const tamanhoLogs = new Blob([logs]).size;
    const tamanhoTotal = tamanhoRelatorios + tamanhoLogs;

    // localStorage típico tem ~5-10MB
    const limiteEstimado = 5 * 1024 * 1024; // 5MB

    return {
      tamanhoRelatorios,
      tamanhoLogs,
      tamanhoTotal,
      percentualUsado: Math.round((tamanhoTotal / limiteEstimado) * 100),
    };
  }

  /**
   * Cria backup de relatórios
   */
  static criarBackup(): string {
    const relatorios = this.obterTodos();
    const logs = this.obterLogs();
    const backup = {
      versao: '1.0',
      dataBackup: new Date().toISOString(),
      relatorios,
      logs,
    };

    return JSON.stringify(backup, null, 2);
  }

  /**
   * Restaura relatórios de um backup
   */
  static restaurarBackup(backupJson: string): boolean {
    try {
      const backup = JSON.parse(backupJson);

      if (!backup.versao || !Array.isArray(backup.relatorios)) {
        throw new Error('Formato de backup inválido');
      }

      localStorage.setItem(this.CHAVE_RELATORIOS, JSON.stringify(backup.relatorios));
      if (backup.logs) {
        localStorage.setItem(this.CHAVE_LOGS, JSON.stringify(backup.logs));
      }

      console.log('[Armazenamento] Backup restaurado com sucesso');
      return true;
    } catch (erro) {
      console.error('[Armazenamento] Erro ao restaurar backup:', erro);
      return false;
    }
  }
}
