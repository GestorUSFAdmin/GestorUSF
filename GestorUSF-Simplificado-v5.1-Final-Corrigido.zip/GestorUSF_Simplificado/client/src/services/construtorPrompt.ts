/**
 * CAMADA 2: CONSTRUÇÃO DE PROMPT
 * Seleção de template, injeção de contexto e otimização de tokens
 */

import { ConfiguracaoRelatorio, ConfiguracaoIA, DadosInspeção } from './relatorioTypes';
import { PreparadorDados } from './preparadorDados';

export class ConstrutorPrompt {
  /**
   * Templates de prompts para diferentes tipos de relatórios
   */
  static readonly TEMPLATES = {
    executivo: `Você é um especialista em gestão de saúde pública e auditoria de Unidades de Saúde da Família (USF).

Gere um RESUMO EXECUTIVO conciso e profissional (máximo 400 palavras) baseado nos dados:

{DADOS}

O resumo executivo deve incluir:
1. **Situação Atual** (1-2 frases): Contexto geral da inspeção
2. **Principais Achados** (3-5 pontos): Descobertas mais relevantes
3. **Inconformidades Críticas** (se houver): Problemas que requerem ação imediata
4. **Recomendações Prioritárias** (3-5 ações): Próximos passos recomendados
5. **Conclusão** (1-2 frases): Síntese dos pontos principais

Use linguagem clara, objetiva e profissional. Formate com títulos e bullet points para melhor legibilidade.`,

    completo: `Você é um especialista em auditoria de Unidades de Saúde da Família (USF) e conformidade em saúde pública.

Gere um RELATÓRIO COMPLETO, ESTRUTURADO e PROFISSIONAL baseado nos dados:

{DADOS}

O relatório deve conter as seguintes seções:

1. **RESUMO EXECUTIVO** (250-350 palavras)
   - Situação atual e contexto
   - Principais achados e descobertas
   - Inconformidades críticas (se houver)
   - Recomendações prioritárias

2. **DADOS DA INSPEÇÃO** (factual e objetivo)
   - Todos os dados coletados
   - Contexto da unidade
   - Informações sobre responsáveis e datas

3. **ANÁLISE SITUACIONAL** (interpretação e contexto)
   - Análise profunda dos dados
   - Padrões identificados
   - Possíveis causas raiz
   - Impacto das inconformidades

4. **INCONFORMIDADES IDENTIFICADAS** (detalhado e estruturado)
   - Cada inconformidade listada separadamente
   - Nível de gravidade (Crítica/Média/Baixa)
   - Impacto potencial
   - Evidências suportando a inconformidade

5. **RECOMENDAÇÕES E PLANO DE AÇÃO** (acionável e específico)
   - Ações corretivas para cada inconformidade
   - Prazos sugeridos
   - Responsáveis recomendados
   - Recursos necessários

6. **CONCLUSÃO** (síntese e próximos passos)
   - Resumo dos pontos principais
   - Avaliação geral da conformidade
   - Próximas etapas recomendadas
   - Data sugerida para acompanhamento

Use linguagem formal, técnica e profissional. Formate com títulos, subtítulos e bullet points. Seja específico e evite generalizações.`,

    tecnico: `Você é um especialista técnico em conformidade de saúde pública e auditoria de USF.

Gere um RELATÓRIO TÉCNICO DETALHADO baseado nos dados:

{DADOS}

O relatório deve incluir:

1. **ANÁLISE TÉCNICA PROFUNDA**
   - Avaliação técnica detalhada
   - Conformidade com normas técnicas
   - Análise de risco técnico

2. **REFERÊNCIAS NORMATIVAS**
   - Normas aplicáveis (ANVISA, MS, etc.)
   - Portarias relevantes
   - Legislação pertinente
   - Protocolos do SUS

3. **MÉTRICAS DE CONFORMIDADE**
   - Percentual de conformidade
   - Indicadores técnicos
   - Benchmarks do setor

4. **PLANO DE AÇÃO DETALHADO**
   - Ações corretivas específicas
   - Cronograma de implementação
   - Responsabilidades técnicas
   - Recursos necessários

5. **CRONOGRAMA DE IMPLEMENTAÇÃO**
   - Fases de implementação
   - Marcos e prazos
   - Dependências entre ações

Use termos técnicos apropriados e seja muito específico. Inclua referências a normas e regulamentações.`,

    customizado: `Você é um especialista em gestão de saúde pública e auditoria de Unidades de Saúde da Família (USF).

Gere um relatório profissional baseado nos dados:

{DADOS}

Estruture o relatório de forma clara e profissional, incluindo:
- Resumo executivo
- Análise dos dados
- Inconformidades identificadas
- Recomendações e plano de ação
- Conclusão

Use linguagem formal, técnica e profissional. Formate para melhor legibilidade com títulos e seções bem definidas.`,
  };

  /**
   * Constrói o prompt final para a IA
   */
  static construir(
    dados: DadosInspeção,
    config: ConfiguracaoRelatorio,
    configIA: ConfiguracaoIA
  ): string {
    // Preparar dados
    const preparacao = PreparadorDados.preparar(dados);
    const dadosFormatados = preparacao.dadosFormatados;

    // Selecionar template
    const template =
      this.TEMPLATES[config.template] || this.TEMPLATES.completo;

    // Injetar dados no template
    let prompt = template.replace('{DADOS}', dadosFormatados);

    // Adicionar instruções de nível de detalhe
    if (config.nivelDetalhe === 'resumido') {
      prompt += '\n\n**IMPORTANTE:** Mantenha o relatório conciso (máximo 500 palavras).';
    } else if (config.nivelDetalhe === 'detalhado') {
      prompt += '\n\n**IMPORTANTE:** Seja detalhado e completo (sem limite de palavras).';
    }

    // Adicionar instruções condicionais
    if (!config.incluirRecomendacoes) {
      prompt += '\n\n**IMPORTANTE:** NÃO inclua seção de recomendações.';
    }

    if (config.idioma === 'en-US') {
      prompt += '\n\n**IMPORTANTE:** Responda em INGLÊS.';
    }

    // Adicionar instruções de formatação
    prompt += '\n\n**FORMATAÇÃO:** Use markdown para melhor estrutura. Inclua títulos com #, ##, ### conforme necessário.';

    return prompt;
  }

  /**
   * Estima o número de tokens no prompt
   * Estimativa simples: 1 token ≈ 4 caracteres
   */
  static estimarTokens(prompt: string): number {
    return Math.ceil(prompt.length / 4);
  }

  /**
   * Valida se o prompt não excede o limite de tokens
   */
  static validarTamanho(prompt: string, maxTokens: number): boolean {
    const tokens = this.estimarTokens(prompt);
    return tokens <= maxTokens * 0.8; // Deixar 20% de margem
  }

  /**
   * Obtém informações sobre o template selecionado
   */
  static obterInfoTemplate(template: string): {
    nome: string;
    descricao: string;
    tamanhoEstimado: string;
  } {
    const infos: Record<string, any> = {
      executivo: {
        nome: 'Executivo',
        descricao: 'Resumo conciso para tomadores de decisão',
        tamanhoEstimado: '400-600 palavras',
      },
      completo: {
        nome: 'Completo',
        descricao: 'Relatório estruturado com todas as seções',
        tamanhoEstimado: '1500-2500 palavras',
      },
      tecnico: {
        nome: 'Técnico',
        descricao: 'Análise técnica profunda com referências normativas',
        tamanhoEstimado: '2000-3000 palavras',
      },
      customizado: {
        nome: 'Customizado',
        descricao: 'Estrutura flexível conforme necessário',
        tamanhoEstimado: 'Variável',
      },
    };

    return infos[template] || infos.completo;
  }
}
