/**
 * Tipos e Interfaces para o Sistema de Geração de Relatórios com IA
 * Arquitetura de 5 Camadas
 */

export interface Arquivo {
  id: string;
  nome: string;
  tamanho: number;
  tipo: string;
  conteudo: string;
}

export interface DadosInspeção {
  id: string;
  titulo: string;
  data: string;
  unidade: string;
  observacoes: string;
  inconformidades: string;
  arquivos?: Arquivo[];
  responsavel?: string;
  tipo?: string;
}

export type TemplateRelatorio = 'executivo' | 'completo' | 'tecnico' | 'customizado';
export type NivelDetalhe = 'resumido' | 'normal' | 'detalhado';
export type Idioma = 'pt-BR' | 'en-US';
export type ProviderIA = 'perplexity' | 'claude' | 'gemini';

export interface ConfiguracaoRelatorio {
  template: TemplateRelatorio;
  incluirGraficos: boolean;
  incluirRecomendacoes: boolean;
  incluirAnexos: boolean;
  idioma: Idioma;
  nivelDetalhe: NivelDetalhe;
}

export interface ConfiguracaoIA {
  provider: ProviderIA;
  apiKey: string;
  modelo: string;
  temperatura: number;
  maxTokens: number;
  providerFallback?: ProviderIA[];
}

export interface SecoeRelatorio {
  resumoExecutivo: string;
  dadosInspeção: string;
  analise: string;
  inconformidades: string;
  recomendacoes: string;
  conclusao: string;
}

export interface MetadadosRelatorio {
  provider: ProviderIA;
  modelo: string;
  temperatura: number;
  tokensUsados: number;
  scoreQualidade: number;
}

export interface Relatorio {
  id: string;
  titulo: string;
  conteudo: string;
  resumoExecutivo: string;
  secoes: SecoeRelatorio;
  registroId: string;
  criadoEm: string;
  tipo: 'ia' | 'manual';
  template: string;
  metadados: MetadadosRelatorio;
}

export interface ValidacaoQualidade {
  valido: boolean;
  score: number;
  problemas: string[];
}

export interface RespostaChamadaIA {
  conteudo: string;
  tokensUsados: number;
}

export interface ResultadoProcessamento {
  relatorio: Omit<Relatorio, 'id' | 'criadoEm'>;
  validacao: ValidacaoQualidade;
}

export interface ResultadoGeracaoRelatorio {
  sucesso: boolean;
  relatorio: Relatorio | null;
  metadados: {
    tempoGeração: number;
    providerUsado: ProviderIA;
    modeloUsado: string;
    tokensUsados: number;
    scoreQualidade: number;
    validacoes: string[];
  };
  erros?: string[];
}

export interface LogRelatorio {
  timestamp: string;
  registroId: string;
  relatorioId: string;
  sucesso: boolean;
  metadados: {
    tempoGeração: number;
    providerUsado: ProviderIA;
    modeloUsado: string;
    tokensUsados: number;
    scoreQualidade: number;
    validacoes: string[];
  };
  erros?: string[];
}
