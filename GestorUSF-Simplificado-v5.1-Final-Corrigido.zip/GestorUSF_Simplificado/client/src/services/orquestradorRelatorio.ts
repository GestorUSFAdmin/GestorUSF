/**
 * ORQUESTRADOR PRINCIPAL
 * Integra todas as 5 camadas em um fluxo coeso
 */

import { DadosInspeção, ConfiguracaoRelatorio, ConfiguracaoIA, ResultadoGeracaoRelatorio, Relatorio } from './relatorioTypes';
import { PreparadorDados } from './preparadorDados';
import { ConstrutorPrompt } from './construtorPrompt';
import { ChamadorIA } from './chamadorIA';
import { ProcessadorResposta } from './processadorResposta';
import { ArmazenadorRelatorio } from './armazenadorRelatorio';

export class OrquestradorRelatorio {
  /**
   * Gera um relatório completo com todas as 5 camadas
   */
  static async gerar(
    dados: DadosInspeção,
    configRelatorio: ConfiguracaoRelatorio,
    configIA: ConfiguracaoIA
  ): Promise<ResultadoGeracaoRelatorio> {
    const tempoInicio = Date.now();
    console.log('[Orquestrador] Iniciando geração de relatório...');

    try {
      // ============================================
      // CAMADA 1: PREPARAÇÃO DE DADOS
      // ============================================
      console.log('[Orquestrador] Camada 1: Preparando dados...');
      const preparacao = PreparadorDados.preparar(dados);

      if (!preparacao.valido) {
        throw new Error('Dados inválidos para geração de relatório');
      }

      // ============================================
      // CAMADA 2: CONSTRUÇÃO DE PROMPT
      // ============================================
      console.log('[Orquestrador] Camada 2: Construindo prompt...');
      const prompt = ConstrutorPrompt.construir(dados, configRelatorio, configIA);
      const tokensEstimados = ConstrutorPrompt.estimarTokens(prompt);

      console.log(`[Orquestrador] Tokens estimados: ${tokensEstimados}`);

      if (!ConstrutorPrompt.validarTamanho(prompt, configIA.maxTokens)) {
        console.warn('[Orquestrador] Aviso: Prompt pode exceder limite de tokens');
      }

      // ============================================
      // CAMADA 3: CHAMADA À IA
      // ============================================
      console.log('[Orquestrador] Camada 3: Chamando IA...');
      const { conteudo, tokensUsados } = await ChamadorIA.chamar(prompt, configIA);

      console.log(`[Orquestrador] Resposta recebida: ${conteudo.length} caracteres`);

      // ============================================
      // CAMADA 4: PROCESSAMENTO DE RESPOSTA
      // ============================================
      console.log('[Orquestrador] Camada 4: Processando resposta...');
      const { relatorio: relatorioBase, validacao } = ProcessadorResposta.processar(
        conteudo,
        tokensUsados,
        configIA
      );

      console.log(`[Orquestrador] Score de qualidade: ${validacao.score}%`);

      if (!validacao.valido) {
        console.warn(`[Orquestrador] Avisos de qualidade: ${validacao.problemas.join(', ')}`);
      }

      // Criar relatório final
      const relatorio: Relatorio = {
        ...relatorioBase,
        id: `rel_${Date.now()}`,
        registroId: dados.id,
        criadoEm: new Date().toISOString(),
      };

      // ============================================
      // CAMADA 5: ARMAZENAMENTO E AUDITORIA
      // ============================================
      console.log('[Orquestrador] Camada 5: Armazenando relatório...');
      ArmazenadorRelatorio.salvar(relatorio);

      const tempoGeração = Date.now() - tempoInicio;
      console.log(`[Orquestrador] Relatório gerado em ${tempoGeração}ms`);

      // Criar resultado
      const resultado: ResultadoGeracaoRelatorio = {
        sucesso: validacao.valido,
        relatorio,
        metadados: {
          tempoGeração,
          providerUsado: configIA.provider,
          modeloUsado: configIA.modelo,
          tokensUsados,
          scoreQualidade: validacao.score,
          validacoes: validacao.problemas.length === 0 ? ['✓ Sem problemas'] : validacao.problemas,
        },
      };

      // Registrar log
      ArmazenadorRelatorio.registrarLog(resultado, dados);

      return resultado;
    } catch (erro) {
      const tempoGeração = Date.now() - tempoInicio;
      const mensagem = erro instanceof Error ? erro.message : 'Erro desconhecido';

      console.error(`[Orquestrador] Erro ao gerar relatório: ${mensagem}`);

      const resultado: ResultadoGeracaoRelatorio = {
        sucesso: false,
        relatorio: null,
        metadados: {
          tempoGeração,
          providerUsado: configIA.provider,
          modeloUsado: configIA.modelo,
          tokensUsados: 0,
          scoreQualidade: 0,
          validacoes: [],
        },
        erros: [mensagem],
      };

      // Registrar log de erro
      ArmazenadorRelatorio.registrarLog(resultado, dados);

      throw erro;
    }
  }

  /**
   * Regenera um relatório existente com nova configuração
   */
  static async regenerar(
    relatorioId: string,
    configRelatorio: ConfiguracaoRelatorio,
    configIA: ConfiguracaoIA,
    dados: DadosInspeção
  ): Promise<ResultadoGeracaoRelatorio> {
    console.log(`[Orquestrador] Regenerando relatório ${relatorioId}...`);

    // Deletar relatório antigo
    ArmazenadorRelatorio.deletar(relatorioId);

    // Gerar novo
    return this.gerar(dados, configRelatorio, configIA);
  }

  /**
   * Obtém estatísticas de geração
   */
  static obterEstatisticas() {
    return ArmazenadorRelatorio.obterEstatisticas();
  }

  /**
   * Exporta auditoria completa
   */
  static exportarAuditoria(): string {
    return ArmazenadorRelatorio.exportarAuditoria();
  }

  /**
   * Cria backup de todos os relatórios
   */
  static criarBackup(): string {
    return ArmazenadorRelatorio.criarBackup();
  }

  /**
   * Restaura relatórios de um backup
   */
  static restaurarBackup(backupJson: string): boolean {
    return ArmazenadorRelatorio.restaurarBackup(backupJson);
  }
}
