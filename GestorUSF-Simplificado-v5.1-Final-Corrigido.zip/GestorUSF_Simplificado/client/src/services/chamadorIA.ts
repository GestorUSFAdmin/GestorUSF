/**
 * CAMADA 3: CHAMADA À IA
 * Integração com múltiplos provedores, retry automático e fallback
 */

import { ConfiguracaoIA, RespostaChamadaIA, ProviderIA } from './relatorioTypes';

export class ChamadorIA {
  /**
   * Aguarda um tempo especificado (em ms)
   */
  private static async aguardar(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  /**
   * Chama a API de IA com retry automático e fallback
   */
  static async chamar(
    prompt: string,
    config: ConfiguracaoIA,
    tentativa: number = 1,
    maxTentativas: number = 3
  ): Promise<RespostaChamadaIA> {
    try {
      console.log(`[IA] Tentativa ${tentativa}/${maxTentativas} - Provider: ${config.provider}`);

      let resposta: RespostaChamadaIA;

      switch (config.provider) {
        case 'perplexity':
          resposta = await this.chamarPerplexity(prompt, config);
          break;
        case 'claude':
          resposta = await this.chamarClaude(prompt, config);
          break;
        case 'gemini':
          resposta = await this.chamarGemini(prompt, config);
          break;
        default:
          throw new Error(`Provedor não suportado: ${config.provider}`);
      }

      console.log(`[IA] Sucesso! Tokens usados: ${resposta.tokensUsados}`);
      return resposta;
    } catch (erro) {
      const mensagemErro = erro instanceof Error ? erro.message : 'Erro desconhecido';
      console.error(`[IA] Erro na tentativa ${tentativa}:`, mensagemErro);

      // Retry automático
      if (tentativa < maxTentativas) {
        console.log(`[IA] Aguardando 2 segundos antes de tentar novamente...`);
        await this.aguardar(2000);
        return this.chamar(prompt, config, tentativa + 1, maxTentativas);
      }

      // Fallback para outro provedor
      if (config.providerFallback && config.providerFallback.length > 0) {
        const proximoProvider = config.providerFallback[0];
        console.log(`[IA] Tentando fallback com provider: ${proximoProvider}`);

        const novaConfig: ConfiguracaoIA = {
          ...config,
          provider: proximoProvider,
          providerFallback: config.providerFallback.slice(1),
        };

        return this.chamar(prompt, novaConfig, 1, maxTentativas);
      }

      throw new Error(
        `Falha ao chamar IA após ${maxTentativas} tentativas. Último erro: ${mensagemErro}`
      );
    }
  }

  /**
   * Chama API Perplexity
   */
  private static async chamarPerplexity(
    prompt: string,
    config: ConfiguracaoIA
  ): Promise<RespostaChamadaIA> {
    const response = await fetch('https://api.perplexity.ai/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${config.apiKey}`,
      },
      body: JSON.stringify({
        model: config.modelo || 'sonar-pro',
        messages: [{ role: 'user', content: prompt }],
        temperature: config.temperatura || 0.7,
        max_tokens: config.maxTokens || 2000,
      }),
    });

    if (!response.ok) {
      const erro = await response.json().catch(() => ({}));
      throw new Error(
        `Erro na API Perplexity: ${response.statusText} - ${erro.error?.message || ''}`
      );
    }

    const data = await response.json();

    if (!data.choices || !data.choices[0] || !data.choices[0].message) {
      throw new Error('Resposta inválida da API Perplexity');
    }

    return {
      conteudo: data.choices[0].message.content,
      tokensUsados: data.usage?.total_tokens || 0,
    };
  }

  /**
   * Chama API Claude (Anthropic)
   */
  private static async chamarClaude(
    prompt: string,
    config: ConfiguracaoIA
  ): Promise<RespostaChamadaIA> {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': config.apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: config.modelo || 'claude-3-opus-20240229',
        max_tokens: config.maxTokens || 2000,
        messages: [{ role: 'user', content: prompt }],
      }),
    });

    if (!response.ok) {
      const erro = await response.json().catch(() => ({}));
      throw new Error(
        `Erro na API Claude: ${response.statusText} - ${erro.error?.message || ''}`
      );
    }

    const data = await response.json();

    if (!data.content || !data.content[0] || !data.content[0].text) {
      throw new Error('Resposta inválida da API Claude');
    }

    return {
      conteudo: data.content[0].text,
      tokensUsados: data.usage?.output_tokens || 0,
    };
  }

  /**
   * Chama API Google Gemini
   */
  private static async chamarGemini(
    prompt: string,
    config: ConfiguracaoIA
  ): Promise<RespostaChamadaIA> {
    const modelo = config.modelo || 'gemini-2.5-flash';

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${modelo}:generateContent?key=${config.apiKey}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [
            {
              parts: [{ text: prompt }],
            },
          ],
          generationConfig: {
            temperature: config.temperatura || 0.7,
            maxOutputTokens: config.maxTokens || 2000,
          },
        }),
      }
    );

    if (!response.ok) {
      const erro = await response.json().catch(() => ({}));
      throw new Error(
        `Erro na API Gemini: ${response.statusText} - ${erro.error?.message || ''}`
      );
    }

    const data = await response.json();

    if (
      !data.candidates ||
      !data.candidates[0] ||
      !data.candidates[0].content ||
      !data.candidates[0].content.parts ||
      !data.candidates[0].content.parts[0]
    ) {
      throw new Error('Resposta inválida da API Gemini');
    }

    return {
      conteudo: data.candidates[0].content.parts[0].text,
      tokensUsados: 0, // Gemini não retorna token count
    };
  }

  /**
   * Testa conexão com um provedor de IA
   */
  static async testarConexao(config: ConfiguracaoIA): Promise<{
    sucesso: boolean;
    mensagem: string;
    tempo: number;
  }> {
    const tempoInicio = Date.now();

    try {
      const promptTeste = 'Responda com uma palavra: OK';

      await this.chamar(promptTeste, config, 1, 1);

      const tempo = Date.now() - tempoInicio;

      return {
        sucesso: true,
        mensagem: `Conexão bem-sucedida com ${config.provider}`,
        tempo,
      };
    } catch (erro) {
      const tempo = Date.now() - tempoInicio;
      const mensagem = erro instanceof Error ? erro.message : 'Erro desconhecido';

      return {
        sucesso: false,
        mensagem: `Falha ao conectar com ${config.provider}: ${mensagem}`,
        tempo,
      };
    }
  }
}
