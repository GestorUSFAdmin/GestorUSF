import React, { createContext, useContext, useState, useEffect } from "react";

export interface User {
  id: string;
  nome: string;
  email: string;
  nivel: "Administrador" | "Gerente" | "Operador";
}

interface AuthContextType {
  user: User | null;
  login: (email: string, senha: string) => Promise<void>;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Carregar usuário do localStorage ao iniciar
  useEffect(() => {
    const savedUser = localStorage.getItem("currentUser");
    if (savedUser) {
      try {
        setUser(JSON.parse(savedUser));
      } catch (e) {
        console.error("Erro ao carregar usuário:", e);
      }
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, senha: string) => {
    setIsLoading(true);
    try {
      // Dados de teste - em produção seria uma chamada à API
      const usuarios = [
        {
          id: "admin",
          nome: "Administrador",
          email: "admin@gestorUSF.com",
          nivel: "Administrador" as const,
          senha: "123",
        },
        {
          id: "gerente",
          nome: "Maria Silva",
          email: "maria@gestorUSF.com",
          nivel: "Gerente" as const,
          senha: "456",
        },
        {
          id: "operador",
          nome: "João Carlos",
          email: "joao@gestorUSF.com",
          nivel: "Operador" as const,
          senha: "789",
        },
      ];

      const usuarioEncontrado = usuarios.find(
        (u) => u.email === email && u.senha === senha
      );

      if (!usuarioEncontrado) {
        throw new Error("Email ou senha inválidos");
      }

      const { senha: _, ...usuarioSemSenha } = usuarioEncontrado;
      setUser(usuarioSemSenha as User);
      localStorage.setItem("currentUser", JSON.stringify(usuarioSemSenha));
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem("currentUser");
  };

  return (
    <AuthContext.Provider value={{ user, login, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth deve ser usado dentro de AuthProvider");
  }
  return context;
}
