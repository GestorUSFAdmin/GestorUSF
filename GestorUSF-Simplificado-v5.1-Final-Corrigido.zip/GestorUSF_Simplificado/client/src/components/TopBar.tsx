import { useState, useRef } from "react";
import { Download, Upload, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import GlobalSearch from "@/components/GlobalSearch";

interface BackupData {
  timestamp: string;
  version: string;
  data: {
    registros: any[];
    relatorios: any[];
    unidades: any[];
    usuarios: any[];
    configIA: any;
  };
}

export default function TopBar() {
  const { user } = useAuth();
  const [isBackingUp, setIsBackingUp] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Função de Backup Completo
  const handleBackup = async () => {
    setIsBackingUp(true);
    try {
      // Coletar todos os dados do localStorage
      const registros = JSON.parse(localStorage.getItem("registros") || "[]");
      const relatorios = JSON.parse(localStorage.getItem("relatorios") || "[]");
      const unidades = JSON.parse(localStorage.getItem("unidades") || "[]");
      const usuarios = JSON.parse(localStorage.getItem("usuarios") || "[]");
      const configIA = JSON.parse(localStorage.getItem("configIA") || "{}");

      // Criar objeto de backup
      const backupData: BackupData = {
        timestamp: new Date().toISOString(),
        version: "4.0",
        data: {
          registros,
          relatorios,
          unidades,
          usuarios,
          configIA,
        },
      };

      // Converter para JSON e criar blob
      const jsonString = JSON.stringify(backupData, null, 2);
      const blob = new Blob([jsonString], { type: "application/json" });

      // Criar link de download
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `GestorUSF-Backup-${new Date().getTime()}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      toast.success("Backup realizado com sucesso!");
    } catch (error) {
      console.error("Erro ao fazer backup:", error);
      toast.error("Erro ao fazer backup");
    } finally {
      setIsBackingUp(false);
    }
  };

  // Função de Restauração
  const handleRestore = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsRestoring(true);
    try {
      const text = await file.text();
      const backupData: BackupData = JSON.parse(text);

      // Validar estrutura do backup
      if (
        !backupData.data ||
        !backupData.timestamp ||
        !backupData.version
      ) {
        throw new Error("Arquivo de backup inválido");
      }

      // Restaurar dados
      localStorage.setItem("registros", JSON.stringify(backupData.data.registros));
      localStorage.setItem("relatorios", JSON.stringify(backupData.data.relatorios));
      localStorage.setItem("unidades", JSON.stringify(backupData.data.unidades));
      localStorage.setItem("usuarios", JSON.stringify(backupData.data.usuarios));
      localStorage.setItem("configIA", JSON.stringify(backupData.data.configIA));

      toast.success("Backup restaurado com sucesso! Recarregando...");

      // Recarregar página após 2 segundos
      setTimeout(() => {
        window.location.reload();
      }, 2000);
    } catch (error) {
      console.error("Erro ao restaurar backup:", error);
      toast.error(
        error instanceof Error ? error.message : "Erro ao restaurar backup"
      );
    } finally {
      setIsRestoring(false);
      // Limpar input
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    }
  };

  return (
    <div className="bg-white border-b border-gray-200 px-4 py-3 sticky top-0 z-30">
      <div className="flex items-center gap-4 h-12">
        {/* Barra de Pesquisa Global - 50% */}
        <div className="flex-1" style={{ width: "50%" }}>
          <GlobalSearch />
        </div>

        {/* Botão de Backup - 15% */}
        <div style={{ width: "15%" }} className="flex justify-center">
          <Button
            onClick={handleBackup}
            disabled={isBackingUp}
            variant="outline"
            size="sm"
            className="w-full gap-2 text-xs"
            title="Fazer backup de todos os dados"
          >
            {isBackingUp ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span className="hidden sm:inline">Backup...</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                <span className="hidden sm:inline">Backup</span>
              </>
            )}
          </Button>
        </div>

        {/* Botão de Upload - 15% */}
        <div style={{ width: "15%" }} className="flex justify-center">
          <Button
            onClick={() => fileInputRef.current?.click()}
            disabled={isRestoring}
            variant="outline"
            size="sm"
            className="w-full gap-2 text-xs"
            title="Restaurar backup"
          >
            {isRestoring ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span className="hidden sm:inline">Restaurando...</span>
              </>
            ) : (
              <>
                <Upload className="w-4 h-4" />
                <span className="hidden sm:inline">Upload</span>
              </>
            )}
          </Button>
          <input
            ref={fileInputRef}
            type="file"
            accept=".json"
            onChange={handleRestore}
            className="hidden"
            disabled={isRestoring}
          />
        </div>

        {/* Nome do Usuário - 10% */}
        <div style={{ width: "10%" }} className="flex justify-end">
          <div className="flex items-center gap-2">
            <div className="text-right hidden sm:block">
              <p className="text-xs font-semibold text-gray-900 truncate">
                {user?.email?.split("@")[0]}
              </p>
              <p className="text-xs text-gray-500 capitalize">{user?.nivel}</p>
            </div>
            <div className="w-8 h-8 bg-green-600 rounded-full flex items-center justify-center text-white text-xs font-bold">
              {user?.email?.charAt(0).toUpperCase()}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
