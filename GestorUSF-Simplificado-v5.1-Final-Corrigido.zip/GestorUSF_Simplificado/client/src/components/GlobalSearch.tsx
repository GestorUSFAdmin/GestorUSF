import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Search, X } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";

interface SearchResult {
  id: string;
  title: string;
  description: string;
  path: string;
  type: "registro" | "relatorio" | "unidade" | "usuario" | "pagina";
  icon: string;
}

export default function GlobalSearch() {
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<SearchResult[]>([]);
  const [, navigate] = useLocation();

  // Carregar dados para busca
  const getAllSearchData = (): SearchResult[] => {
    const data: SearchResult[] = [];

    // Páginas principais
    const pages = [
      { title: "Dashboard", path: "/", type: "pagina" as const, icon: "📊" },
      { title: "Registros", path: "/registros", type: "pagina" as const, icon: "📋" },
      { title: "Relatórios", path: "/relatorios", type: "pagina" as const, icon: "📄" },
      { title: "Unidades", path: "/unidades", type: "pagina" as const, icon: "🏢" },
      { title: "Usuários", path: "/usuarios", type: "pagina" as const, icon: "👥" },
      { title: "Configurações IA", path: "/config-ia", type: "pagina" as const, icon: "⚙️" },
    ];

    pages.forEach((page) => {
      data.push({
        id: page.path,
        title: page.title,
        description: `Ir para ${page.title}`,
        path: page.path,
        type: page.type,
        icon: page.icon,
      });
    });

    // Registros
    const registros = JSON.parse(localStorage.getItem("registros") || "[]");
    registros.forEach((reg: any) => {
      data.push({
        id: reg.id,
        title: reg.titulo,
        description: `Registro - ${reg.unidade} (${new Date(reg.data).toLocaleDateString("pt-BR")})`,
        path: "/registros",
        type: "registro" as const,
        icon: "📋",
      });
    });

    // Relatórios
    const relatorios = JSON.parse(localStorage.getItem("relatorios") || "[]");
    relatorios.forEach((rel: any) => {
      data.push({
        id: rel.id,
        title: rel.titulo,
        description: `Relatório - Gerado em ${new Date(rel.criadoEm).toLocaleDateString("pt-BR")}`,
        path: "/relatorios",
        type: "relatorio" as const,
        icon: "📄",
      });
    });

    // Unidades
    const unidades = Array.from(new Set(registros.map((r: any) => r.unidade))).filter(Boolean);
    (unidades as string[]).forEach((unidade) => {
      data.push({
        id: `unidade_${unidade}`,
        title: unidade,
        description: `Unidade de Saúde`,
        path: "/unidades",
        type: "unidade" as const,
        icon: "🏢",
      });
    });

    return data;
  };

  // Buscar quando query muda
  useEffect(() => {
    if (query.trim() === "") {
      setResults([]);
      return;
    }

    const allData = getAllSearchData();
    const filtered = allData.filter(
      (item) =>
        item.title.toLowerCase().includes(query.toLowerCase()) ||
        item.description.toLowerCase().includes(query.toLowerCase())
    );

    setResults(filtered.slice(0, 10)); // Limitar a 10 resultados
  }, [query]);

  // Atalho de teclado Cmd+K / Ctrl+K
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setIsOpen(!isOpen);
        setQuery("");
      }

      if (e.key === "Escape") {
        setIsOpen(false);
        setQuery("");
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen]);

  const handleSelectResult = (result: SearchResult) => {
    navigate(result.path);
    setIsOpen(false);
    setQuery("");
  };

  return (
    <>
      {/* Botão de Busca na Barra Superior */}
      <button
        onClick={() => setIsOpen(true)}
        className="hidden md:flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg text-gray-600 text-sm transition"
      >
        <Search className="w-4 h-4" />
        <span>Buscar...</span>
        <kbd className="ml-auto text-xs bg-white px-2 py-1 rounded border border-gray-300">
          ⌘K
        </kbd>
      </button>

      {/* Modal de Busca */}
      {isOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-start justify-center pt-20 z-50">
          <Card className="w-full max-w-2xl shadow-2xl">
            {/* Input */}
            <div className="flex items-center gap-3 p-4 border-b">
              <Search className="w-5 h-5 text-gray-400" />
              <Input
                autoFocus
                placeholder="Buscar registros, relatórios, páginas..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="border-0 focus:ring-0 text-lg"
              />
              <button
                onClick={() => {
                  setIsOpen(false);
                  setQuery("");
                }}
                className="p-1 hover:bg-gray-100 rounded"
              >
                <X className="w-5 h-5 text-gray-400" />
              </button>
            </div>

            {/* Resultados */}
            <div className="max-h-96 overflow-y-auto">
              {results.length === 0 && query.trim() !== "" ? (
                <div className="p-8 text-center text-gray-500">
                  <p>Nenhum resultado encontrado para "{query}"</p>
                </div>
              ) : results.length === 0 ? (
                <div className="p-8 text-center text-gray-500">
                  <p>Digite para buscar registros, relatórios e páginas</p>
                </div>
              ) : (
                <div className="divide-y">
                  {results.map((result) => (
                    <button
                      key={result.id}
                      onClick={() => handleSelectResult(result)}
                      className="w-full text-left px-4 py-3 hover:bg-gray-50 transition flex items-start gap-3"
                    >
                      <span className="text-xl">{result.icon}</span>
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-gray-900 truncate">
                          {result.title}
                        </p>
                        <p className="text-sm text-gray-600 truncate">
                          {result.description}
                        </p>
                      </div>
                      <span className="text-xs bg-gray-100 px-2 py-1 rounded text-gray-600 whitespace-nowrap">
                        {result.type === "pagina" ? "Página" : result.type === "registro" ? "Registro" : result.type === "relatorio" ? "Relatório" : result.type === "unidade" ? "Unidade" : "Usuário"}
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="p-3 border-t bg-gray-50 text-xs text-gray-600 flex justify-between">
              <div className="space-x-2">
                <kbd className="bg-white px-2 py-1 rounded border">↑↓</kbd>
                <span>Navegar</span>
                <kbd className="bg-white px-2 py-1 rounded border ml-2">↵</kbd>
                <span>Selecionar</span>
              </div>
              <div>
                <kbd className="bg-white px-2 py-1 rounded border">Esc</kbd>
                <span className="ml-2">Fechar</span>
              </div>
            </div>
          </Card>
        </div>
      )}
    </>
  );
}
