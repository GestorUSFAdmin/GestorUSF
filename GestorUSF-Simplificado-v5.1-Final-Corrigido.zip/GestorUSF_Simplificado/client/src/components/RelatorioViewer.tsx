import { useState } from "react";
import {
  X,
  ZoomIn,
  ZoomOut,
  Printer,
  Eye,
  Copy,
  Download,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { toast } from "sonner";

interface RelatorioViewerProps {
  titulo: string;
  conteudo: string;
  onClose: () => void;
}

export default function RelatorioViewer({
  titulo,
  conteudo,
  onClose,
}: RelatorioViewerProps) {
  const [zoom, setZoom] = useState(100);
  const [modoLeitura, setModoLeitura] = useState(false);
  const [selectedText, setSelectedText] = useState("");

  const handleZoomIn = () => {
    setZoom(Math.min(zoom + 10, 200));
  };

  const handleZoomOut = () => {
    setZoom(Math.max(zoom - 10, 50));
  };

  const handleResetZoom = () => {
    setZoom(100);
  };

  const handlePrint = () => {
    const printWindow = window.open("", "", "height=600,width=800");
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>${titulo}</title>
            <style>
              body { font-family: Arial, sans-serif; margin: 20px; line-height: 1.6; }
              h1 { color: #2ecc71; border-bottom: 2px solid #2ecc71; padding-bottom: 10px; }
              pre { background: #f5f5f5; padding: 15px; border-radius: 5px; overflow-x: auto; }
              @media print { body { margin: 0; } }
            </style>
          </head>
          <body>
            <h1>${titulo}</h1>
            <pre>${conteudo}</pre>
            <p style="color: #999; font-size: 12px; margin-top: 30px;">
              Gerado por GestorUSF em ${new Date().toLocaleDateString("pt-BR")} às ${new Date().toLocaleTimeString("pt-BR")}
            </p>
          </body>
        </html>
      `);
      printWindow.document.close();
      printWindow.print();
    }
  };

  const handleCopyAll = () => {
    navigator.clipboard.writeText(conteudo);
    toast.success("Relatório copiado para a área de transferência!");
  };

  const handleCopySelected = () => {
    if (selectedText) {
      navigator.clipboard.writeText(selectedText);
      toast.success("Texto copiado!");
    }
  };

  const handleDownloadTxt = () => {
    const element = document.createElement("a");
    const file = new Blob([conteudo], { type: "text/plain" });
    element.href = URL.createObjectURL(file);
    element.download = `${titulo}_${new Date().getTime()}.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
    URL.revokeObjectURL(element.href);
    toast.success("Relatório baixado em TXT!");
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl">
        {/* Header */}
        <div className="bg-gradient-to-r from-green-600 to-green-700 text-white p-4 flex items-center justify-between rounded-t-lg">
          <h2 className="text-xl font-bold truncate">{titulo}</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-green-500 rounded-lg transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Toolbar */}
        <div className="bg-gray-100 border-b p-3 flex flex-wrap items-center gap-2 overflow-x-auto">
          <div className="flex items-center gap-1 bg-white rounded-lg p-1 border">
            <Button
              onClick={handleZoomOut}
              variant="ghost"
              size="sm"
              className="h-8 w-8 p-0"
              title="Diminuir zoom"
            >
              <ZoomOut className="w-4 h-4" />
            </Button>
            <span className="text-sm font-semibold text-gray-700 w-12 text-center">
              {zoom}%
            </span>
            <Button
              onClick={handleZoomIn}
              variant="ghost"
              size="sm"
              className="h-8 w-8 p-0"
              title="Aumentar zoom"
            >
              <ZoomIn className="w-4 h-4" />
            </Button>
            <Button
              onClick={handleResetZoom}
              variant="ghost"
              size="sm"
              className="h-8 px-2 text-xs"
              title="Resetar zoom"
            >
              Resetar
            </Button>
          </div>

          <div className="flex-1" />

          <Button
            onClick={() => setModoLeitura(!modoLeitura)}
            variant={modoLeitura ? "default" : "outline"}
            size="sm"
            className="gap-2"
            title="Modo de leitura sem distrações"
          >
            <Eye className="w-4 h-4" />
            <span className="hidden sm:inline">
              {modoLeitura ? "Sair" : "Modo"} Leitura
            </span>
          </Button>

          <Button
            onClick={handlePrint}
            variant="outline"
            size="sm"
            className="gap-2"
            title="Imprimir relatório"
          >
            <Printer className="w-4 h-4" />
            <span className="hidden sm:inline">Imprimir</span>
          </Button>

          <Button
            onClick={handleCopyAll}
            variant="outline"
            size="sm"
            className="gap-2"
            title="Copiar todo o relatório"
          >
            <Copy className="w-4 h-4" />
            <span className="hidden sm:inline">Copiar</span>
          </Button>

          <Button
            onClick={handleDownloadTxt}
            variant="outline"
            size="sm"
            className="gap-2"
            title="Baixar como TXT"
          >
            <Download className="w-4 h-4" />
            <span className="hidden sm:inline">TXT</span>
          </Button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-auto">
          {modoLeitura ? (
            // Modo Leitura
            <div className="bg-gradient-to-b from-amber-50 to-amber-100 p-8 md:p-12 min-h-full">
              <div
                className="max-w-2xl mx-auto bg-white rounded-lg p-8 shadow-lg"
                style={{ fontSize: `${zoom * 0.14}px` }}
              >
                <h1 className="text-3xl font-bold text-gray-900 mb-6 border-b-2 border-green-600 pb-4">
                  {titulo}
                </h1>
                <div
                  className="text-gray-800 leading-relaxed whitespace-pre-wrap select-text"
                  onMouseUp={() => {
                    const selected = window.getSelection()?.toString() || "";
                    setSelectedText(selected);
                  }}
                >
                  {conteudo}
                </div>
                <div className="mt-8 pt-6 border-t text-sm text-gray-500">
                  <p>
                    Gerado por GestorUSF em{" "}
                    {new Date().toLocaleDateString("pt-BR")} às{" "}
                    {new Date().toLocaleTimeString("pt-BR")}
                  </p>
                </div>
              </div>
            </div>
          ) : (
            // Modo Normal
            <div className="p-6 bg-white">
              <div
                className="text-gray-800 leading-relaxed whitespace-pre-wrap select-text font-mono"
                style={{ fontSize: `${zoom * 0.14}px` }}
                onMouseUp={() => {
                  const selected = window.getSelection()?.toString() || "";
                  setSelectedText(selected);
                }}
              >
                {conteudo}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-gray-50 border-t p-4 flex items-center justify-between text-sm text-gray-600">
          <span>
            Texto selecionado: {selectedText.length > 0 && `${selectedText.length} caracteres`}
          </span>
          {selectedText.length > 0 && (
            <Button
              onClick={handleCopySelected}
              size="sm"
              className="bg-green-600 hover:bg-green-700 text-white"
            >
              <Copy className="w-4 h-4 mr-1" />
              Copiar Seleção
            </Button>
          )}
        </div>
      </Card>
    </div>
  );
}
