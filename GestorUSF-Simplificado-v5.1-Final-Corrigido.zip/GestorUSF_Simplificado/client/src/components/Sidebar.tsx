import { useState } from "react";
import { useLocation } from "wouter";
import {
  BarChart3,
  FileText,
  Clipboard,
  Building2,
  Users,
  Settings,
  Menu,
  X,
  LogOut,
} from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";

interface NavItem {
  label: string;
  path: string;
  icon: React.ReactNode;
  roles?: string[];
}

const navItems: NavItem[] = [
  {
    label: "Dashboard",
    path: "/",
    icon: <BarChart3 className="w-5 h-5" />,
  },
  {
    label: "Registros",
    path: "/registros",
    icon: <Clipboard className="w-5 h-5" />,
  },
  {
    label: "Relatórios",
    path: "/relatorios",
    icon: <FileText className="w-5 h-5" />,
  },
  {
    label: "Unidades",
    path: "/unidades",
    icon: <Building2 className="w-5 h-5" />,
  },
  {
    label: "Usuários",
    path: "/usuarios",
    icon: <Users className="w-5 h-5" />,
    roles: ["admin"],
  },
  {
    label: "Configurações IA",
    path: "/config-ia",
    icon: <Settings className="w-5 h-5" />,
  },
];

export default function Sidebar() {
  const [isOpen, setIsOpen] = useState(true);
  const [, navigate] = useLocation();
  const { user, logout } = useAuth();
  const location = useLocation()[0];

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  const filteredNavItems = navItems.filter((item) => {
    if (item.roles) {
      const userRole = user?.nivel === "Administrador" ? "admin" : user?.nivel === "Gerente" ? "gerente" : "operador";
      if (!item.roles.includes(userRole)) {
        return false;
      }
    }
    return true;
  });

  return (
    <>
      {/* Sidebar Mobile Toggle */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-4 right-4 md:hidden z-40 bg-green-600 text-white p-3 rounded-full shadow-lg hover:bg-green-700 transition"
      >
        {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
      </button>

      {/* Overlay Mobile */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 md:hidden z-30"
          onClick={() => setIsOpen(false)}
        />
      )}

      {/* Sidebar Desktop */}
      <aside
        className={`fixed left-0 top-0 h-screen bg-gradient-to-b from-green-700 to-green-800 text-white transition-all duration-300 z-40 ${
          isOpen ? "w-64" : "w-20"
        } hidden md:block`}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-green-600">
          {isOpen && (
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center">
                <span className="text-green-700 font-bold text-sm">🏥</span>
              </div>
              <span className="font-bold text-lg">GestorUSF</span>
            </div>
          )}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="p-1 hover:bg-green-600 rounded-lg transition"
          >
            {isOpen ? (
              <X className="w-5 h-5" />
            ) : (
              <Menu className="w-5 h-5" />
            )}
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4 space-y-2">
          {filteredNavItems.map((item) => (
            <button
              key={item.path}
              onClick={() => navigate(item.path)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition ${
                location === item.path
                  ? "bg-white text-green-700 font-semibold"
                  : "text-green-100 hover:bg-green-600"
              }`}
              title={!isOpen ? item.label : ""}
            >
              {item.icon}
              {isOpen && <span>{item.label}</span>}
            </button>
          ))}
        </nav>

        {/* User Info */}
        <div className="p-4 border-t border-green-600">
          {isOpen ? (
            <div className="space-y-3">
              <div className="p-3 bg-green-600 rounded-lg">
                <p className="text-xs text-green-200">Usuário</p>
                <p className="font-semibold text-sm truncate">{user?.email}</p>
                <p className="text-xs text-green-200 capitalize">
                  {user?.nivel}
                </p>
              </div>
              <Button
                onClick={handleLogout}
                variant="outline"
                className="w-full bg-green-600 border-green-500 text-white hover:bg-green-700"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Sair
              </Button>
            </div>
          ) : (
            <button
              onClick={handleLogout}
              className="w-full p-2 hover:bg-green-600 rounded-lg transition"
              title="Sair"
            >
              <LogOut className="w-5 h-5 mx-auto" />
            </button>
          )}
        </div>
      </aside>

      {/* Spacer para o conteúdo - Desktop */}
      <div className={`transition-all duration-300 hidden md:block ${isOpen ? "ml-64" : "ml-20"}`} />

      {/* Sidebar Mobile */}
      {isOpen && (
        <aside className="fixed left-0 top-0 h-screen w-64 bg-gradient-to-b from-green-700 to-green-800 text-white z-40 md:hidden overflow-y-auto">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-green-600">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center">
                <span className="text-green-700 font-bold text-sm">🏥</span>
              </div>
              <span className="font-bold text-lg">GestorUSF</span>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="p-1 hover:bg-green-600 rounded-lg transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Navigation */}
          <nav className="p-4 space-y-2">
            {filteredNavItems.map((item) => (
              <button
                key={item.path}
                onClick={() => {
                  navigate(item.path);
                  setIsOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition ${
                  location === item.path
                    ? "bg-white text-green-700 font-semibold"
                    : "text-green-100 hover:bg-green-600"
                }`}
              >
                {item.icon}
                <span>{item.label}</span>
              </button>
            ))}
          </nav>

          {/* User Info */}
          <div className="p-4 border-t border-green-600">
            <div className="space-y-3">
              <div className="p-3 bg-green-600 rounded-lg">
                <p className="text-xs text-green-200">Usuário</p>
                <p className="font-semibold text-sm truncate">{user?.email}</p>
                <p className="text-xs text-green-200 capitalize">
                  {user?.nivel}
                </p>
              </div>
              <Button
                onClick={handleLogout}
                variant="outline"
                className="w-full bg-green-600 border-green-500 text-white hover:bg-green-700"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Sair
              </Button>
            </div>
          </div>
        </aside>
      )}
    </>
  );
}
