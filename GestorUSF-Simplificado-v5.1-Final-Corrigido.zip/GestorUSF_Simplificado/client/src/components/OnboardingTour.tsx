import { useState, useEffect } from "react";
import { X, ChevronRight, ChevronLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

interface TourStep {
  id: string;
  title: string;
  description: string;
  target?: string;
  position?: "top" | "bottom" | "left" | "right";
}

const tourSteps: TourStep[] = [
  {
    id: "welcome",
    title: "Bem-vindo ao GestorUSF! 👋",
    description:
      "Vamos fazer um tour rápido para você conhecer todas as funcionalidades do sistema de gestão de Unidades de Saúde da Família.",
    position: "bottom",
  },
  {
    id: "sidebar",
    title: "Navegação Lateral",
    description:
      "Use a barra lateral para navegar entre as principais seções: Dashboard, Registros, Relatórios, Unidades, Usuários e Configurações de IA.",
    position: "right",
  },
  {
    id: "search",
    title: "Busca Global (Cmd+K)",
    description:
      "Pressione Cmd+K (Mac) ou Ctrl+K (Windows) para abrir a busca global e encontrar rapidamente registros, relatórios e páginas.",
    position: "bottom",
  },
  {
    id: "dashboard",
    title: "Dashboard",
    description:
      "Veja um resumo visual com KPIs, gráficos de distribuição, estatísticas e atividades recentes do seu sistema.",
    position: "bottom",
  },
  {
    id: "registros",
    title: "Registros de Inspeção",
    description:
      "Crie, edite e visualize registros de inspeção. Você pode anexar arquivos de qualquer tipo e gerar relatórios automaticamente com IA.",
    position: "bottom",
  },
  {
    id: "relatorios",
    title: "Geração de Relatórios com IA",
    description:
      "Gere relatórios profissionais automaticamente usando IA. Escolha entre Perplexity, Claude, Gemini, ChatGPT, Cohere ou OpenRouter. Exporte em múltiplos formatos.",
    position: "bottom",
  },
  {
    id: "unidades",
    title: "Cadastro de Unidades",
    description:
      "Cadastre e gerencie as Unidades de Saúde da Família (USFs) do seu sistema.",
    position: "bottom",
  },
  {
    id: "usuarios",
    title: "Gestão de Usuários",
    description:
      "Crie e gerencie usuários do sistema com diferentes níveis de acesso: Administrador, Gerente e Operador.",
    position: "bottom",
  },
  {
    id: "config",
    title: "Configurações de IA",
    description:
      "Configure suas chaves de API para as diferentes provedoras de IA. Teste a conexão antes de usar.",
    position: "bottom",
  },
  {
    id: "final",
    title: "Pronto para começar! 🚀",
    description:
      "Você agora conhece todas as funcionalidades principais. Comece criando um novo registro ou consultando o manual completo.",
    position: "bottom",
  },
];

interface OnboardingTourProps {
  onComplete?: () => void;
}

export default function OnboardingTour({ onComplete }: OnboardingTourProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Verificar se o usuário já fez o tour
    const hasSeenTour = localStorage.getItem("hasSeenOnboardingTour");
    if (!hasSeenTour) {
      setIsVisible(true);
    }
  }, []);

  const handleNext = () => {
    if (currentStep < tourSteps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      handleComplete();
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleComplete = () => {
    localStorage.setItem("hasSeenOnboardingTour", "true");
    setIsVisible(false);
    onComplete?.();
  };

  const handleSkip = () => {
    localStorage.setItem("hasSeenOnboardingTour", "true");
    setIsVisible(false);
  };

  if (!isVisible) return null;

  const step = tourSteps[currentStep];
  const progress = ((currentStep + 1) / tourSteps.length) * 100;

  return (
    <div className="fixed inset-0 z-50 pointer-events-none">
      {/* Overlay */}
      <div
        className="absolute inset-0 bg-black bg-opacity-50 pointer-events-auto transition-opacity"
        onClick={handleSkip}
      />

      {/* Tour Card */}
      <div className="absolute bottom-8 left-8 right-8 md:left-auto md:right-8 md:w-96 pointer-events-auto">
        <Card className="p-6 shadow-2xl animate-in fade-in slide-in-from-bottom-4 duration-300">
          {/* Header */}
          <div className="flex items-start justify-between mb-4">
            <h3 className="text-xl font-bold text-gray-900">{step.title}</h3>
            <button
              onClick={handleSkip}
              className="p-1 hover:bg-gray-100 rounded-lg transition"
            >
              <X className="w-5 h-5 text-gray-500" />
            </button>
          </div>

          {/* Description */}
          <p className="text-gray-700 mb-6 leading-relaxed">{step.description}</p>

          {/* Progress Bar */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-gray-600">
                Passo {currentStep + 1} de {tourSteps.length}
              </span>
              <span className="text-xs font-semibold text-green-600">
                {Math.round(progress)}%
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-green-600 h-2 rounded-full transition-all duration-300"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-between gap-3">
            <Button
              onClick={handleSkip}
              variant="outline"
              className="text-sm"
            >
              Pular Tour
            </Button>

            <div className="flex gap-2">
              <Button
                onClick={handlePrev}
                variant="outline"
                size="sm"
                disabled={currentStep === 0}
                className="w-10 h-10 p-0"
              >
                <ChevronLeft className="w-4 h-4" />
              </Button>

              <Button
                onClick={handleNext}
                className="bg-green-600 hover:bg-green-700"
                size="sm"
              >
                {currentStep === tourSteps.length - 1 ? (
                  "Concluir"
                ) : (
                  <>
                    Próximo <ChevronRight className="w-4 h-4 ml-1" />
                  </>
                )}
              </Button>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
