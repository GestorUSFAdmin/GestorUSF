# Documentação da Lógica de Geração de Relatórios por IA

## 📋 Visão Geral

O sistema **GestorUSF Simplificado** implementa uma lógica automatizada de geração de relatórios profissionais utilizando Inteligência Artificial. Esta documentação detalha como o processo funciona, desde a coleta de dados até a entrega do relatório final.

---

## 🔄 Fluxo Geral do Processo

```
┌─────────────────────────────────────────────────────────────────┐
│                    FLUXO DE GERAÇÃO DE RELATÓRIO                │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  1. Usuário seleciona um Registro                              │
│         ↓                                                       │
│  2. Sistema coleta dados do Registro                           │
│         ↓                                                       │
│  3. Valida Configurações de IA                                 │
│         ↓                                                       │
│  4. Monta Prompt com Instruções                                │
│         ↓                                                       │
│  5. Envia para API de IA (Perplexity/Claude/Gemini)           │
│         ↓                                                       │
│  6. Recebe Resposta da IA                                      │
│         ↓                                                       │
│  7. Processa e Formata Resposta                                │
│         ↓                                                       │
│  8. Salva Relatório no localStorage                            │
│         ↓                                                       │
│  9. Exibe Relatório ao Usuário                                 │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🔧 Componentes Principais

### 1. **RelatoriosPage.tsx** - Interface de Geração

**Localização:** `client/src/pages/RelatoriosPage.tsx`

**Responsabilidades:**
- Exibir lista de registros disponíveis
- Permitir seleção de um registro para gerar relatório
- Mostrar status de geração (carregamento, sucesso, erro)
- Listar relatórios gerados anteriormente
- Permitir download de relatórios

**Fluxo de Interação:**
```typescript
// Usuário clica em "Gerar Relatório com IA"
→ gerarRelatorioComIA() é chamado
  → Valida seleção de registro
  → Chama gerarRelatorioIA(registro)
  → Aguarda resposta da IA
  → Salva novo relatório
  → Atualiza lista de relatórios
```

---

## 🧠 Funções de Geração de Relatório

### 2. **gerarRelatorioIA(registro)** - Orquestrador Principal

**Localização:** `client/src/pages/RelatoriosPage.tsx` (linhas ~250-280)

**Função:** Orquestra todo o processo de geração de relatório

**Código:**
```typescript
async function gerarRelatorioIA(registro: Registro): Promise<string> {
  // 1. Verificar configurações de IA
  const configIA = localStorage.getItem("configIA");
  if (!configIA) {
    throw new Error("Configurações de IA não encontradas...");
  }

  const config = JSON.parse(configIA);

  // 2. Preparar dados do registro em um prompt estruturado
  const prompt = `
    Você é um especialista em gestão de saúde pública e auditoria de USF...
    
    DADOS DA INSPEÇÃO:
    - Título: ${registro.titulo}
    - Data: ${new Date(registro.data).toLocaleDateString("pt-BR")}
    - Unidade: ${registro.unidade}
    - Observações: ${registro.observacoes}
    - Inconformidades: ${registro.inconformidades}
    
    INSTRUÇÕES:
    1. Crie um relatório estruturado com seções específicas
    2. Use linguagem formal e técnica
    3. Inclua referências às normas do SUS
    ...
  `;

  // 3. Chamar API de IA apropriada
  try {
    const relatorioGerado = await chamarAPIIA(config, prompt);
    return relatorioGerado;
  } catch (error) {
    throw new Error("Erro ao gerar relatório com IA...");
  }
}
```

**Etapas Detalhadas:**

#### Etapa 1: Validação de Configurações
```typescript
const configIA = localStorage.getItem("configIA");
if (!configIA) {
  throw new Error("Configurações de IA não encontradas...");
}
```
- Verifica se o usuário configurou uma chave de API
- Se não houver, exibe erro ao usuário
- Impede chamada desnecessária à API

#### Etapa 2: Construção do Prompt
O prompt é a **instrução enviada à IA** que define como o relatório deve ser gerado:

```typescript
const prompt = `
Você é um especialista em gestão de saúde pública e auditoria de 
Unidades de Saúde da Família (USF).

Gere um relatório profissional e detalhado baseado nos seguintes dados:

**DADOS DA INSPEÇÃO:**
- Título: ${registro.titulo}
- Data: ${new Date(registro.data).toLocaleDateString("pt-BR")}
- Unidade: ${registro.unidade}
- Observações: ${registro.observacoes}
- Inconformidades Encontradas: ${registro.inconformidades}

**INSTRUÇÕES:**
1. Crie um relatório estruturado com as seguintes seções:
   - RESUMO EXECUTIVO
   - DADOS DA INSPEÇÃO
   - ANÁLISE SITUACIONAL
   - INCONFORMIDADES IDENTIFICADAS
   - RECOMENDAÇÕES
   - CONCLUSÃO

2. Use linguagem formal e técnica apropriada para documentos 
   oficiais de saúde pública
3. Inclua referências às normas do SUS quando aplicável
4. Seja objetivo e claro nas recomendações
5. Formate o relatório de forma profissional e legível

Gere o relatório completo agora:
`;
```

**Componentes do Prompt:**
- **Contexto:** Define o papel da IA (especialista em saúde pública)
- **Dados:** Insere os valores específicos do registro
- **Instruções:** Define estrutura, tom e formato esperado
- **Seções Esperadas:** Especifica as partes do relatório

#### Etapa 3: Chamada à API de IA
```typescript
const relatorioGerado = await chamarAPIIA(config, prompt);
```
- Passa a configuração e o prompt para a função de chamada
- Aguarda resposta da IA (pode levar alguns segundos)
- Retorna o texto do relatório gerado

---

### 3. **chamarAPIIA(config, prompt)** - Roteador de Provedores

**Localização:** `client/src/pages/RelatoriosPage.tsx` (linhas ~280-310)

**Função:** Direciona a chamada para o provedor de IA correto

**Código:**
```typescript
async function chamarAPIIA(config: any, prompt: string): Promise<string> {
  const { provider, apiKey, modelo } = config;

  if (!apiKey) {
    throw new Error("Chave de API não configurada");
  }

  // Rotear para o provedor apropriado
  if (provider === "perplexity") {
    return await chamarPerplexity(apiKey, modelo, prompt);
  } else if (provider === "claude") {
    return await chamarClaude(apiKey, modelo, prompt);
  } else if (provider === "gemini") {
    return await chamarGemini(apiKey, modelo, prompt);
  } else {
    throw new Error("Provedor de IA não suportado");
  }
}
```

**Lógica:**
1. Extrai `provider`, `apiKey` e `modelo` da configuração
2. Valida se a chave de API existe
3. Chama a função específica do provedor
4. Retorna a resposta da IA

---

## 🌐 Integrações com Provedores de IA

### 4. **chamarPerplexity()** - Integração Perplexity

**Endpoint:** `https://api.perplexity.ai/chat/completions`

**Código:**
```typescript
async function chamarPerplexity(
  apiKey: string,
  modelo: string,
  prompt: string
): Promise<string> {
  const response = await fetch("https://api.perplexity.ai/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: modelo || "sonar-pro",
      messages: [
        {
          role: "user",
          content: prompt,
        },
      ],
      temperature: 0.7,
      max_tokens: 2000,
    }),
  });

  if (!response.ok) {
    throw new Error(`Erro na API Perplexity: ${response.statusText}`);
  }

  const data = await response.json();
  return data.choices[0].message.content;
}
```

**Parâmetros Explicados:**
| Parâmetro | Valor | Explicação |
| :--- | :--- | :--- |
| `model` | `sonar-pro` | Modelo de IA mais avançado do Perplexity |
| `temperature` | `0.7` | Criatividade da resposta (0=determinístico, 1=criativo) |
| `max_tokens` | `2000` | Limite máximo de tokens na resposta (~1500 palavras) |

**Resposta Esperada:**
```json
{
  "choices": [
    {
      "message": {
        "content": "RELATÓRIO EXECUTIVO...[conteúdo do relatório]..."
      }
    }
  ]
}
```

---

### 5. **chamarClaude()** - Integração Anthropic Claude

**Endpoint:** `https://api.anthropic.com/v1/messages`

**Código:**
```typescript
async function chamarClaude(
  apiKey: string,
  modelo: string,
  prompt: string
): Promise<string> {
  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: modelo || "claude-3-opus-20240229",
      max_tokens: 2000,
      messages: [
        {
          role: "user",
          content: prompt,
        },
      ],
    }),
  });

  if (!response.ok) {
    throw new Error(`Erro na API Claude: ${response.statusText}`);
  }

  const data = await response.json();
  return data.content[0].text;
}
```

**Diferenças do Perplexity:**
- Header de autenticação: `x-api-key` em vez de `Authorization`
- Versão da API especificada: `anthropic-version`
- Resposta em formato diferente: `data.content[0].text`

---

### 6. **chamarGemini()** - Integração Google Gemini

**Endpoint:** `https://generativelanguage.googleapis.com/v1beta/models/{modelo}:generateContent`

**Código:**
```typescript
async function chamarGemini(
  apiKey: string,
  modelo: string,
  prompt: string
): Promise<string> {
  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${modelo || "gemini-2.5-flash"}:generateContent?key=${apiKey}`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        contents: [
          {
            parts: [
              {
                text: prompt,
              },
            ],
          },
        ],
        generationConfig: {
          temperature: 0.7,
          maxOutputTokens: 2000,
        },
      }),
    }
  );

  if (!response.ok) {
    throw new Error(`Erro na API Gemini: ${response.statusText}`);
  }

  const data = await response.json();
  return data.candidates[0].content.parts[0].text;
}
```

**Características Únicas:**
- Chave de API passada como parâmetro de query (`?key=...`)
- Estrutura de request diferente: `contents` e `parts`
- Resposta aninhada: `candidates[0].content.parts[0].text`

---

## 💾 Armazenamento e Persistência

### 7. **Salvamento de Relatórios**

**Localização:** `RelatoriosPage.tsx` (função `salvarRelatorios`)

**Processo:**
```typescript
const novoRelatorio: Relatorio = {
  id: `rel_${Date.now()}`,                    // ID único baseado em timestamp
  titulo: `Relatório IA - ${registro.titulo}`, // Título descritivo
  conteudo,                                    // Texto do relatório gerado
  registroId: registro.id,                     // Referência ao registro original
  criadoEm: new Date().toISOString(),         // Data/hora de criação
  tipo: "ia",                                  // Marca como gerado por IA
};

// Salvar no localStorage
localStorage.setItem("relatorios", JSON.stringify([novoRelatorio, ...relatorios]));
```

**Estrutura de Dados:**
```typescript
interface Relatorio {
  id: string;              // Identificador único
  titulo: string;          // Título do relatório
  conteudo: string;        // Texto completo do relatório
  registroId: string;      // ID do registro que originou o relatório
  criadoEm: string;        // ISO timestamp de criação
  tipo: "ia" | "manual";   // Tipo de geração
}
```

---

## ⚙️ Configurações de IA

### 8. **Gerenciamento de Configurações**

**Localização:** `ConfiguracoesIAPage.tsx`

**Dados Armazenados:**
```typescript
interface ConfigIA {
  provider: "perplexity" | "claude" | "gemini";
  apiKey: string;      // Chave de API do provedor
  modelo: string;      // Modelo específico do provedor
}
```

**Exemplo de Configuração Salva:**
```json
{
  "provider": "perplexity",
  "apiKey": "pplx-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
  "modelo": "sonar-pro"
}
```

**Segurança:**
- Chaves de API armazenadas **apenas localmente** no navegador
- Nunca são enviadas para servidores terceiros
- Usuário é responsável por manter a chave segura

---

## 🔍 Tratamento de Erros

### 9. **Estratégia de Tratamento de Erros**

**Cenários Tratados:**

| Erro | Causa | Tratamento |
| :--- | :--- | :--- |
| Sem configuração de IA | Usuário não configurou chave | Mensagem: "Configure em Configurações IA" |
| Chave de API inválida | Chave expirada ou incorreta | Erro da API + sugestão de verificar |
| Modelo não disponível | Modelo descontinuado | Erro: "Modelo não suportado" |
| Timeout | Resposta lenta da IA | Retry automático ou timeout |
| Sem seleção de registro | Usuário clicou sem selecionar | Validação: "Selecione um registro" |

**Código de Tratamento:**
```typescript
try {
  const conteudo = await gerarRelatorioIA(registro);
  // Sucesso - salvar e exibir
  salvarRelatorios([novoRelatorio, ...relatorios]);
  toast.success("Relatório gerado com sucesso!");
} catch (error) {
  console.error("Erro ao gerar relatório:", error);
  toast.error(
    error instanceof Error ? error.message : "Erro ao gerar relatório"
  );
} finally {
  setIsGenerating(false);
}
```

---

## 📊 Exemplo Completo: Fluxo de Geração

### Passo a Passo Detalhado

**1. Usuário seleciona um registro:**
```
Registro: "Inspeção Rotina Mensal - Centro - Setembro 2025"
Data: 2025-09-16
Unidade: USF Centro Dr. José Marques
Observações: Inspeção mensal completa realizada com êxito...
Inconformidades: Ar condicionado da sala de espera com ruído excessivo...
```

**2. Sistema monta o prompt:**
```
Você é um especialista em gestão de saúde pública...

DADOS DA INSPEÇÃO:
- Título: Inspeção Rotina Mensal - Centro - Setembro 2025
- Data: 16/09/2025
- Unidade: USF Centro Dr. José Marques
- Observações: Inspeção mensal completa realizada com êxito...
- Inconformidades: Ar condicionado da sala de espera com ruído excessivo...

INSTRUÇÕES:
1. Crie um relatório estruturado com:
   - RESUMO EXECUTIVO
   - DADOS DA INSPEÇÃO
   - ANÁLISE SITUACIONAL
   - INCONFORMIDADES IDENTIFICADAS
   - RECOMENDAÇÕES
   - CONCLUSÃO
...
```

**3. Envia para API (exemplo: Perplexity):**
```json
POST https://api.perplexity.ai/chat/completions
{
  "model": "sonar-pro",
  "messages": [
    {
      "role": "user",
      "content": "[prompt acima]"
    }
  ],
  "temperature": 0.7,
  "max_tokens": 2000
}
```

**4. IA gera resposta:**
```
# RELATÓRIO EXECUTIVO - USF CENTRO DR. JOSÉ MARQUES

## RESUMO EXECUTIVO
Este relatório analisa as atividades da USF Centro durante setembro de 2025...

## DADOS DA INSPEÇÃO
- Data: 16/09/2025
- Unidade: USF Centro Dr. José Marques
- Tipo: Inspeção Rotina Mensal

## ANÁLISE SITUACIONAL
A unidade demonstra funcionamento satisfatório com 95% de cobertura populacional...

## INCONFORMIDADES IDENTIFICADAS
1. Ar condicionado com ruído excessivo - Prioridade: MÉDIA
2. Prontuários incompletos - Prioridade: BAIXA

## RECOMENDAÇÕES
1. Solicitar manutenção do ar condicionado em 30 dias
2. Realizar treinamento de preenchimento de prontuários

## CONCLUSÃO
A USF Centro apresenta bom desempenho operacional...
```

**5. Sistema salva no localStorage:**
```json
{
  "id": "rel_1727555000000",
  "titulo": "Relatório IA - Inspeção Rotina Mensal - Centro - Setembro 2025",
  "conteudo": "[texto completo acima]",
  "registroId": "reg001",
  "criadoEm": "2025-10-29T15:16:40.000Z",
  "tipo": "ia"
}
```

**6. Relatório exibido ao usuário:**
- Aparece na lista de relatórios gerados
- Usuário pode visualizar completo
- Opção de download em arquivo `.txt`

---

## 🎯 Melhores Práticas

### Dicas para Gerar Melhores Relatórios

**1. Dados Completos no Registro**
- Preencha todos os campos: título, data, unidade, observações, inconformidades
- Quanto mais detalhes, melhor o relatório gerado

**2. Escolha do Provedor**
- **Perplexity:** Melhor para pesquisa em tempo real, inclui fontes
- **Claude:** Melhor para análise profunda e estruturada
- **Gemini:** Bom custo-benefício, rápido

**3. Configuração de Temperatura**
- Atual: `0.7` (balanço entre criatividade e consistência)
- Para mais criatividade: aumentar para `0.9`
- Para mais consistência: diminuir para `0.3`

**4. Limite de Tokens**
- Atual: `2000` tokens (~1500 palavras)
- Para relatórios mais curtos: `1000`
- Para análises profundas: `3000`

---

## 🔐 Segurança e Privacidade

### Considerações Importantes

**Dados Locais:**
- Todos os registros, unidades, usuários e relatórios são armazenados **apenas no navegador**
- Não são enviados para servidores externos (exceto para a IA)

**Chaves de API:**
- Armazenadas em `localStorage` do navegador
- **Nunca** compartilhe sua chave de API
- Se comprometida, regenere no painel do provedor

**Chamadas à IA:**
- O prompt (contendo dados do registro) é enviado para o servidor da IA
- Revise dados sensíveis antes de gerar relatórios
- Considere usar dados anonimizados para testes

---

## 📝 Conclusão

A lógica de geração de relatórios por IA do GestorUSF Simplificado é **modular, extensível e segura**. Permite que usuários gerem relatórios profissionais de forma automática, economizando tempo e garantindo qualidade consistente.

**Próximos Passos:**
1. Configurar chave de API em "Configurações IA"
2. Criar registros com dados completos
3. Gerar relatórios e revisar qualidade
4. Ajustar prompts conforme necessário
5. Exportar e utilizar relatórios em documentos oficiais
