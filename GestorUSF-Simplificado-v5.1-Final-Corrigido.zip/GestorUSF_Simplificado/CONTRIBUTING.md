# 🤝 Guia de Contribuição - GestorUSF

Obrigado por considerar contribuir para o **GestorUSF Simplificado**! Este documento fornece diretrizes para contribuir ao projeto.

---

## 📋 Código de Conduta

Todos os contribuidores devem seguir nosso código de conduta:

- Seja respeitoso com outros contribuidores
- Aceite críticas construtivas
- Foque no que é melhor para a comunidade
- Mostre empatia com outros membros

---

## 🐛 Reportar Bugs

### Antes de reportar

1. Verifique se o bug já foi reportado em **Issues**
2. Tente reproduzir o bug em uma versão limpa
3. Colete informações sobre seu ambiente

### Como reportar

1. Acesse **Issues** no GitHub
2. Clique em **New Issue**
3. Preencha o template com:
   - **Título**: Descrição breve do bug
   - **Descrição**: Explicação detalhada
   - **Passos para reproduzir**: Como replicar o bug
   - **Comportamento esperado**: O que deveria acontecer
   - **Comportamento atual**: O que está acontecendo
   - **Screenshots**: Se aplicável
   - **Ambiente**: Sistema operacional, navegador, versão do Node.js

---

## ✨ Sugerir Melhorias

### Antes de sugerir

1. Verifique se a melhoria já foi sugerida
2. Considere se a melhoria se alinha com os objetivos do projeto

### Como sugerir

1. Acesse **Issues** no GitHub
2. Clique em **New Issue**
3. Use o template de Feature Request com:
   - **Título**: Descrição breve da melhoria
   - **Descrição**: Explicação detalhada
   - **Caso de uso**: Por que essa melhoria é útil
   - **Solução proposta**: Como você imagina a implementação
   - **Alternativas**: Outras abordagens possíveis

---

## 🔧 Processo de Desenvolvimento

### 1. Fork do Repositório

```bash
# Clique em "Fork" no GitHub
# Depois clone seu fork
git clone https://github.com/SEU_USERNAME/GestorUSF-Simplificado.git
cd GestorUSF-Simplificado
```

### 2. Criar Branch para sua Feature

```bash
# Atualize main
git checkout main
git pull origin main

# Crie uma branch descritiva
git checkout -b feature/sua-feature
# ou
git checkout -b fix/seu-bug
```

**Convenção de nomes**:
- `feature/descricao` - Para novas funcionalidades
- `fix/descricao` - Para correção de bugs
- `docs/descricao` - Para documentação
- `refactor/descricao` - Para refatoração

### 3. Fazer Alterações

```bash
# Instale dependências
pnpm install

# Inicie o servidor de desenvolvimento
pnpm dev

# Faça suas alterações
# Teste localmente
```

### 4. Commit das Alterações

```bash
# Adicione arquivos
git add .

# Faça commit com mensagem descritiva
git commit -m "feat: adiciona nova funcionalidade X"
```

**Convenção de commits**:
- `feat:` - Nova funcionalidade
- `fix:` - Correção de bug
- `docs:` - Documentação
- `style:` - Formatação de código
- `refactor:` - Refatoração
- `test:` - Testes
- `chore:` - Tarefas de manutenção

### 5. Push para seu Fork

```bash
git push origin feature/sua-feature
```

### 6. Abrir Pull Request

1. Acesse seu fork no GitHub
2. Clique em **Compare & pull request**
3. Preencha o template com:
   - **Título**: Descrição breve
   - **Descrição**: Explicação detalhada
   - **Tipo de mudança**: Bug fix, Feature, etc.
   - **Como foi testado**: Passos para testar
   - **Checklist**: Confirme que testou

---

## 📝 Padrões de Código

### TypeScript

```typescript
// Use tipos explícitos
interface Usuario {
  id: string;
  nome: string;
  email: string;
}

// Use const para funções
const meuFuncao = (param: string): string => {
  return param.toUpperCase();
};

// Use async/await
const buscarDados = async (): Promise<Dados[]> => {
  try {
    const response = await fetch('/api/dados');
    return await response.json();
  } catch (error) {
    console.error('Erro:', error);
    throw error;
  }
};
```

### React

```typescript
// Use functional components
export default function MeuComponente() {
  const [estado, setEstado] = useState<string>('');

  useEffect(() => {
    // Efeito
  }, []);

  return (
    <div className="...">
      {/* JSX */}
    </div>
  );
}
```

### CSS/Tailwind

```html
<!-- Use classes Tailwind -->
<div className="flex items-center justify-between p-4 bg-white rounded-lg shadow">
  <h1 className="text-2xl font-bold text-gray-900">Título</h1>
  <button className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
    Botão
  </button>
</div>
```

---

## 🧪 Testes

### Executar testes

```bash
pnpm test
```

### Escrever testes

```typescript
describe('MeuComponente', () => {
  it('deve renderizar corretamente', () => {
    // Teste
  });

  it('deve atualizar estado ao clicar', () => {
    // Teste
  });
});
```

---

## 📚 Documentação

### Atualizar documentação

1. Edite o arquivo `.md` relevante
2. Mantenha a formatação consistente
3. Adicione exemplos quando possível

### Arquivos de documentação

- `README.md` - Visão geral do projeto
- `INSTALLATION.md` - Como instalar localmente
- `DEPLOY_GUIDE.md` - Como publicar no Netlify
- `LOGICA_IA_RELATORIOS_DETALHADA.md` - Documentação técnica de IA
- `CONTRIBUTING.md` - Este arquivo

---

## ✅ Checklist antes de Submeter

- [ ] Código segue os padrões do projeto
- [ ] Testes passam localmente (`pnpm test`)
- [ ] Build funciona (`pnpm build`)
- [ ] Documentação foi atualizada
- [ ] Commit messages seguem a convenção
- [ ] Sem erros de linting
- [ ] Sem console.log desnecessários
- [ ] Responsivo em mobile
- [ ] Acessibilidade verificada

---

## 🚀 Processo de Review

1. Um mantenedor revisará seu PR
2. Podem ser solicitadas alterações
3. Após aprovação, será feito merge
4. Seu código estará na próxima release

---

## 📦 Release Process

1. Atualizar versão em `package.json`
2. Atualizar `CHANGELOG.md`
3. Criar tag no Git
4. Publicar no npm (se aplicável)

---

## 💬 Comunicação

- **Issues**: Para bugs e features
- **Discussions**: Para perguntas e discussões
- **Pull Requests**: Para contribuições de código

---

## 📞 Perguntas?

Se tiver dúvidas:

1. Verifique a documentação existente
2. Procure por issues similares
3. Abra uma discussão no GitHub

---

## 🎉 Obrigado!

Suas contribuições fazem o GestorUSF melhor para todos!

---

**Versão**: 1.0  
**Última Atualização**: Outubro 2025  
**Autor**: GestorUSF Development Team
