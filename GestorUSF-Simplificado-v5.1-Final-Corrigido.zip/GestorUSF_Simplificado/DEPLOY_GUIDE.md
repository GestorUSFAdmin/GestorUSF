# 🚀 Guia de Publicação no Netlify - GestorUSF

## Visão Geral

Este documento fornece instruções passo a passo para publicar o **GestorUSF Simplificado** no Netlify, um serviço de hospedagem gratuito para aplicações web estáticas.

---

## 📋 Pré-requisitos

Antes de começar, você precisa ter:

1. **Conta no GitHub** - Para armazenar o código do projeto
2. **Conta no Netlify** - Gratuita em https://netlify.com
3. **Git instalado** - Para versionar o código
4. **Node.js e pnpm** - Para desenvolvimento local (opcional)

---

## 🔧 Passo 1: Preparar o Repositório no GitHub

### 1.1 Criar um novo repositório no GitHub

1. Acesse https://github.com/new
2. Preencha os dados:
   - **Repository name**: `GestorUSF-Simplificado`
   - **Description**: `Sistema de Gestão de Unidades de Saúde da Família`
   - **Visibility**: Público (recomendado) ou Privado
3. Clique em **Create repository**

### 1.2 Fazer push do código para o GitHub

```bash
# Navegar para o diretório do projeto
cd /caminho/para/GestorUSF_Simplificado

# Inicializar repositório git (se não estiver inicializado)
git init

# Adicionar todos os arquivos
git add .

# Fazer commit inicial
git commit -m "Commit inicial: GestorUSF Simplificado com todas as funcionalidades"

# Adicionar remote (substitua USERNAME e REPO pelos seus dados)
git remote add origin https://github.com/USERNAME/GestorUSF-Simplificado.git

# Fazer push para main branch
git branch -M main
git push -u origin main
```

---

## 🌐 Passo 2: Conectar ao Netlify

### 2.1 Fazer login no Netlify

1. Acesse https://app.netlify.com
2. Clique em **Sign up** ou **Log in**
3. Escolha **GitHub** como método de autenticação
4. Autorize o Netlify a acessar seus repositórios

### 2.2 Criar novo site

1. Clique em **New site from Git**
2. Selecione **GitHub** como provedor
3. Procure por `GestorUSF-Simplificado`
4. Clique no repositório para selecioná-lo

### 2.3 Configurar build

Na tela de configuração de build, preencha:

- **Base directory**: (deixe em branco ou deixe vazio)
- **Build command**: `pnpm install && pnpm build`
- **Publish directory**: `dist`

**Nota**: O arquivo `netlify.toml` já contém essas configurações, então o Netlify as detectará automaticamente.

### 2.4 Configurar variáveis de ambiente (se necessário)

Se o seu app usa variáveis de ambiente:

1. Clique em **Site settings** → **Build & deploy** → **Environment**
2. Clique em **Edit variables**
3. Adicione as variáveis necessárias (ex: chaves de API)

**Variáveis recomendadas para GestorUSF**:
- `VITE_APP_TITLE`: Título da aplicação
- `VITE_APP_LOGO`: URL do logo
- `VITE_ANALYTICS_ENDPOINT`: Endpoint de analytics (opcional)

### 2.5 Deploy

1. Clique em **Deploy site**
2. Aguarde o build completar (geralmente 2-5 minutos)
3. Seu site estará disponível em uma URL como: `https://seu-site.netlify.app`

---

## 🔄 Passo 3: Configurações Pós-Deploy

### 3.1 Configurar domínio customizado

1. Acesse **Site settings** → **Domain management**
2. Clique em **Add custom domain**
3. Digite seu domínio (ex: `gestorUSF.com.br`)
4. Siga as instruções para configurar DNS

### 3.2 Habilitar HTTPS

O Netlify fornece HTTPS gratuito automaticamente via Let's Encrypt.

1. Acesse **Site settings** → **Domain management**
2. Procure por **HTTPS**
3. Clique em **Verify DNS configuration** se necessário

### 3.3 Configurar redirecionamentos

O arquivo `netlify.toml` já contém a configuração para SPA (Single Page Application):

```toml
[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200
```

Isso garante que todas as rotas sejam servidas pelo `index.html`.

---

## 📝 Passo 4: Configurar CI/CD Automático

O Netlify detectará automaticamente novos pushes no GitHub e fará deploy automático.

### 4.1 Habilitar deploy automático

1. Acesse **Site settings** → **Build & deploy** → **Deploy contexts**
2. Configure quando fazer deploy:
   - **Production**: Quando fazer push em `main`
   - **Deploy previews**: Criar preview para cada Pull Request
   - **Branch deploys**: Deploy de branches específicas

### 4.2 Adicionar status badge ao README

Adicione este código ao seu `README.md`:

```markdown
[![Netlify Status](https://api.netlify.com/api/v1/badges/SEU_SITE_ID/deploy-status)](https://app.netlify.com/sites/seu-site/deploys)
```

Substitua `SEU_SITE_ID` pelo ID do seu site (encontrado em **Site settings** → **General**).

---

## 🧪 Passo 5: Testar a Aplicação

### 5.1 Testar funcionalidades principais

1. Acesse o site publicado
2. Teste o login com credenciais de teste:
   - Admin: `admin@gestorUSF.com` / `123`
   - Gerente: `maria@gestorUSF.com` / `456`
   - Operador: `joao@gestorUSF.com` / `789`

3. Teste as principais funcionalidades:
   - ✅ Dashboard com gráficos
   - ✅ Criar registros
   - ✅ Upload de arquivos
   - ✅ Gerar relatórios com IA
   - ✅ Exportar em múltiplos formatos
   - ✅ Backup/Restore

### 5.2 Verificar performance

1. Acesse https://pagespeed.web.dev
2. Digite a URL do seu site
3. Analise os resultados de performance

---

## 🔐 Passo 6: Segurança

### 6.1 Proteger dados sensíveis

- **Nunca** commite chaves de API no código
- Use variáveis de ambiente para dados sensíveis
- Configure em **Site settings** → **Build & deploy** → **Environment**

### 6.2 Backup de dados

Como o app usa `localStorage`, os dados são armazenados localmente no navegador:

- Recomenda-se usar a função de **Backup** do app regularmente
- Exporte os dados em JSON para segurança

### 6.3 Monitorar logs

1. Acesse **Deploys**
2. Clique no deploy mais recente
3. Verifique **Deploy log** para erros

---

## 🐛 Troubleshooting

### Problema: Build falha

**Solução**:
1. Verifique o **Deploy log** para mensagens de erro
2. Certifique-se de que `pnpm` está instalado
3. Verifique se todas as dependências estão em `package.json`

### Problema: Site mostra 404 em rotas

**Solução**:
- Verifique se `netlify.toml` contém a configuração de redirects
- Certifique-se de que o `publish` directory está correto (`dist`)

### Problema: Variáveis de ambiente não funcionam

**Solução**:
1. Verifique se as variáveis estão configuradas em **Environment**
2. Certifique-se de que estão prefixadas com `VITE_` (para Vite)
3. Faça um novo deploy após adicionar variáveis

### Problema: Dados desaparecem após refresh

**Solução**:
- Este é o comportamento esperado se o navegador limpar cache
- Use a função de **Backup** para preservar dados
- Considere integrar com um banco de dados backend

---

## 📊 Monitoramento e Análise

### Habilitar analytics

1. Acesse **Site settings** → **Analytics**
2. Clique em **Enable Netlify Analytics** (pago)
3. Ou configure Google Analytics manualmente

### Verificar uptime

1. Acesse **Site settings** → **Monitoring**
2. Configure notificações de downtime

---

## 🚀 Próximos Passos

### Melhorias recomendadas

1. **Integrar com banco de dados backend**
   - PostgreSQL, MongoDB ou Firebase
   - Permitir sincronização em nuvem

2. **Adicionar autenticação com OAuth**
   - Google, GitHub ou Azure AD
   - Melhor segurança e gerenciamento de usuários

3. **Implementar API REST**
   - Usar Netlify Functions ou backend separado
   - Integração com sistemas externos

4. **Adicionar testes automatizados**
   - Jest ou Vitest
   - CI/CD pipeline com GitHub Actions

5. **Configurar domínio customizado**
   - Melhor branding
   - Email profissional

---

## 📞 Suporte

Para mais informações:

- **Documentação Netlify**: https://docs.netlify.com
- **Comunidade Netlify**: https://community.netlify.com
- **GitHub Issues**: Abra uma issue no repositório

---

## 📄 Checklist de Publicação

- [ ] Repositório criado no GitHub
- [ ] Código enviado para GitHub
- [ ] Conta Netlify criada
- [ ] Site conectado ao repositório
- [ ] Build configurado corretamente
- [ ] Deploy realizado com sucesso
- [ ] Site acessível publicamente
- [ ] Funcionalidades testadas
- [ ] Domínio customizado configurado (opcional)
- [ ] HTTPS ativado
- [ ] Variáveis de ambiente configuradas
- [ ] Analytics configurado (opcional)

---

**Versão**: 1.0  
**Última Atualização**: Outubro 2025  
**Autor**: GestorUSF Development Team
