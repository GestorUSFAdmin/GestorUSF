# 📝 Changelog - GestorUSF Simplificado

Todas as mudanças notáveis neste projeto serão documentadas neste arquivo.

---

## [1.0.0] - 2025-10-15

### ✨ Adicionado

#### Autenticação
- Sistema de login com 3 níveis de acesso (Admin, Gerente, Operador)
- Contexto de autenticação com React
- Credenciais de teste incluídas

#### Dashboard
- Exibição de estatísticas principais (registros, inconformidades, unidades, usuários, relatórios)
- Gráficos de distribuição de registros
- Análise de inconformidades
- Botões de Backup e Restore
- Navegação para todas as seções

#### Módulo de Registros
- CRUD completo de registros de inspeção
- Upload de múltiplos arquivos de qualquer tipo
- Download de arquivos anexados
- Visualização de arquivos anexados
- Remoção de arquivos
- Formatação de tamanho de arquivo
- Menu de seleção de unidades (dropdown)

#### Módulo de Relatórios
- Geração de relatórios com IA
- Integração com 3 provedores de IA:
  - Perplexity (sonar-pro, sonar)
  - Claude (claude-3-opus, claude-3-sonnet, claude-3-haiku)
  - Google Gemini (gemini-2.5-flash, gemini-1.5-pro, gemini-1.5-flash)
- Exportação em múltiplos formatos:
  - TXT (texto simples)
  - HTML (página web formatada)
  - JSON (formato estruturado)
  - DOCX (documento Word)
  - PDF (documento portável)
- Inclusão de anexos na geração de relatórios por IA
- Menu de seleção de unidades (dropdown)
- Cópia de conteúdo para área de transferência
- Visualização expandida de relatórios
- Prompt estruturado para gerar relatórios profissionais

#### Cadastro de Unidades
- CRUD de unidades de saúde
- Armazenamento local

#### Cadastro de Usuários
- CRUD de usuários
- Definição de níveis de acesso
- Armazenamento local

#### Configurações de IA
- Seleção de provedor (Perplexity, Claude, Gemini)
- Configuração de chave de API
- Seleção de modelo de IA
- Teste de conexão com API
- Instruções para obter chaves de API
- Indicador de status de configuração

#### Backup e Restore
- Backup completo (registros, relatórios, unidades, usuários, configurações de IA)
- Restauração de backup
- Preservação de chaves de API no backup
- Validação de formato de backup

#### Interface
- Design responsivo
- Sidebar com navegação
- Cards com gradientes
- Ícones descritivos
- Notificações com toast
- Formulários com validação
- Tema claro profissional

#### Documentação
- README.md - Visão geral do projeto
- INSTALLATION.md - Guia de instalação local
- DEPLOY_GUIDE.md - Guia de publicação no Netlify
- LOGICA_IA_RELATORIOS_DETALHADA.md - Documentação técnica de IA
- CONTRIBUTING.md - Guia de contribuição
- CHANGELOG.md - Este arquivo
- userGuide.md - Guia para usuários finais

### 🔧 Técnico

#### Stack
- Frontend: React 19 + TypeScript
- UI: Tailwind CSS 4 + shadcn/ui
- Roteamento: Wouter
- Build: Vite
- Gerenciador de pacotes: pnpm

#### Armazenamento
- LocalStorage para persistência de dados
- Base64 para armazenamento de arquivos

#### APIs Integradas
- Perplexity API
- Anthropic Claude API
- Google Gemini API

### 📦 Dependências Principais

```json
{
  "react": "^19.0.0",
  "typescript": "^5.x",
  "tailwindcss": "^4.0.0",
  "shadcn/ui": "latest",
  "wouter": "latest",
  "sonner": "latest",
  "lucide-react": "latest"
}
```

---

## Planejado para Futuras Versões

### v1.1.0 - Integração com Banco de Dados
- [ ] Integração com PostgreSQL
- [ ] Sincronização em nuvem
- [ ] Acesso multi-dispositivo

### v1.2.0 - Autenticação Avançada
- [ ] OAuth2 (Google, GitHub)
- [ ] JWT tokens
- [ ] Recuperação de senha

### v1.3.0 - Melhorias de IA
- [ ] Pesquisa web integrada
- [ ] Fundamentação legal automática
- [ ] Análise de sentimento

### v1.4.0 - Exportação Avançada
- [ ] Geração de PDF com jsPDF
- [ ] Geração de DOCX com docx
- [ ] Geração de XLSX com xlsx

### v2.0.0 - Backend Completo
- [ ] API REST
- [ ] Autenticação com OAuth
- [ ] Banco de dados relacional
- [ ] Testes automatizados

---

## Notas de Versão

### v1.0.0

**Data de Lançamento**: 15 de Outubro de 2025

**Destaques**:
- Primeira versão estável do GestorUSF Simplificado
- Todas as funcionalidades principais implementadas
- Integração com 3 provedores de IA
- Exportação em 5 formatos diferentes
- Sistema de backup e restore

**Conhecidos Problemas**:
- Dados armazenados localmente (localStorage) - considere usar backend para produção
- Limite de tamanho de arquivo (~5-10 MB total)
- Sem sincronização multi-dispositivo

**Migração de Versões Anteriores**:
- Primeira versão, sem migração necessária

---

## Como Contribuir

Se você encontrou um bug ou tem uma sugestão, abra uma issue no GitHub.

Para contribuir com código, veja [CONTRIBUTING.md](CONTRIBUTING.md).

---

## Suporte

Para suporte, abra uma issue no GitHub ou consulte a documentação.

---

**Versão Atual**: 1.0.0  
**Última Atualização**: 15 de Outubro de 2025  
**Autor**: GestorUSF Development Team

---

## Formato de Versionamento

Este projeto segue [Semantic Versioning](https://semver.org/):

- **MAJOR** - Mudanças incompatíveis
- **MINOR** - Novas funcionalidades compatíveis
- **PATCH** - Correções de bugs

Exemplo: `1.0.0` = Major.Minor.Patch
